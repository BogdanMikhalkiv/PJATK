﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApplication1.EfConfig;

namespace WebApplication1.Models
{
    public class MainDbContext : DbContext
    {
        public MainDbContext()
        {

        }
        public MainDbContext(DbContextOptions options)
            : base(options)
        {

        }

        public DbSet<Doctor> Doctors { get; set; }
        public DbSet<Medicament> Medicaments { get; set; }

        public DbSet<Patient> Patients { get; set; }

        public DbSet<Prescription> Prescriptions { get; set; }
        public DbSet<Prescription_Medicament> prescription_Medicaments { get; set; }
        public DbSet<User> Users { get; set; }



        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            base.OnConfiguring(optionsBuilder);
            optionsBuilder.UseSqlServer("Data Source=db-mssql16.pjwstk.edu.pl;Initial Catalog=s19362;Integrated Security=True");
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.ApplyConfiguration(new DoctorEntityTypeConfig());
            modelBuilder.ApplyConfiguration(new MedicamentEntityTypeConfig());
            modelBuilder.ApplyConfiguration(new PatientEntityTypeConfig());
            modelBuilder.ApplyConfiguration(new Prescription_MedicamentConfig());
            modelBuilder.ApplyConfiguration(new PrescriptionEntityTypeConfig());
            modelBuilder.ApplyConfiguration(new UserEntityTypeConfig());

            SeedDB(modelBuilder);
           



           
        }
        public void SeedDB(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Doctor>(d =>
           {
               d.HasData(
                        new Doctor {IdDoctor = 1, FirstName = "Bogdan", LastName = "Mikhalkiv", Email = "dfdf@mail.ru" },
                        new Doctor { IdDoctor = 2, FirstName = "Yaroslav", LastName = "Mikhalkiv", Email = "yar@mail.ru" },
                        new Doctor { IdDoctor = 3, FirstName = "Yevgenii", LastName = "Memruk", Email = "mem@mail.ru" }

                   );
           });

            modelBuilder.Entity<Patient>(d =>
            {
                d.HasData(
                         new Patient {IdPatient = 1, FirstName = "Piotr", LastName = "Mikhalkiv", Birthdate = new DateTime(1971, 01, 03) },
                         new Patient { IdPatient = 2, FirstName = "Elena", LastName = "Mikhalkiv", Birthdate = new DateTime(1972, 01, 03) },
                         new Patient { IdPatient = 3, FirstName = "Roza", LastName = "Vafina", Birthdate = new DateTime(1950, 01, 03) }

                    );
            });

            modelBuilder.Entity<Prescription>(d =>
            {
                d.HasData(
                         new Prescription {IdPrescription = 1, Date = new DateTime(2020, 03, 01), DueDate = new DateTime(2020, 03, 04), IdPatient = 1, IdDoctor = 1 },
                         new Prescription { IdPrescription = 2, Date = new DateTime(2020, 03, 05), DueDate = new DateTime(2020, 03, 14),  IdPatient = 2, IdDoctor = 2 }

                    );
            });

            modelBuilder.Entity<Medicament>(d =>
            {
                d.HasData(
                         new Medicament {IdMedicament = 1, Name = "cytryn", Description = "something", Type = "A" },
                         new Medicament { IdMedicament = 2, Name = "kola", Description = "something some", Type = "B" }

                    );
            });

            modelBuilder.Entity<Prescription_Medicament>(d =>
            {
                d.HasData(
                         new Prescription_Medicament { IdMedicament = 1, IdPrescription = 1, Dose = 20, Details = "details" },
                         new Prescription_Medicament { IdMedicament = 2, IdPrescription = 2, Dose = 30, Details = "details2" }

                    );
            });
        }


    }
   
}
