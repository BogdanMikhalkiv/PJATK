﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
using WebApplication1.DTO;
using WebApplication1.Models;

namespace WebApplication1.Controllers
{
    [Authorize]
    [Route("api/doctor")]
    [ApiController]
    public class DoctorController : ControllerBase
    {

    



        [HttpGet]
        public IActionResult getDoctor()
        {
            var context = new MainDbContext();
           
            var result = context.Doctors.ToList();

            
            context.Dispose();
            return Ok(result);
        }

        [HttpDelete("{idDoctor}")]
        public IActionResult removeDoctor(int idDoctor)
        {
            var context = new MainDbContext();

            int counter = (from e in context.Doctors
                           where e.IdDoctor == idDoctor
                           select e).Count();
            if (counter == 0)
            {
                return StatusCode(404, "nie ma takiiego doctora");
            }
            else
            {
                var result = (from e in context.Doctors
                              where e.IdDoctor == idDoctor
                              select e).Single();

                context.Doctors.Remove(result);
                context.SaveChanges();
                context.Dispose();
                return Ok("deleted");
            }
        }

        [HttpPost]
        public IActionResult postDoctor(Doctor doctor)
        {
            var context = new MainDbContext();
            Doctor myDoctor = doctor;
            context.Doctors.Add(myDoctor);

            try
            {
                context.SaveChanges();

            }
            catch (DbUpdateException e)
            {
                return Ok(e.StackTrace);
            }
            context.Dispose();
            return Ok("inserted");
        }
        [HttpPut("{idDoctor}")]
        public IActionResult putDoctor(int idDoctor, DoctorDTO doctorDto)
        {

            var context = new MainDbContext();
            int counter = (from e in context.Doctors
                           where e.IdDoctor == idDoctor
                           select e).Count();
            if (counter == 0)
            {
                return StatusCode(404, "nie ma takiiego doctora");
            }
            else
            {
                var doctorRes = (from e in context.Doctors
                                 where e.IdDoctor == idDoctor
                                 select e).First();
                doctorRes.FirstName = doctorDto.FirstName;
                doctorRes.LastName = doctorDto.LastName;
                doctorRes.Email = doctorDto.Email;

                context.SaveChanges();
                context.Dispose();

                return Ok("modicated");
            }
        }
    }
}
