﻿using Microsoft.AspNetCore.Cryptography.KeyDerivation;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using WebApplication1.DTO;
using WebApplication1.Models;

namespace WebApplication1.Controllers
{
    
    [Route("api/account")]
    [ApiController]
    public class AccountsController : Controller
    {
        public IConfiguration _con;

        public AccountsController(IConfiguration con)
        {
            _con = con;
        }

        [HttpPost("add")]
        public IActionResult addUser(UserDto userDto)
        {
            var context = new MainDbContext();

            byte[] salt = new byte[128 / 8];
            using (var rng = RandomNumberGenerator.Create())
            {
                rng.GetBytes(salt);
            }

            string hashed = Convert.ToBase64String(KeyDerivation.Pbkdf2(
                password: userDto.Password,
                salt: salt,
                prf: KeyDerivationPrf.HMACSHA1,
                iterationCount: 10000,
                numBytesRequested: 256 / 8
                ));
            string saltBase64 = Convert.ToBase64String(salt);

            var user = new User()
            {
                Login = userDto.Login,
                Email = userDto.Email,
                Password = hashed,
                Salt = saltBase64,
                RefreshToken = null,
                RefreshTokenExp = null
            };

            context.Users.Add(user);
            context.SaveChanges();

            return Ok("Added");
        }

        [HttpPost("login")]
        public IActionResult Login(LoginRequest loginRequest)
        {
            var context = new MainDbContext();
            User user = context.Users.Where(u => u.Login == loginRequest.Login).FirstOrDefault();

            string passwordHash = user.Password;
            string curHashedPassword = "";

          
            byte[] salt = Convert.FromBase64String(user.Salt);

        
            string currentHashedPassword = Convert.ToBase64String(KeyDerivation.Pbkdf2(
                password: loginRequest.Password,
                salt: salt,
                prf: KeyDerivationPrf.HMACSHA1,
                iterationCount: 10000,
                numBytesRequested: 256 / 8));
          
            if (passwordHash != currentHashedPassword)
            {
                return Unauthorized();
            }


            Claim[] userclaim = new[] {
                    new Claim(ClaimTypes.Name, "pgago"),
                    new Claim(ClaimTypes.Role, "user"),
                    new Claim(ClaimTypes.Role, "admin")
                    //Add additional data here
                };

            SymmetricSecurityKey key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_con["SecretKey"]));

            SigningCredentials creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

            JwtSecurityToken token = new JwtSecurityToken(
                issuer: "https://localhost:5001",
                audience: "https://localhost:5001",
                claims: userclaim,
                expires: DateTime.Now.AddMinutes(10),
                signingCredentials: creds
            );

            string GenerateRefreshToken()
            {
                var randomNumber = new byte[32];
                using (var rng = RandomNumberGenerator.Create())
                {
                    rng.GetBytes(randomNumber);
                    return Convert.ToBase64String(randomNumber);
                }
            }

            user.RefreshToken = GenerateRefreshToken();
            user.RefreshTokenExp = DateTime.Now.AddDays(1);
            context.SaveChanges();

            return Ok(new
            {
                accessToken = new JwtSecurityTokenHandler().WriteToken(token),
                refreshToken = "refresh_token"
            });
       
        }
    }
}
