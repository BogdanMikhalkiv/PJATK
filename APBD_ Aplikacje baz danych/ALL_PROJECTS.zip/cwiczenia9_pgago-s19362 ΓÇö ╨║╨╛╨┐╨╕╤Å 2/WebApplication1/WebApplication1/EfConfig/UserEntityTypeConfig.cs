﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApplication1.Models;

namespace WebApplication1.EfConfig
{
    public class UserEntityTypeConfig : IEntityTypeConfiguration<User>
    {
        public void Configure(EntityTypeBuilder<User> opt)
        {
            opt.HasKey(e => e.IdUser);
            opt.Property(e => e.IdUser).ValueGeneratedOnAdd();

            opt.Property(e => e.Login).IsRequired().HasMaxLength(100);
            opt.Property(e => e.Password).IsRequired().HasMaxLength(100);
            opt.Property(e => e.Email).IsRequired().HasMaxLength(100);
            opt.Property(e => e.Salt).IsRequired().HasMaxLength(350);
            opt.Property(e => e.RefreshTokenExp).HasMaxLength(100);


            opt.ToTable("Users");
        }
    }
}
