﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApplication1.Models;

namespace WebApplication1.EfConfig
{
    public class PrescriptionEntityTypeConfig : IEntityTypeConfiguration<Prescription>
    {
        public void Configure(EntityTypeBuilder<Prescription> opt)
        {

            opt.HasKey(e => e.IdPrescription);
            //opt.Property(e => e.IdPrescription).ValueGeneratedOnAdd();

            opt.Property(e => e.Date).IsRequired();
            opt.Property(e => e.DueDate).IsRequired();

            opt.HasOne(p => p.PatientNav)
                .WithMany(m => m.Prescriptions)
                .HasForeignKey(m => m.IdPatient);

            opt.HasOne(p => p.DoctorNav)
               .WithMany(m => m.Prescriptions)
               .HasForeignKey(m => m.IdDoctor);
            opt.ToTable("Prescriptions");
                
        }
    }
}
