﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApplication1.Models;

namespace WebApplication1.EfConfig
{
    public class Prescription_MedicamentConfig : IEntityTypeConfiguration<Prescription_Medicament>
    {
        public void Configure(EntityTypeBuilder<Prescription_Medicament> opt)
        {
            opt.HasKey(e => new { e.IdMedicament, e.IdPrescription });
            
            
            opt.Property(e => e.Details).IsRequired().HasMaxLength(100);

            opt.HasOne(p => p.PrescriptionNavigation)
                 .WithMany(m => m.PrescriptionsMed)
                 .HasForeignKey(m => m.IdPrescription);

            opt.HasOne(p => p.MedicamentNavigation)
                 .WithMany(m => m.PrescriptionsMed)
                 .HasForeignKey(m => m.IdMedicament);
            opt.ToTable("Prescription_Medicaments");

        }
    }
}

