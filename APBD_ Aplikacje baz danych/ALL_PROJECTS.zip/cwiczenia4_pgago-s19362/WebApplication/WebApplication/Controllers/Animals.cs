using System.Collections.Generic;
using System.Data.SqlClient;
using System.Text.Json;
using Microsoft.AspNetCore.Mvc;

namespace WebApplication.Controllers
{
	[Route("api/animals")]
    [ApiController]
    public class Animals : Controller
    {
        // GET
        SqlConnection sql = new SqlConnection("Data Source=db-mssql16.pjwstk.edu.pl;Initial Catalog=s19362;Integrated Security=True");
        SqlCommand com = new SqlCommand();
        List<Animal> listAnimal = new List<Animal>();

        [HttpPost]
        public IActionResult postAnimals(Animal animal)
        {
          
            com.CommandText = "insert into Animal(Name, Description, Category, Area)" +
                              "values(" +
                              "'" + animal.Name + "'," +
                              "'" + animal.Description + "'," +
                              "'" + animal.Category + "'," +
                              "'" + animal.Area + "'" +
                              "); ";


            com.Connection = sql;
            sql.Open();
            com.ExecuteReader();
            sql.Close();
            return Ok();
        }


        [HttpDelete("{idAnimal}")]
        public IActionResult deletetAnimals(int idAnimal)
        {
            com.CommandText = "delete from animal where idAnimal = " + idAnimal;
            com.Connection = sql;
            sql.Open();

            com.ExecuteReader();


            return Ok("deleted");
        }




        [HttpGet()]
        public IActionResult getAnimals([FromQuery(Name = "orderBy")] string orderBy)
        {
            if (orderBy == null)
            {
                orderBy = "name";
            }

            
            com.CommandText = "select * from animal order by " + orderBy;
            com.Connection = sql;
            sql.Open();

            SqlDataReader dr = com.ExecuteReader();




            while (dr.Read())
            {
                listAnimal.Add(new Animal()
                {
                    IdAnimal = dr["idanimal"].ToString(),
                    Name = dr.GetString(1),
                    Description = dr.GetString(2),
                    Category = dr.GetString(3),
                    Area = dr.GetString(4)

                });

            }
            string jsonFormat = JsonSerializer.Serialize(listAnimal);
            return Ok(jsonFormat);
        }

        [HttpPut("{idAnimal}")]
        public IActionResult putAnimal(string idAnimal, Animal animal)
        {
            com.CommandText = "update animal set name =  " + animal.Name +
                              ", Description = " + animal.Description +
                              ", Category =  " + animal.Category + 
                              ", Area = " + animal.Area + " where idanimal like " + idAnimal;
            com.Connection = sql;
            sql.Open();

            SqlDataReader dr = com.ExecuteReader();
            
            return Ok("updated");
        }
    }
}
