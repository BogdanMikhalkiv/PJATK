namespace WebApplication1
{
    public class Warehouse
    {
        public string idProduct { get; set; }
        public string idWarehouse { get; set; }
        public int amount { get; set; }
        public string createdAt { get; set; }
    }
}