using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Text.Json;
using Microsoft.AspNetCore.Mvc;

namespace WebApplication1.Controllers
{
    [Route("api/warehouses")]
    [ApiController]
    public class WarehousesController : Controller
    {
        private List<Animal> _warehouses = new List<Animal>();
        SqlConnection sql = new SqlConnection("Data Source=db-mssql;Initial Catalog=s19362;Integrated Security=True");


        [HttpPost]
        public IActionResult postWarehouses(Warehouse warehouse)
        {
            SqlCommand com = new SqlCommand();
            SqlCommand com2 = new SqlCommand();


            com.CommandText = "select count(idproduct) from product where idproduct =" + warehouse.idProduct;
            com.Connection = sql;
            com2.CommandText = "select count(IdWarehouse) from Warehouse where IdWarehouse =" + warehouse.idWarehouse;
            sql.Open();
            
            SqlDataReader dr = com.ExecuteReader();
            SqlDataReader dr2 = com2.ExecuteReader();

           
                if (dr.GetString(0).Contains("0")  )
                {
                return Ok(new NotFoundResult() + " nie ma takiego productu ");
                }
                else if (dr2.GetString(0).Contains("0"))
                { 
                    return Ok(new NotFoundResult() + " nie ma takiego  warehouse");

                }
                else if (warehouse.amount <= 0)
                {
                    return Ok("amount musze byc > 0");
                }
                else
                {
                    
                }
                
                    
                
            
            return Ok();
        }

        [HttpGet]
        public IActionResult getWarehouses()
        {
            SqlCommand com = new SqlCommand();
            com.CommandText = "select * from Animal ";
            com.Connection = sql;
            sql.Open();
            
            SqlDataReader dr = com.ExecuteReader();

            while (dr.Read())
            {
                _warehouses.Add(new Animal()
                {
                    IdAnimal = dr["idanimal"].ToString(),
                    Name = dr.GetString(1),
                    Description = dr.GetString(2),
                    Category = dr.GetString(3),
                    Area = dr.GetString(4)
                });
            }
            
            string jsonFormat = JsonSerializer.Serialize(_warehouses);
            return Ok(jsonFormat);
        }



    }
}