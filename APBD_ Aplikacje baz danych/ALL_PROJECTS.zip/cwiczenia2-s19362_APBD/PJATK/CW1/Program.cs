﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace CW1
{
    class Program
    {
        static void Main(string[] args)
        {

            if (!args[0].EndsWith("csv"))
            {
                String str1 = File.ReadAllText("/Users/bogda/Documents/PJATK/APBD/cwiczenia2_pgago-s19362/PJATK/CW1/Data/log.txt");

                using (StreamWriter sw = new StreamWriter("/Users/bogda/Documents/PJATK/APBD/cwiczenia2_pgago-s19362/PJATK/CW1/Data/log.txt"))
                {
                    sw.WriteLine(str1 + "\n" + "Podana ścieżka jest niepoprawna");
                }

                throw new ArgumentException("Podana ścieżka jest niepoprawna");
            }

            if (!File.Exists(args[0]))
            {
                String str1 = File.ReadAllText("/Users/bogda/Documents/PJATK/APBD/cwiczenia2_pgago-s19362/PJATK/CW1/Data/log.txt");

                using (StreamWriter sw = new StreamWriter("/Users/bogda/Documents/PJATK/APBD/cwiczenia2_pgago-s19362/PJATK/CW1/Data/log.txt"))
                {
                    sw.WriteLine(str1 + "\n" + "Plik nazwa nie istnieje");
                }
                
                throw new FileNotFoundException("Plik nazwa nie istnieje");
            }
            List <string> studiesStr = new List<string>();
            List<int> studiesInt = new List<int>();

            List<string[]> list = new List<string[]>();
            string line = null;
            FileInfo fi = new FileInfo("/Users/bogda/Documents/PJATK/APBD/cwiczenia2_pgago-s19362/PJATK/CW1/Data/dane.csv");
            StreamReader stream = new StreamReader(fi.OpenRead());
            while ((line = stream.ReadLine()) != null)
            {
                string[] arr = line.Split(',');

                if ( (chek(arr) == false) && (chekLen(arr)) && (chekDubl(arr, list) == false))
                {
                    list.Add(arr);
                    
                    
                }
                else
                {
                    String str1 = File.ReadAllText("/Users/bogda/Documents/PJATK/APBD/cwiczenia2_pgago-s19362/PJATK/CW1/Data/log.txt");

                    using (StreamWriter sw = new StreamWriter("/Users/bogda/Documents/PJATK/APBD/cwiczenia2_pgago-s19362/PJATK/CW1/Data/log.txt"))
                    {
                        sw.WriteLine(str1 + "\n" + line + "(Student jest duplikatem albo liczba kolumn nie jest rowna 9)");
                    }

                }

              

            }


            for (int i = 0; i < list.Count; i++)
            {
                String str2 = File.ReadAllText(args[1]);

                    using (StreamWriter sw = new StreamWriter(args[1]))
                    {
                        
                        if (!studiesStr.Contains(list.ElementAt(i).ElementAt(2)))
                        {
                            studiesStr.Add(list.ElementAt(i).ElementAt(2));
                            studiesInt.Add(1);
                        }
                        else {
                            studiesInt[studiesStr.IndexOf(list.ElementAt(i).ElementAt(2))]++;
                        }
                        
                        
                        if (i == 0)
                        {
                            sw.WriteLine(str2 + "\n" + "{\n" +
                                         "\t uczelnia: {\n " +
                                         "\t\t createdAt: " + DateTime.Now.ToString("dd.MM.yyy") + ",\n" +
                                         "\t\t author: Bohdan Mykhalkiv,\n" +
                                         "\t\t student: [\n" + "\t\t\t {\n" +
                                         "\t\t\t\t indexNumber: s" + list.ElementAt(i).ElementAt(4) + ",\n " +
                                         "\t\t\t\t fname: " + list.ElementAt(i).ElementAt(0) + ",\n" +
                                         "\t\t\t\t lname: " + list.ElementAt(i).ElementAt(1) + ",\n" +
                                         "\t\t\t\t birthdate: " + list.ElementAt(i).ElementAt(5) + ",\n" +
                                         "\t\t\t\t email: " + list.ElementAt(i).ElementAt(6) + ",\n" +
                                         "\t\t\t\t mothersName: " + list.ElementAt(i).ElementAt(7) + ",\n" +
                                         "\t\t\t\t fathersName: " + list.ElementAt(i).ElementAt(8) + ",\n" +
                                         "\t\t\t\t studies: {\n" +
                                         "\t\t\t\t\t name: " + list.ElementAt(i).ElementAt(2) + " ,\n" +
                                         "\t\t\t\t\t mode: " + list.ElementAt(i).ElementAt(3) + " \n" +
                                         "\t\t\t\t }\n" +
                                         "\t\t\t },"
                            );
                        }
                        if (i >= 1 && i <= list.Count-2)
                        {
                            sw.WriteLine(str2 + "\n" + "\t\t\t {\n" +
                                         "\t\t\t\t indexNumber: s" + list.ElementAt(i).ElementAt(4) + ",\n " +
                                         "\t\t\t\t fname: " + list.ElementAt(i).ElementAt(0) + ",\n" +
                                         "\t\t\t\t lname: " + list.ElementAt(i).ElementAt(1) + ",\n" +
                                         "\t\t\t\t birthdate: " + list.ElementAt(i).ElementAt(5) + ",\n" +
                                         "\t\t\t\t email: " + list.ElementAt(i).ElementAt(6) + ",\n" +
                                         "\t\t\t\t mothersName: " + list.ElementAt(i).ElementAt(7) + ",\n" +
                                         "\t\t\t\t fathersName: " + list.ElementAt(i).ElementAt(8) + ",\n" +
                                         "\t\t\t\t studies: {\n" +
                                         "\t\t\t\t\t name: " + list.ElementAt(i).ElementAt(2) + " ,\n" +
                                         "\t\t\t\t\t mode: " + list.ElementAt(i).ElementAt(3) + " \n" +
                                         "\t\t\t\t }\n" +
                                         "\t\t\t },"
                            );
                        }
                        else if (i == list.Count-1)
                            
                        {
                            sw.WriteLine(str2 + "\n" + "\t\t\t {\n" +
                                         "\t\t\t\t indexNumber: s" + list.ElementAt(i).ElementAt(4) + ",\n " +
                                         "\t\t\t\t fname: " + list.ElementAt(i).ElementAt(0) + ",\n" +
                                         "\t\t\t\t lname: " + list.ElementAt(i).ElementAt(1) + ",\n" +
                                         "\t\t\t\t birthdate: " + list.ElementAt(i).ElementAt(5) + ",\n" +
                                         "\t\t\t\t email: " + list.ElementAt(i).ElementAt(6) + ",\n" +
                                         "\t\t\t\t mothersName: " + list.ElementAt(i).ElementAt(7) + ",\n" +
                                         "\t\t\t\t fathersName: " + list.ElementAt(i).ElementAt(8) + ",\n" +
                                         "\t\t\t\t studies: {\n" +
                                         "\t\t\t\t\t name: " + list.ElementAt(i).ElementAt(2) + " ,\n" +
                                         "\t\t\t\t\t mode: " + list.ElementAt(i).ElementAt(3) + " \n" +
                                         "\t\t\t\t }\n" +
                                         "\t\t\t }\n" +
                                         "\t\t ],"
                            );
                        }
                       
                    }   
                
            }

            for (int i = 0; i < studiesStr.Count; i++)
            {
                String str2 = File.ReadAllText(args[1]);

                using (StreamWriter sw = new StreamWriter(args[1]))
                {
                    if (i == 0)
                    {
                        sw.WriteLine(str2 + "\n" +"\t\t activeStudies: [\n" + "\t\t\t {\n" +
                                                                            "\t\t\t\t name: " + studiesStr[i]+ " ,\n" +
                                                                            "\t\t\t\t numberOfStudents: " + studiesInt[i] + " \n"+
                                                                            "\t\t\t },");    
                    }

                    if (i >= 1 && i <= studiesStr.Count-2) 
                    {
                        sw.WriteLine(str2 + "\n" + "\t\t\t {\n" +
                                     "\t\t\t\t name: " + studiesStr[i]+ " ,\n" +
                                     "\t\t\t\t numberOfStudents: " + studiesInt[i] + " \n"+
                                     "\t\t\t },"
                        );    

                    }else if (i == studiesStr.Count - 1) {
                        sw.WriteLine(str2 + "\n" + "\t\t\t {\n" +
                                     "\t\t\t\t name: " + studiesStr[i]+ " ,\n" +
                                     "\t\t\t\t numberOfStudents: " + studiesInt[i] + " \n"+
                                     "\t\t\t }\n" +
                                     "\t\t ]\n" +
                                     "\t }\n " +
                                     "}\n"
                        );
                    }

                }
            }
            
            
            

        }

       static bool chek(string[] line)
       {
           int count = 0;
            bool b = false;
            for (int i = 0; i < line.Length; i++)
            {
                if (line[i] == "")
                {
                    b = true;
                }

                if (line[i] != "")
                {
                    count++;
                }
                
            }

            return b;
        }
       
       static bool chekLen(string[] line)
       {
           int count = 0;
           bool b = true;
           for (int i = 0; i < line.Length; i++)
           {
               if (line[i] != "")
               {
                   count++;
               }
                
           }

           if (count != 9)
           {
               b = false;
           }

           return b;
       }

       static bool chekDubl(string[] line, List<string[]> list)
       {
           bool b = false;
           for (int i = 0; i < list.Count; i++)
           {
               for (int j = 0; j < list.ElementAt(i).Length; j++)
               {
                   if (line[0] == list.ElementAt(i).ElementAt(0) && line[1] == list.ElementAt(i).ElementAt(1) && line[4] == list.ElementAt(i).ElementAt(4))
                   {
                       b = true;
                   }
                   
               }
               
           }

           return b;
       } 
       
    }
}