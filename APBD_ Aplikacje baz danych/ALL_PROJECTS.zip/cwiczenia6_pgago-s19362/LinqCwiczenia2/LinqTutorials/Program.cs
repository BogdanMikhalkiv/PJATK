﻿using System;

namespace LinqTutorials
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] arr = {1, 1, 1, 1, 1, 1, 10, 1, 1, 1, 1};
            var t = LinqTasks.Task14();
            // Console.WriteLine(t);
            foreach (var emp in t)
            {
                Console.WriteLine(emp);
            
            }
           
        }
    }
}
