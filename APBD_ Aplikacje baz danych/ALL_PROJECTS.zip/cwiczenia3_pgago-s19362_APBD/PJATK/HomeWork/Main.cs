namespace HomeWork
{
    public class Main
    {
        public static void main(string[] args)
        {
            
        }
    }
}