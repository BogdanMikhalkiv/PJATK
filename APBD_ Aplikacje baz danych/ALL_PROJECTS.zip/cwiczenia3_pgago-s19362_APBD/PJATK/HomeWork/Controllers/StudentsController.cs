using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using Microsoft.AspNetCore.Mvc;

namespace HomeWork.Controllers
{
    [Route("api/students")]
    [ApiController]
    public class StudentsController : Controller
    {
        string line = null;
        static  FileInfo fileInfo =
            new FileInfo("./Data/dane.csv");
            
            
        StreamReader stream = new StreamReader(fileInfo.OpenRead());
            
        string[] arr = null;
        List<string[]> list = new List<string[]>();
        List<string> list2 = new List<string>();


        
        [HttpPost]
        public IActionResult PostStudent(Student s)
        {
            myReader();
            int count = 0;
            for (int i = 0; i < list.Count; i++)
            {
                if (!list.ElementAt(i).ElementAt(2).Contains(s.numerIndeksu))
                {
                    count++;
                }
            }

            if (count == list.Count)
            {
                using (StreamWriter sw = new StreamWriter("./Data/dane.csv", true, System.Text.Encoding.Default))
                {
                    sw.WriteLine(
                        s.FirstName+","+s.LastName + "," +s.numerIndeksu + "," +s.dataUrodzenia + "," +
                        s.studia + "," +s.trybStudia + "," +s.mailStudenta + "," +s.imieOjca + "," +s.imieMatki
                    );
                    sw.Close();
                } 
            }
            else
            {
                return Ok("numer indeksu nie jest unikalnym");
            }
               
            
            return Ok("dobrze");
        }
        

        [HttpDelete("{index}")]
        public IActionResult DeleteStudent(string index)
        {
            int count = 1;
            while ((line = stream.ReadLine()) != null)
            {
               // string[] arr = line.Split(',');
                if (!line.Split(',')[2].Contains(index))
                {
                    string q = line;
                    list2.Add(q);
                    
                }
        
                
            }
            string s = "";
            for (int i = 0; i < list2.Count; i++)
            {
                if (list2.Count == 1)
                {
                    s = list2.ElementAt(i);
                }
                else if (list2.Count == 2)
                {
                    if (i == 0)
                    {
                        s += list2.ElementAt(i) + "\n";
                  
                    }
                    else if (i == list.Count - 1)
                    {
                        s += list2.ElementAt(i);
                    }
                }
                else if( list2.Count > 2)
                {
                    if (i == 0)
                    {
                        s += list2.ElementAt(i) + "\n";
                    }else if (i >= 1 && i <= list.Count - 2)
                    {
                        s += list2.ElementAt(i) + "\n";
                    } else if (i == list2.Count - 1)
                    {
                        s += list2.ElementAt(i);
                    }
                }
                
                    
                
                
            }
        
            using (StreamWriter sw =
                new StreamWriter(
                    "./Data/dane.csv"))
            {
                sw.WriteLine(s);
            }
        
            return Ok("deleted");
        
        }

        [HttpGet("{index}")]
        public IActionResult GetStudent(string index)
        {
            while ((line = stream.ReadLine()) != null)
            {
                arr = line.Split(',');
                list.Add(arr);
            }

            string result = "";
            for (int i = 0; i < list.Count; i++)
            {
                Console.WriteLine(index);
                if (list.ElementAt(i).ElementAt(2).Contains(index))
                {
                    result += "\n" + "{\n" +
                              "\t uczelnia: {\n " +
                              "\t\t createdAt: " + DateTime.Now.ToString("dd.MM.yyy") + ",\n" +
                              "\t\t author: Bohdan Mykhalkiv,\n" +
                              "\t\t student: [\n" + "\t\t\t {\n" +
                              "\t\t\t\t indexNumber: " + list.ElementAt(i).ElementAt(2) + ",\n " +
                              "\t\t\t\t fname: " + list.ElementAt(i).ElementAt(0) + ",\n" +
                              "\t\t\t\t lname: " + list.ElementAt(i).ElementAt(1) + ",\n" +
                              "\t\t\t\t birthdate: " + list.ElementAt(i).ElementAt(3) + ",\n" +
                              "\t\t\t\t email: " + list.ElementAt(i).ElementAt(6) + ",\n" +
                              "\t\t\t\t mothersName: " + list.ElementAt(i).ElementAt(8) + ",\n" +
                              "\t\t\t\t fathersName: " + list.ElementAt(i).ElementAt(7) + ",\n" +
                              "\t\t\t\t studies: {\n" +
                              "\t\t\t\t\t name: " + list.ElementAt(i).ElementAt(4) + " ,\n" +
                              "\t\t\t\t\t mode: " + list.ElementAt(i).ElementAt(5) + " \n" +
                              "\t\t\t\t }\n" +
                              "\t\t\t }\n" +
                              "\t\t ]\n" +
                              "\t }\n " +
                              "}\n";
                }



                
            }

            if (result.Length == 0) 
            {
                result = "nie ma takiego indexu";
            }

            
            return Ok(result);
        }
        
        
        // GET
        [HttpGet]
        public IActionResult GetStudents()
        {
            
            myReader();
            

            string result = "";
            for (int i = 0; i < list.Count; i++)
            {
                if (list.Count == 1)
                {
                    result += "\n" + "{\n" +
                              "\t uczelnia: {\n " +
                              "\t\t createdAt: " + DateTime.Now.ToString("dd.MM.yyy") + ",\n" +
                              "\t\t author: Bohdan Mykhalkiv,\n" +
                              "\t\t student: [\n" + "\t\t\t {\n" +
                              "\t\t\t\t indexNumber: " + list.ElementAt(i).ElementAt(2) + ",\n " +
                              "\t\t\t\t fname: " + list.ElementAt(i).ElementAt(0) + ",\n" +
                              "\t\t\t\t lname: " + list.ElementAt(i).ElementAt(1) + ",\n" +
                              "\t\t\t\t birthdate: " + list.ElementAt(i).ElementAt(3) + ",\n" +
                              "\t\t\t\t email: " + list.ElementAt(i).ElementAt(6) + ",\n" +
                              "\t\t\t\t mothersName: " + list.ElementAt(i).ElementAt(8) + ",\n" +
                              "\t\t\t\t fathersName: " + list.ElementAt(i).ElementAt(7) + ",\n" +
                              "\t\t\t\t studies: {\n" +
                              "\t\t\t\t\t name: " + list.ElementAt(i).ElementAt(4) + " ,\n" +
                              "\t\t\t\t\t mode: " + list.ElementAt(i).ElementAt(5) + " \n" +
                              "\t\t\t\t }\n" +
                              "\t\t\t }\n" +
                              "\t\t ]\n" +
                              "\t }\n " +
                              "}\n";
                } else if (list.Count == 2)
                {
                    if (i == 0)
                    {
                        result += "\n" + "{\n" +
                                  "\t uczelnia: {\n " +
                                  "\t\t createdAt: " + DateTime.Now.ToString("dd.MM.yyy") + ",\n" +
                                  "\t\t author: Bohdan Mykhalkiv,\n" +
                                  "\t\t student: [\n" + "\t\t\t {\n" +
                                  "\t\t\t\t indexNumber: " + list.ElementAt(i).ElementAt(2) + ",\n " +
                                  "\t\t\t\t fname: " + list.ElementAt(i).ElementAt(0) + ",\n" +
                                  "\t\t\t\t lname: " + list.ElementAt(i).ElementAt(1) + ",\n" +
                                  "\t\t\t\t birthdate: " + list.ElementAt(i).ElementAt(3) + ",\n" +
                                  "\t\t\t\t email: " + list.ElementAt(i).ElementAt(6) + ",\n" +
                                  "\t\t\t\t mothersName: " + list.ElementAt(i).ElementAt(8) + ",\n" +
                                  "\t\t\t\t fathersName: " + list.ElementAt(i).ElementAt(7) + ",\n" +
                                  "\t\t\t\t studies: {\n" +
                                  "\t\t\t\t\t name: " + list.ElementAt(i).ElementAt(4) + " ,\n" +
                                  "\t\t\t\t\t mode: " + list.ElementAt(i).ElementAt(5) + " \n" +
                                  "\t\t\t\t }\n" +
                                  "\t\t\t },";
                    }
                    else if (i == list.Count - 1)
                    {
                        result += "\n" + "\t\t\t {\n" +
                                  "\t\t\t\t indexNumber: " + list.ElementAt(i).ElementAt(2) + ",\n " +
                                  "\t\t\t\t fname: " + list.ElementAt(i).ElementAt(0) + ",\n" +
                                  "\t\t\t\t lname: " + list.ElementAt(i).ElementAt(1) + ",\n" +
                                  "\t\t\t\t birthdate: " + list.ElementAt(i).ElementAt(3) + ",\n" +
                                  "\t\t\t\t email: " + list.ElementAt(i).ElementAt(6) + ",\n" +
                                  "\t\t\t\t mothersName: " + list.ElementAt(i).ElementAt(8) + ",\n" +
                                  "\t\t\t\t fathersName: " + list.ElementAt(i).ElementAt(7) + ",\n" +
                                  "\t\t\t\t studies: {\n" +
                                  "\t\t\t\t\t name: " + list.ElementAt(i).ElementAt(4) + " ,\n" +
                                  "\t\t\t\t\t mode: " + list.ElementAt(i).ElementAt(5) + " \n" +
                                  "\t\t\t\t }\n" +
                                  "\t\t\t }\n" +
                                  "\t\t ]\n" +
                                  "\t }\n " +
                                  "}\n";
                    }
                }
                else if(list.Count > 2)
                {
                    
                    if (i == 0)
                    {
                        result += "\n" + "{\n" +
                                  "\t uczelnia: {\n " +
                                  "\t\t createdAt: " + DateTime.Now.ToString("dd.MM.yyy") + ",\n" +
                                  "\t\t author: Bohdan Mykhalkiv,\n" +
                                  "\t\t student: [\n" + "\t\t\t {\n" +
                                  "\t\t\t\t indexNumber: " + list.ElementAt(i).ElementAt(2) + ",\n " +
                                  "\t\t\t\t fname: " + list.ElementAt(i).ElementAt(0) + ",\n" +
                                  "\t\t\t\t lname: " + list.ElementAt(i).ElementAt(1) + ",\n" +
                                  "\t\t\t\t birthdate: " + list.ElementAt(i).ElementAt(3) + ",\n" +
                                  "\t\t\t\t email: " + list.ElementAt(i).ElementAt(6) + ",\n" +
                                  "\t\t\t\t mothersName: " + list.ElementAt(i).ElementAt(8) + ",\n" +
                                  "\t\t\t\t fathersName: " + list.ElementAt(i).ElementAt(7) + ",\n" +
                                  "\t\t\t\t studies: {\n" +
                                  "\t\t\t\t\t name: " + list.ElementAt(i).ElementAt(4) + " ,\n" +
                                  "\t\t\t\t\t mode: " + list.ElementAt(i).ElementAt(5) + " \n" +
                                  "\t\t\t\t }\n" +
                                  "\t\t\t },";
                    }

                    if (i >= 1 && i <= list.Count - 2)
                    {
                        result += "\n" + "\t\t\t {\n" +
                                  "\t\t\t\t indexNumber: " + list.ElementAt(i).ElementAt(2) + ",\n " +
                                  "\t\t\t\t fname: " + list.ElementAt(i).ElementAt(0) + ",\n" +
                                  "\t\t\t\t lname: " + list.ElementAt(i).ElementAt(1) + ",\n" +
                                  "\t\t\t\t birthdate: " + list.ElementAt(i).ElementAt(3) + ",\n" +
                                  "\t\t\t\t email: " + list.ElementAt(i).ElementAt(6) + ",\n" +
                                  "\t\t\t\t mothersName: " + list.ElementAt(i).ElementAt(8) + ",\n" +
                                  "\t\t\t\t fathersName: " + list.ElementAt(i).ElementAt(7) + ",\n" +
                                  "\t\t\t\t studies: {\n" +
                                  "\t\t\t\t\t name: " + list.ElementAt(i).ElementAt(4) + " ,\n" +
                                  "\t\t\t\t\t mode: " + list.ElementAt(i).ElementAt(5) + " \n" +
                                  "\t\t\t\t }\n" +
                                  "\t\t\t },";
                    }
                    else if (i == list.Count - 1)
                    {
                        result += "\n" + "\t\t\t {\n" +
                                  "\t\t\t\t indexNumber: " + list.ElementAt(i).ElementAt(2) + ",\n " +
                                  "\t\t\t\t fname: " + list.ElementAt(i).ElementAt(0) + ",\n" +
                                  "\t\t\t\t lname: " + list.ElementAt(i).ElementAt(1) + ",\n" +
                                  "\t\t\t\t birthdate: " + list.ElementAt(i).ElementAt(3) + ",\n" +
                                  "\t\t\t\t email: " + list.ElementAt(i).ElementAt(6) + ",\n" +
                                  "\t\t\t\t mothersName: " + list.ElementAt(i).ElementAt(8) + ",\n" +
                                  "\t\t\t\t fathersName: " + list.ElementAt(i).ElementAt(7) + ",\n" +
                                  "\t\t\t\t studies: {\n" +
                                  "\t\t\t\t\t name: " + list.ElementAt(i).ElementAt(4) + " ,\n" +
                                  "\t\t\t\t\t mode: " + list.ElementAt(i).ElementAt(5) + " \n" +
                                  "\t\t\t\t }\n" +
                                  "\t\t\t }\n" +
                                  "\t\t ]\n" +
                                  "\t }\n " +
                                  "}\n";
                    }
                }

            }
            return Ok(result);
        }

        public void myReader()
        {
            while ((line = stream.ReadLine()) != null)
            {
                if (line.Length != 0)
                {
                    arr = line.Split(',');
                    list.Add(arr);     
                }
               
            }
        }
    }
}