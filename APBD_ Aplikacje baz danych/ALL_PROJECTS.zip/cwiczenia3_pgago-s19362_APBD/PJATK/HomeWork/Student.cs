

namespace HomeWork
{
    public class Student
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string numerIndeksu { get; set; }
        public string dataUrodzenia { get; set; }
        public string studia { get; set; }
        public string trybStudia { get; set; }
        public string mailStudenta { get; set; }
        public string imieOjca { get; set; }
        public string imieMatki { get; set; }

    }
}