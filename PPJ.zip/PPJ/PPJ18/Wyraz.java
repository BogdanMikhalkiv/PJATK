package PPJ18;

public class Wyraz {
    char[] chars;
    int tmp;

    public Wyraz () {
        chars = new char[100];
        tmp = 0;
    }

    public void dodajZnak( char c) {
        if (tmp < chars.length) {
            chars[tmp] = c;
            tmp++;
        }
    }

    public void wyswietl () {
        for (int i = 0; i < tmp; i++) {
            System.out.print(chars[i] + " ");
        }
    }

    public int   length () {
       return tmp;
    }
}
