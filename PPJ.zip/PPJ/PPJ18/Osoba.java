package PPJ18;

public class Osoba {
    String imie;
    int rokUrodzenia;

    public Osoba (String imie , int rokUrodzenia) {
        this.imie = imie;
        this.rokUrodzenia = rokUrodzenia;
    }
     public Osoba (String imie) {
        this.imie = imie;
        rokUrodzenia = 1990;
     }

     public String getImie () {
        return imie;
    }
     public int getRokUrodzenia () {
        return rokUrodzenia;
     }

     public static Osoba  zwrocStarszaOsobe (Osoba osoba1, Osoba osoba2) {
        if ((2019 - osoba1.rokUrodzenia) > (2019 - osoba2.rokUrodzenia)) {
            System.out.println(osoba1.getImie());
            return osoba1;
        } else {
            System.out.println(osoba2.getImie());
            return osoba2;
        }
     }

     public static Osoba zwrocNajstarszaOsobe (Osoba[] arr) {
        int max =0;
        int index = 0;
         for (int i = 0; i < arr.length; i++) {
             if (( 2019 - arr[i].rokUrodzenia) > max) {
                 max = arr[i].rokUrodzenia;
                 index = i;
             }
         }
         System.out.println(arr[index].getImie());
         return arr[index];
     }
}
