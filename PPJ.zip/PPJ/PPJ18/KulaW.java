package PPJ18;

public class KulaW {
    public KulaW (Kwadrat kwadrat) {
    }
    public KulaW (Walec walec) {
    }
}
