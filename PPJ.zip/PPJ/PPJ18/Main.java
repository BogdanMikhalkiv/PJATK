package PPJ18;

public class Main {
    public static void main(String[] args) {
        Osoba osoba = new Osoba("Bogdan", 2002);
        Osoba osoba1 = new Osoba("Yaroslav", 2001);
        Osoba osoba2 = new Osoba("Masha" , 2000);
        Osoba[] arr = new Osoba[3];
        arr[0] = osoba;
        arr[1] = osoba2;
        arr[2] = osoba1;
//        System.out.println(osoba.getImie());
//        System.out.println(osoba.getRokUrodzenia());
//        System.out.println(Osoba.zwrocStarszaOsobe(osoba, osoba1));
        System.out.println(Osoba.zwrocNajstarszaOsobe(arr));

    }
}
