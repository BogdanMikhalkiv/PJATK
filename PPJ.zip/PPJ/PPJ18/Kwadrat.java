package PPJ18;

public class Kwadrat {
    private int bok;
    public Kwadrat (int bok) {
        this.bok = bok;
    }
    public void show () {
        System.out.println("pole -" + bok * bok + "\t" + "Obj - " + Math.pow(bok,3));
    }
}
