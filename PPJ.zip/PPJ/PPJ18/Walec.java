package PPJ18;

public class Walec {
    private int promien;
    private int wysokosc;

    public Walec (int promien, int wysokosc) {
        this.promien = promien;
        this.wysokosc = wysokosc;
    }
    public void show () {
        System.out.println("Pole powierchni - " + Math.pow(promien,2) * Math.PI + " " + "Obj - " + (Math.pow(promien,2) * Math.PI) * wysokosc );

    }
}
