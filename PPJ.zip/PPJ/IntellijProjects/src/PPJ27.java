import java.io.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class PPJ27 {
    public static void main(String[] args) {
        int slow = 0;
        int dat = 0;
        int lat = 0;
        int slowZWielkiej = 0;
        int kropek = 0;
        String text = "Jan III Sobieski herbu Janina (ur. 17\n" +
                "sierpnia 1629 w Olesku, zm. 17 czerwca 1696 w Wilanowie) – król Polski i wielki\n" +
                "książę litewski od 1674, hetman wielki koronny od 1668, hetman polny koronny od\n" +
                "1666, marszałek wielki koronny od 1665, chorąży wielki koronny od 1656." + "99 sie 1975";

        Pattern p = Pattern.compile("\\w+");
        Matcher m = p.matcher(text);

        while(m.find()) {
            slow++;
            System.out.println(m.group());
        }
        System.out.println("Slow : " + slow);

        p = Pattern.compile("[0-3]{1}[1-9]{1}\\p{Space}\\w+\\p{Space}\\d{4}");
        m = p.matcher(text);

        while(m.find()) {
            dat++;
            System.out.println(m.group());
        }
        System.out.println("Dat : " + dat);

        p = Pattern.compile("\\d{4}");
        m = p.matcher(text);

        while(m.find()) {
            lat++;
            System.out.println(m.group());
        }
        System.out.println("Lat : " + lat);

        p = Pattern.compile("[A-Z]{1}[a-z]+");
        m = p.matcher(text);

        while(m.find()) {
            slowZWielkiej++;
            System.out.println(m.group());
        }
        System.out.println("Slow z Wielkiej : " +slowZWielkiej );

        p = Pattern.compile("\\.");
        m = p.matcher(text);

        while(m.find()) {
            kropek++;
            System.out.println(m.group());
        }
        System.out.println("Kropek : " + kropek);

        StringBuilder str = new StringBuilder();
        try {
            int helpfulInt;

            FileInputStream fis = new FileInputStream("C:\\Users\\s17505\\Desktop\\PPJ27\\serverLog");
            while((helpfulInt = fis.read())!= -1) {
                str.append((char) helpfulInt);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        Pattern ip = Pattern.compile("\\d+\\.\\d+\\.\\d+\\.\\d+");
        Pattern data = Pattern.compile("[0-3]{1}[1-9]{1}\\/[0-3]{1}[1-9]{1}\\/\\d{4}");
        Pattern wiadomosc = Pattern.compile("\\> .*");
        Matcher ip1 = ip.matcher(str);

        String[][] tablica = new String[100][3];
        int i = 0;
        while (ip1.find()) {
            tablica[i][0] = ip1.group();
            i++;
        }
        i = 0;

        Matcher data1 = data.matcher(str);
        while(data1.find()) {
            tablica[i][1] = data1.group();
            i++;
        }
        i = 0;
        Matcher wiadomosc1 = wiadomosc.matcher(str);
        while(wiadomosc1.find()) {
            tablica[i][2] = wiadomosc1.group();
            i++;
        }




    }
}
