package PPJ29;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Main {
    public static void main(String[] args) {
        Pattern pattern = Pattern.compile("\\d{4}[-]([1-9]|[1][0-2])[-]([1-2][0-9]|[3][0-1]|[1-9])");
        String test = "1245-12-130";
        Matcher matcher = pattern.matcher(test);
        System.out.println(matcher.matches());


        /*Scanner in = new Scanner(System.in);
        String adresEmail = in.nextLine();

        pattern = Pattern.compile("[a-zA-Z].*[@]([a-zA-Z]*[.])+[a-zA-Z]*");
        matcher = pattern.matcher(adresEmail);
        System.out.println(matcher.matches());
        */

        StringBuilder str = new StringBuilder();
        String ipv4 = null;
        try {
            int helpfulInt;
            FileInputStream fis = new FileInputStream("C:\\Users\\s17505\\Desktop\\PPJ27\\serverLog.txt");
            while((helpfulInt = fis.read())!= -1) {
                str.append((char) helpfulInt);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }finally {
            ipv4 = str.toString();
        }
        ArrayList<String> ipAdresses = new ArrayList<>();
        pattern = Pattern.compile("(\\d{1,3}[.]){3}\\d{1,3}");
        matcher = pattern.matcher(ipv4);
        while (matcher.find()) {
            ipAdresses.add(matcher.group());
        }
        StringBuilder helpfulString = new StringBuilder();
        InputStream in = (System.in);
        for (int i = 0; i < ipAdresses.size(); ++i) {

            helpfulString = new StringBuilder();
        }

    }
}
