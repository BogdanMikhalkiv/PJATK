package PPJ29;

import java.io.*;

public class MyScanner {
    InputStream in;
    MyScanner(InputStream in) {
        this.in = in;
    }


    public String getWord() {
        int helpfullInt;
        String stop = " ;,.\n\t\r";
        String word = "";
        try {
            while (stop.indexOf((char)(helpfullInt = in.read())) == -1 ) {
                word = word + (char)helpfullInt;
            }
        }catch (Exception ex) {
            ex.printStackTrace();
        }
        return word;
    }

    public String getLineFromText() {
        int helpfullInt;
        char stop = '\n';
        String line = "";
        try {
            while((helpfullInt = in.read()) != -1 && helpfullInt != stop) {
                line = line + (char)helpfullInt;
            }
        }catch (Exception ex) {
            ex.printStackTrace();
        }
        return line;
    }

    public int getNumber() {
        return Integer.parseInt(getWord());
    }

    public int getPlusInt() throws Exception {
        int number = getNumber();
        if(number < 0) {
            throw new Exception("Number is degree zero.");
        }else
            if(number == 0) {
                throw new Exception("Number is zero");
            } else
                return number;
    }
}
