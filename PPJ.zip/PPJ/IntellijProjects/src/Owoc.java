
public class Owoc {

    int iloscPestek;
    String barwa;
    double waga;

    Owoc(int iloscPestek, String barwa){
        this.iloscPestek = iloscPestek;
        this.barwa = barwa;
        this.waga = ((Math.random()*0.3) + 0.5);
    }

    void show(){
        System.out.println(
                this + "Ja owowc mam " + iloscPestek +
                        " i jest barwy " + barwa
        );
    }

    public void toString(Owoc owoc) {
        System.out.println("Waga owoca " + owoc.waga);
    }

}
