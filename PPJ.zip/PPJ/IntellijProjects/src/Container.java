public class Container {
    Ciastko cargo;
    double cargoWeight;
    int expireDays;
}
