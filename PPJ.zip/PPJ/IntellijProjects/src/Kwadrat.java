public class Kwadrat {
    int bok;

    Kwadrat(int bok) {
        this.bok = bok;
    }



    public void show(){
        System.out.println("pole powerzchni : " + Math.pow(bok,2));
        System.out.println("obetnosc szeszcianu : " + Math.pow(bok,3));

        Walec wc = new Walec(bok/2, bok);
        wc.show();
    }

}
