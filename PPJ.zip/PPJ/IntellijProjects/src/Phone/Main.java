package Phone;

import java.awt.*;

public class Main {
    public static void main(String[] args) {
        Person[] numbers = {
          new Person("Jarek", "Chuiev", "752-125-151")
        };

        Telefon[] telefons = {
                new Telefon(Color.black,"Cabel"),
                new Komorka(Color.green,"Radio"),
                new Smartphone(Color.white, "IOS", numbers)
        };

        for (int i = 0; i < telefons.length; ++i) {
            for (int j = 0; j < 10; ++j) {
                if (j%2 == 0) {
                    telefons[i].call("123-234-513");
                } else {
                    telefons[i].call(numbers[0].getNumber());
                }
            }
        }

        for (int i = 0; i < telefons.length; ++i) {
            System.out.println("\n===========================================================\n");

            telefons[i].showCallHistory();
        }
    }
}
