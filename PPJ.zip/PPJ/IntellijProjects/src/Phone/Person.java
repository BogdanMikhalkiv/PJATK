package Phone;

public class Person {
    protected String name;
    protected String thurName;
    protected String number;

    public Person(String name, String thurName, String number) {
        this.name = name;
        this.thurName = thurName;
        this.number = number;
    }

    public String getNumber() {
        return number;
    }

    public String getThurName() {
        return thurName;
    }

    public String getName() {
        return name;
    }
}
