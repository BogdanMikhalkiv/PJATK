package Phone;

import java.awt.*;

public class Komorka extends Telefon {
   protected String[] lastTenCalls = new String[10];

    public Komorka(Color color, String communicativeInterface) {
        super(color, communicativeInterface);
    }

    void call (String number) {
       super.call(number);

       for (int i = 8; i >= 0; --i) {
           lastTenCalls[i + 1] = lastTenCalls[i];
           lastTenCalls[0] = number;
       }
    }

    void showCallHistory () {
        for (int i = 0; i < lastTenCalls.length; ++i) {
            System.out.println("Call " + i + " : " + lastTenCalls[i]);
        }
    }
}
