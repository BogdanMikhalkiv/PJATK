package Phone;

import java.awt.*;

public class Telefon {
    private String communicativeInterface;
    private Color color;

    public Telefon (Color color, String communicativeInterface) {
        this.communicativeInterface = communicativeInterface;
        this.color = color;
    }

     void call (String number) {
        System.out.println("Calling : " + number);
     }

     void showCallHistory () {
         System.out.println("No history!");
     }

}
