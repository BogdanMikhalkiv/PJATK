package Phone;

import java.awt.*;

public class Smartphone extends  Komorka {
    protected Person[] friends;

    public Smartphone (Color color, String communicativeInterface, Person[] friends) {
        super(color, communicativeInterface);
        this.friends = friends;
    }

    public void call (String number) {
        super.call(number);
    }

    public void call (Person friend) {
        call(friend.getNumber());
    }

    void showCallHistory () {
        for (int i = 0; i < lastTenCalls.length; ++i) {
            boolean show = false;
            for (int j = 0; j < friends.length; ++j) {
                if (lastTenCalls[i].equals(friends[j].getNumber())) {
                    System.out.println (
                            "Call " + i + ": " +
                            friends[j].getName() + " " +
                            friends[j].getThurName() + " " +
                            friends[j].getNumber()
                    );
                    show = true;
                    j = friends.length;
                }
            }
            if (!show) {
                System.out.println("Call " + i + " : " + lastTenCalls[i]);
            }
        }
    }
}
