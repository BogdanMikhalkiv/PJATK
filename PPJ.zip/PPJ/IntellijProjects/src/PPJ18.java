public class PPJ18 {
    public static void main(String args[]) {
        B b = new B();
        b.nStaticShowThis();
        B.staticShowThis();

        String str1 = "";
        String str2 = "";
        String str3 = "";

        String str = "Ala ma kota";
        System.out.println(str.charAt(2) + " " + str.charAt(4));

        System.out.println(str.indexOf('k'));

        for(int i = 0 ; i < str.length(); ++i) {
           if(i == str.indexOf(' ')) {
               for (int j = 0; j < i; ++j ) {
                   str1 = str1 + str.charAt(j);
               }

               for(int p = i + 1; p < str.indexOf(' ', i + 1); ++p) {
                   str2 = str2 + str.charAt(p);
               }

               for(int k = str.indexOf(' ', i + 1 ) + 1; k < str.length(); ++ k) {
                   str3 = str3 + str.charAt(k);
               }
           }

        }
        System.out.println(str1);
        System.out.println(str2);
        System.out.println(str3);
    }
}
