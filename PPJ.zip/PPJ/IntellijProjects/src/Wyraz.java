public class Wyraz {
    String str;
    int number;
    Wyraz() {
        this.str = "";
        this.number = 0;
    }
    public String dodajZnak(char chr) {
        this.str = str + chr;
        return str;
    }
    public String toString() {
        return str;
    }
    public int length() {
        this.number = str.length();
        return number;
    }
}
