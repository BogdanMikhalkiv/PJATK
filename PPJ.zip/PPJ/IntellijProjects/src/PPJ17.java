public class PPJ17 {
    public static void main( String args[]) {
        Kwadrat kw = new Kwadrat(15);
        kw.show();

        Walec wc = new Walec(15,10);
        wc.show();
    }
}
