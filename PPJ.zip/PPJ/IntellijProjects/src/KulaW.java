public class KulaW {
    int radius;

    KulaW(Walec walec) {
        if(walec.promien < walec.wysokosc) {
            this.radius =  walec.promien/2;
        }else
            this.radius = walec.wysokosc/2;

    }

    KulaW(Kwadrat kwadrat) {
        this.radius = kwadrat.bok/2;
    }


}
