package PPJ28;

public class Wiadomosc {
    int dzien, miesiac, rok;
    String godzina;
    String user;
    String ip;
    String text;

    public Wiadomosc(int dzien, int miesiac, int rok, String godzina, String user, String ip, String text) {
        this.dzien = dzien;
        this.miesiac = miesiac;
        this.rok = rok;
        this.godzina = godzina;
        this.user = user;
        this.ip = ip;
        this.text = text;
    }

    @Override
    public String toString() {
        return "Wiadomosc{" +
                "dzien=" + dzien +
                ", miesiac=" + miesiac +
                ", rok=" + rok +
                ", godzina='" + godzina + '\'' +
                ", user='" + user + '\'' +
                ", ip='" + ip + '\'' +
                ", text='" + text + '\'' +
                '}';
    }

}
