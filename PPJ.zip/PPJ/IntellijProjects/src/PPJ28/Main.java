package PPJ28;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        StringBuilder str = new StringBuilder();
        try {
            int helpfulInt;

            FileInputStream fis = new FileInputStream("C:\\Users\\s17505\\Desktop\\PPJ27\\serverLog");
            while((helpfulInt = fis.read())!= -1) {
                str.append((char) helpfulInt);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        ArrayList<Wiadomosc> wiadomoscArrayList = new ArrayList<>();
        

    }
}
