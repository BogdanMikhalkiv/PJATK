import java.util.Scanner;

public class PPJ14 {
    public static void main(String[] args) {
        System.out.println("Enter number");
        Scanner in = new Scanner(System.in);
        int zmienna1 = in.nextInt();
        show(zmienna1);



        //==========================
        int wrt = 5;
        modifyValue(wrt);
        wrt = modifyValueInt(wrt);

        //=============================

        char[] matrixChar = {'A','l','a',' ','m','a',' ','k','o','t','a','.'};
        int count ;
        count = countLetters(matrixChar);
        System.out.println(count);

        //======================================================

        int[][] matrix = new int[20][20];                   //OSTATNIE ZADANIE, PRACUJE TYLKO DLA TABLIC [N] x [N]

        for(int i = 0; i <= matrix.length/2; i = i + 2) {
            fillCol(matrix,0,1);
            fillRowFromTo(matrix, i, i+2, matrix[i].length-1-i, 1);
            firrColFromTo(matrix, i+2, i, matrix.length-3-i, 1);

            fillRowFromTo(matrix,matrix.length - 1 - i, i,matrix.length-1-i,1);
            firrColFromTo(matrix,matrix.length- 1- i, i,matrix.length-1-i,1);
        }
        matrixOut(matrix);
    }




    public static void show(int zmiennaInt) {
        System.out.println("Zmienna INT : "+zmiennaInt);
    }
    //====================================================


    public static void modifyValue(int valueInt ) {
        System.out.println(valueInt);
        valueInt = valueInt * 5;
        System.out.println(valueInt);
    }
    public static int modifyValueInt(int valueInt ) {
        System.out.println(valueInt);
        valueInt = valueInt * 5;
        System.out.println(valueInt);
        return valueInt;
    }
    //==========================================================

    public static int countLetters(char[] argumentMatrix) {
        int count = 0;
        for(int i = 0; i < argumentMatrix.length;++i) {
            if(argumentMatrix[i] != ' ' && argumentMatrix[i] != '.'){
                count++;
            }
        }
        return count;
    }
    //=================================================

    public static void matrixOut(int[][] matrixInt) {
        for (int i = 0; i < matrixInt.length; ++i) {
            for(int j = 0; j < matrixInt[i].length;++j) {
                System.out.print(matrixInt[i][j]);
            }
            System.out.println();
        }
    }

    public static void fillRow(int[][] matrix, int row, int val) {
        if(row > matrix.length - 1) {
            System.out.println("zly 'row'");
        }else {
            for (int i = 0; i < matrix[matrix.length-1].length; ++i) {
                matrix[row][i] = val;
            }
        }
    }

    public static void fillCol(int[][] matrix, int col, int val) {
        for(int i = 0; i < matrix.length; ++i ){
            if(col > matrix[i].length){
                System.out.println("zly 'col'");
            }else {
                matrix[i][col] = val;
            }
        }
    }

    public static void fillRowFromTo(int matrix[][], int row, int from, int to, int val) {
        if(row > matrix.length - 1) {
            System.out.println("zly 'row'");
        }else {
            for (int i = 0; i < matrix[matrix.length-1].length; ++i) {
                if(i >= from && i <= to) {
                    matrix[row][i] = val;
                }
            }
        }
    }

    public static void firrColFromTo(int matrix[][], int col, int from, int to, int val) {
        if(col > matrix.length - 1) {
            System.out.println("zly 'row'");
        }else {
            for (int i = 0; i < matrix[matrix.length-1].length; ++i) {
                if(i >= from && i <= to) {
                    matrix[i][col] = val;
                }
            }
        }
    }
}