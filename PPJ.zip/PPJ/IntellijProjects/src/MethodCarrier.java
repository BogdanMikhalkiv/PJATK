public class MethodCarrier {
    public void setValue(int value) {
        System.out.println("value is int : " + value );
    }

    public void setValue(float value) {
        System.out.println("value is float : " + value);
    }

    public void setValue(Liczba liczba) {
        System.out.println("value is Liczba : " + liczba);
        liczba.przypiszWartosc(5);
        liczba.wyswietlWartosc();
    }
}
