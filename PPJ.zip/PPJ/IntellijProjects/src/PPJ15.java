public class PPJ15 {
    public static void main(String args[]) {
        int number = 5;
        najmniejszeWspolne();

        char[][]tablicaKajak = new char[20][20];
        for(int i = 0; i < tablicaKajak.length; ++i) {
            for(int j = 0 ; j < tablicaKajak[i].length;++j) {
                tablicaKajak[i][j] = (char)(((Math.random())*('z'-'a')) + 'a');
            }
        }
        howMuchKajak(tablicaKajak);

    }


    public static void kwadrat(int number, char xOr0) {
        char[][] tab = new char[number][number];
        for(int i = 0; i < tab.length; ++i) {
            for(int j = 0; j < tab.length; ++j) {
                if (i == 0 && j < tab[i].length) {
                    if(j % 2 == 0 ) {
                        tab[i][j] = xOr0;
                    }else {
                        if(xOr0 == 'x') {
                            tab[i][j] = 'o';
                        }else
                            tab[i][j] = 'x';
                    }

                } else if (j == 0 && i < tab.length) {
                    if(i % 2 == 0 ) {
                        tab[i][j] = xOr0;
                    }else {
                        if(xOr0 == 'x') {
                            tab[i][j] = 'o';
                        }else
                            tab[i][j] = 'x';
                    }

                } else if (i == tab.length - 1 && j < tab[i].length) {
                    if(j % 2 == 0 ) {
                        tab[i][j] = xOr0;
                    }else {
                        if(xOr0 == 'x') {
                            tab[i][j] = 'o';
                        }else
                            tab[i][j] = 'x';
                    }

                } else if (i < tab.length && j == tab[i].length - 1) {
                    if(i % 2 == 0 ) {
                        tab[i][j] = xOr0;
                    }else {
                        if(xOr0 == 'x') {
                            tab[i][j] = 'o';
                        }else
                            tab[i][j] = 'x';
                    }

                } else
                    tab[i][j] = ' ';
            }
        }

        for(int i = 0; i < tab.length; ++ i) {
            for(int j = 0; j < tab.length; ++j) {
                System.out.print(tab[i][j]);
            }
            System.out.println();
        }
    }


    public static void jestJednastkowa(int[][] tablica) {
        boolean zera = true;
        boolean jedynki = true;
        boolean theSameNubmers = true;

            System.out.println("it has the same number of colums and lines");
            for(int i = 0; i < tablica.length; ++i) {
                for(int j = 0; j < tablica[i].length; ++j) {
                    if(tablica.length == tablica[i].length) {
                        theSameNubmers = false;
                    }else
                        theSameNubmers = true;
                    if(tablica[i][j] == 0 && i !=j ) {
                        zera = false;
                    }else zera = true;

                    if(tablica[i][j] == 1 && i == j) {
                        jedynki = false;
                    }else jedynki = true;
                }
            }



        if(jedynki && zera && theSameNubmers) {
            System.out.println("Tablica nie jest jednastkowa");
        }else
            System.out.println("Tablica jednastkowa");
    }

    public static void najmniejszeWspolne() {
        int tab[] = new int[20];
        int zmienna = 1;
        boolean go = true;
        for(int i = 0; i < tab.length;++i) {
            tab[i] = (int)(Math.random()*100);
        }
        for(int i = 0; i < tab.length/2;i+=2) {
            do {
                if(i != tab.length-1) {
                    if(zmienna%tab[i] == 0 && zmienna%tab[i+1] == 0 && tab[i] != 0 && tab[i+1] !=0) {
                        System.out.println(tab[i] + " " + tab[i+ 1] + " : " + zmienna);
                        go = false;
                    }else
                        ++zmienna;
                }
            }while (go);
        }
    }

    public static void howMuchKajak(char[][]tablica) {
        int count = 0;
        for(int i = 0; i < tablica.length; ++i) {
            if(tablica[i][i] == 'k' && i !=tablica.length-5) {
                if (tablica[i+1][i+1] == 'a' && tablica[i+2][i+2] == 'j' && tablica[i+3][i+3] == 'a' && tablica[i+4][i+4] == 'k') {
                    ++count;
                }
            }
            if(tablica[tablica.length-1 -i][i] == 'k' && i != tablica.length-5){
                if(tablica[tablica.length-1-i - 1][i + 1] == 'a' && tablica[tablica.length-1 -i - 2][i + 2] == 'j'&& tablica[tablica.length-1 -i - 3][i + 3] == 'a' && tablica[tablica.length-1 -i - 4][i + 4]=='k') {
                    ++count;
                }
            }
        }
        System.out.println("wystepuje " + count + " raz");
    }




}
