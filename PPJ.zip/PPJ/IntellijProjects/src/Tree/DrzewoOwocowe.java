package Tree;

public class DrzewoOwocowe extends DrzewoLisciaste {
    String nazwaOwoca;
    protected DrzewoOwocowe(boolean wiecznieZielone, int wysokosc, String przekrojDrzewa, int ksztaltLiscia, String nazwaOwoca) {
        super(wiecznieZielone, wysokosc, przekrojDrzewa, ksztaltLiscia);
        this.nazwaOwoca = nazwaOwoca;
    }

    public String toString () {
        return super.toString() + "Nazwa owoca : " + nazwaOwoca;
    }

    public void zerwijOwoc () throws DrzewoBezOwocoweException {
        System.out.println("Owoc");
    }
}
