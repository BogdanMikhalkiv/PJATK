package Tree;

public class DrzewoIglaste extends Drzewo {
    int iloscIgel;
    double dlugscSzyszki;


    protected DrzewoIglaste(boolean wiecznieZielone, int wysokosc, String przekrojDrzewa, int iloscIgel, double dlugscSzyszki) {
        super(wiecznieZielone, wysokosc, przekrojDrzewa);
        this.iloscIgel = iloscIgel;
        this.dlugscSzyszki = dlugscSzyszki;
    }

    public String toString () {
        return super.toString() + "Ilosc igel : " + iloscIgel + " Dlugosc Szyszki : " + dlugscSzyszki;
    }

    public void zerwijOwoc () throws DrzewoBezOwocoweException {
        super.zerwijOwoc();
    }
}
