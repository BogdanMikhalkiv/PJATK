package Tree;

public class DrzewoLisciaste extends Drzewo {
    int ksztaltLiscia;

    protected DrzewoLisciaste(boolean wiecznieZielone, int wysokosc, String przekrojDrzewa, int ksztaltLiscia) {
        super(wiecznieZielone, wysokosc, przekrojDrzewa);
        this.ksztaltLiscia = ksztaltLiscia;
    }


     public String toString () {
        return super.toString() + "Kstalt Liscia : " + ksztaltLiscia;
     }

    public void zerwijOwoc () throws DrzewoBezOwocoweException {
        super.zerwijOwoc();
    }
}
