package Tree;

public class DrzewoBezOwocoweException extends Exception {
    DrzewoBezOwocoweException(String s) {
        System.out.println(s);
    }
}
