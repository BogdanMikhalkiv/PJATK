package Tree;

public class Main {
    public static void main(String[] args) {
        Drzewo[] las = {
                new DrzewoIglaste(true,100,"czanre", 10,10d),
                new DrzewoLisciaste(false,150,"zielone",10),
                new DrzewoOwocowe(false,200,"cos",30,"Jabko")
        };

        for(int i = 0; i < las.length; ++i) {
            System.out.println(las[i].toString());
        }
    }
}
