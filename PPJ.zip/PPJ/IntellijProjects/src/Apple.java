public class Apple {
    public Apple(){

    }
}
