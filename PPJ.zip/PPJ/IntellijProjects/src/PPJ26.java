import java.io.FileInputStream;
import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class PPJ26 {
    public static void main(String[] args) {

        int helpfulInt;
        StringBuilder helpfulString = new StringBuilder();
        try {
            FileInputStream fis = new FileInputStream("Z:\\PPJ\\1.txt");
            while ((helpfulInt = fis.read()) != -1) {
                helpfulString.append((char) helpfulInt);
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
        System.out.println(helpfulString);

        //==============================================================

        Pattern p = Pattern.compile("[abc]+h");

        String[] str = {
            "aaaabbcch",
            "bbaaaacch",
            "ccaaacch",
            "bbaaaabbh",
            "abch",
        };

        for(int i = 0; i < str.length; ++i) {
            Matcher m = p.matcher(str[i]);
            if(m.find()) {
                System.out.println(str[i]);
            }
        }
        //==============================================================================

        helpfulString = new StringBuilder("       Ala.,         ma kota");

        Pattern p2 = Pattern.compile("\\w+");
        Matcher m = p2.matcher(helpfulString);
        int count = 0;

        while(m.find()) {
            count++;
        }
        System.out.println(count);

        //==============================================================================

        String string3 = "wieś w Polsce położona w województwie wielkopolskim, w powiecie\n" +
                "kolskim, w gminie Olszówka. W latach 1975-1998 miejscowość położona była w województwie\n" +
                "konińskim.";



        Pattern p3 = Pattern.compile("\\d+\\W\\d+");
        Matcher m3 = p3.matcher(string3);
        int count3 = 0;
        while (m3.find()) {
            count3++;
        }
        System.out.println(count3);
    }
}
