public class B {
    B(){
        System.out.println(this);
    }

    public static void staticShowThis(){
        System.out.println(new B());
    }

    public void nStaticShowThis() {
        System.out.println(this);
    }
}
