package GUI05;

import java.util.ArrayList;

public class Box <T extends Comparable> extends ArrayList<T> {

    @Override
    public boolean add(T elm) {
        if (!contains(elm)) {
            super.add(elm);
            return true;
        }else {
            return false;
        }
    }

    boolean addAll (T[] elmTab) {
        boolean isSuccessful = true;
        for (int i = 0; i < elmTab.length; ++i) {
            if (!this.contains(elmTab[i])) {
                add(elmTab[i]);
            }else
                isSuccessful = false;
        }

        return isSuccessful;
    }

    boolean delete (T elm) {
        return super.remove(elm);
    }

    void swap (int pos1, int pos2) {
        if (super.get(pos1) != null && super.get(pos2) != null) {
            T helpfulT = super.get(pos1);
            super.set(pos1,super.get(pos2));
            super.set(pos2,helpfulT);
        }
    }

    public T min() {
        T min = super.get(0);
        for (int i = 1; i < super.size(); ++i) {
            if (min.compareTo(super.get(i)) <= 0) {
                min = super.get(i);
            }
        }
        return min;
    }

    public T max() {
        T max = super.get(0);
        for (int i = 1; i < super.size(); ++i) {
            if (max.compareTo(super.get(i)) >= 0) {
                max = super.get(i);
            }
        }
        return max;
    }

    public boolean search (T elm) {
        return super.contains(elm);
    }

    public void print() {
        this.forEach(t -> System.out.println(t.toString()));
    }
}
