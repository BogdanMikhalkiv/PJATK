package GUI05.OsobaPac;

public class Osoba implements Comparable {
    protected String nazwisko;
    protected int wiek;

    public Osoba(String nazwisko, int wiek) {
        this.nazwisko = nazwisko;
        this.wiek = wiek;
    }

    @Override
    public int compareTo(Object o) {
        if (this.nazwisko.compareTo(((Osoba) o).nazwisko) == 0) {
            return this.wiek - ((Osoba) o).wiek;
        }else
            return this.nazwisko.compareTo(((Osoba) o).nazwisko);
    }

    @Override
    public String toString() {
        return "Osoba{" +
                "nazwisko='" + nazwisko + '\'' +
                ", wiek=" + wiek +
                '}';
    }
}
