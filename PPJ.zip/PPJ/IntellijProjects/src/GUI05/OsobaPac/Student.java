package GUI05.OsobaPac;

public class Student extends Osoba implements Comparable {
    int numerGrupy;
    public Student(String nazwisko, int wiek, int numerGrupy) {
        super(nazwisko, wiek);
        this.numerGrupy = numerGrupy;
    }

    @Override
    public int compareTo(Object o) {
        if (super.compareTo(o) == 0) {
            return this.numerGrupy - ((Student)o).numerGrupy;
        }else
            return super.compareTo(o);
    }

    @Override
    public String toString() {
        return super.toString() + "numer grupy: " + numerGrupy;
    }
}
