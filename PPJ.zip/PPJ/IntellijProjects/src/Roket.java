import java.io.IOException;

public class Roket {
    String name;
    int oilWeight;

    public Roket(String name){
        this.name = name;
        try {
            start(getOil());
        }catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public int getOil() {
        return oilWeight = (int)(Math.random()*100);
    }

    public void start(int oilWeight) throws Exception {
        if(oilWeight < 1000) {
            throw new Exception("you dont have enough oil to start!");
        }else {
            System.out.println("STARTING ENGINE");
        }
    }

}
