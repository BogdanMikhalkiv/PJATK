public class Dzem {
    private String smak;
    private double waga;

    Dzem(String smak, double waga) {
        this.smak = smak;
        this.waga = waga;
    }

    Dzem(double waga) {
        this("no name", waga);

    }
    Dzem(String smak) {
        this(smak,100.0);
    }
}
