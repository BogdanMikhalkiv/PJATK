public class Osoba {

    public String imie;
    public String nazwisko;
    public int urodzenia;

    public Osoba(String imie, String nazwisko, int urodzenia){
        this.imie = imie;
        this.nazwisko = nazwisko;
        this.urodzenia = urodzenia;
    }

    public void out(){
        System.out.println("Imie : " + imie + ". Nazwisko : " + nazwisko + ". Urodzenia : " + urodzenia);
    }
}
