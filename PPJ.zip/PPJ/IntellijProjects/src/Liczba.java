public class Liczba {
    int number;


    public void przypiszWartosc(int number) {
        this.number = number;
    }

    public void wyswietlWartosc() {
        System.out.println("liczba is " + number);
    }
}
