public class Walec {
    int promien;
    int wysokosc;

    Walec(int promien, int wysokosc){
        this.promien = promien;
        this.wysokosc = wysokosc;
    }

    public void show() {
        System.out.println("obietnosc walca : " + (3.14 * Math.pow(promien,2)*wysokosc));
        System.out.println("pole powierzchni podstawy : " + (3.14 * Math.pow(promien,2)));
    }
}
