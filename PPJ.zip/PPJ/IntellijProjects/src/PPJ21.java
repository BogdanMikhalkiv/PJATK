import java.io.*;

public class PPJ21 {
    public static void main(String[] args) {
        /*int[] tab = new int[10];
        System.out.println("start");
        try{
            tab[15] = 5;
        }catch (ArrayIndexOutOfBoundsException ex) {
            ex.printStackTrace();
        }
        System.out.println("koniec");

        //=================================================================

        System.out.println("Start");
        try {
            FileInputStream fis = new FileInputStream("C:\\1.txt");
        }catch (IOException ex) {
            ex.printStackTrace();
        }
        System.out.println("koniec");

        //==================================================================

        try{
            throwArrayOutOfException();
            throwFileNotFoundException();
            throwException();
        }catch (ArrayIndexOutOfBoundsException aiox){
            aiox.printStackTrace();
        }catch (FileNotFoundException fnx) {
            fnx.printStackTrace();
        }catch (Exception ex) {
            ex.printStackTrace();
        }

        //===================================================================

        try{
            int helpfullInt;
            String line = "";
            FileInputStream input = new FileInputStream("C:\\Users\\s17505\\Desktop\\PPJ\\TEST\\ppj20.txt");
            while ((helpfullInt = input.read()) != -1){
                line += (char)helpfullInt;
            }
            System.out.println(line);
            input.close();
        }catch (IOException ex) {
            ex.printStackTrace();
        }
    */

        try {

            int number = 0;
            int helpfulInt;
            StringBuilder line = new StringBuilder();
            char stop = ',';
            FileInputStream inputStream = new FileInputStream("C:\\Users\\s17505\\Desktop\\PPJ\\TEST\\pierwsze.txt");
            while ((helpfulInt = inputStream.read()) != -1) {
                line.append((char) helpfulInt);
            }



            char[] charArray = line.toString().toCharArray();
            StringBuilder helpfulString = new StringBuilder();
            for(int i = 0; i < charArray.length;++i){
                if(charArray[i] != stop){
                    helpfulString.append(charArray[i]);
                }else {
                    number = Integer.parseInt(helpfulString.toString());

                    if(prime(number)){
                        System.out.println(number + " LICZBA PIERWSZA");
                    }
                    number = 0;
                    helpfulString = new StringBuilder();
                }
            }


        }catch (IOException ex){
            ex.printStackTrace();
        }

    }

    public static void throwArrayOutOfException() throws Exception {
        throw new ArrayIndexOutOfBoundsException("Array out of its length");
    }


    public static void throwFileNotFoundException() throws Exception {
        throw new FileNotFoundException("File not found!");
    }

    public static void throwException() throws Exception {
        throw new Exception("zla jednostka");
    }

    public static boolean prime(int n)
    {
        if (n>2)
        {
            double sq = Math.sqrt(n);
            if(n%2==0)
                return false;
            else
            {
                for(int i=3; i<=sq; i+=2)
                {
                    if(n%i==0)
                    {
                        return false;
                    }
                }
                return true;
            }
        }
        else if (n==2) return true;
        return false;
    }



}
