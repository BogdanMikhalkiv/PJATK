public class Sloik {
    Dzem dzem;
    boolean otwurz;
    boolean czyOtwarty ;
    boolean zamknij;

    Sloik(Dzem dzem) {
        otwurz = otwurz();
        if(otwurz) {
            this.dzem = dzem;
            czyOtwarty = czyOtwarty();
            if(czyOtwarty) {
                zamknij = zamknij();
            }
        }

    }

    public boolean otwurz() {
        if(zamknij) {
            return true;
        }
        else return false;

    }
    public boolean zamknij() {
        if(czyOtwarty){
            otwurz = false;
            czyOtwarty = false;
            return true;
        }
        else return false;
    }
    public boolean czyOtwarty() {
        if(otwurz) {
            return true;
        }else
            return false;
    }
}
