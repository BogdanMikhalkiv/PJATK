public class PPJ19 {
    public static void main(String args[]) {
        Owoc owoc = new Owoc(2, "red");
        owoc.toString(owoc);


        Dzem dzem1 = new Dzem("slodki", 150.0);
        Dzem dzem2 = new Dzem("nieSlodki");
        Dzem dzem3 = new Dzem(12.0);
    }
}
