
public class CookieFactory {
    static Ciastko[] cookies = new Ciastko[100];

    public static Ciastko makeCookies(int jamNumber){
        if (cookies[jamNumber] == null) {
            String jam;
            switch (jamNumber) {
                case 1:
                    jam = "Strawberry";
                    break;
                case 2:
                    jam = "Cherry";
                    break;
                case 3:
                    jam = "Peach";
                    break;
                default:
                    //scanner -> dzem
                    jam = "";
            }
            cookies[jamNumber] = new Ciastko(new Dzem(jam),0);

        }
        return cookies[jamNumber];
    }

}
