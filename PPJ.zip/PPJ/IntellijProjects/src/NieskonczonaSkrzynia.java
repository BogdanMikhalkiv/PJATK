

public class NieskonczonaSkrzynia {
    Apple[] apples = new Apple[1];
    int numerOfApples = 0;



    public void addApple(Apple newApple){
        Apple[] helpflApple = new Apple[apples.length+1];

        for(int i = 0; i < helpflApple.length; ++i){
            helpflApple[i] = apples[i];
        }

        apples = helpflApple;

        apples[apples.length-1] = newApple;
        ++numerOfApples;

    }

    public Apple getFirstApple() throws  SkrzynkaException{

        if(apples[numerOfApples - (numerOfApples - 1)] != null){
            return apples[numerOfApples - (numerOfApples - 1)];
        }else {
            throw new SkrzynkaException("No apple found");
        }
    }

    public Apple getAppleByIndex(int index) throws SkrzynkaException{
        if(index > numerOfApples - 1 || index < 0) {
            throw new SkrzynkaException("YOU DON`T HAVE AN APPLE");
        }else {
            Apple newap = apples[index];
            apples[index]=null;
            return newap;
        }

    }

    public int getNumerOfApples(){
        return numerOfApples;
    }

}


