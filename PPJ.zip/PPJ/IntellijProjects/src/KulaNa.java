public class KulaNa {
    int radius;

    KulaNa(Walec walec) {
        if(walec.promien == walec.wysokosc) {
            this.radius = (int)(walec.promien / Math.sqrt(2));
        }
    }

    KulaNa(Kwadrat kwadrat) {
        this.radius = (int)(kwadrat.bok / Math.sqrt(2));
    }
}
