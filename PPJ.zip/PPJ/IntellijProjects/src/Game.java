import java.util.Objects;
import java.util.Scanner;
public class Game {

    public static void main(String args[]) {
        Scanner in = new Scanner(System.in);
        boolean playAgain;
        String decision;
        System.out.println("Developed by Anton Katyrenchuk \n");
        do {
            String[][] gameMatrix = createMatrix(1, 1);
            int iPosition = randomIPositionNumber(gameMatrix);
            int iSecondPosition = randomIPositionNumber(gameMatrix);
            int jPosition = randomJPositionNumber(gameMatrix);
            int jSecondPosition = randomJPositionNumber(gameMatrix);
            String view = "a";
            String dollar = "$";
            String move;
            char[] charArray;
            boolean isGameRunning = true;
            boolean check;
            gameMatrix[iPosition][jPosition] = view;
            gameMatrix[iSecondPosition][jSecondPosition] = dollar;
            matrixOut(gameMatrix);
            System.out.println("The game is very easy to play. To move in different direction use W(up) S(down) A(left) D(right). Just enter the letter u need and press 'ENTER'. \n You are 'a'. When you eat a DOLLAR ( $ ) you become 'b' and so on.. To exit from the game type 'exit'.\n The game will Finish when u become 'z' \n Now enter your direction, have fun! ");
            do {

                move = in.nextLine();
                move = move.toLowerCase();
                clearScreen();
                gameMatrix = moveChar(gameMatrix, move, iPosition, jPosition, view);
                switch (move) {
                    case "w":
                        if (iPosition - 1 != 0) {
                            --iPosition;
                        }
                        break;
                    case "s":
                        if (iPosition + 1 != gameMatrix.length - 1) {
                            ++iPosition;
                        }
                        break;
                    case "a":
                        if (jPosition - 1 != 0) {
                            --jPosition;
                        }
                        break;
                    case "d":
                        if (jPosition + 1 != gameMatrix[gameMatrix.length - 1].length - 1) {
                            ++jPosition;
                        }
                        break;
                }

                if (Objects.equals(gameMatrix[iPosition][jPosition], gameMatrix[iSecondPosition][jSecondPosition])) {
                    do {
                        iSecondPosition = randomIPositionNumber(gameMatrix);
                        jSecondPosition = randomIPositionNumber(gameMatrix);
                        gameMatrix[iSecondPosition][jSecondPosition] = dollar;
                        check = Objects.equals(gameMatrix[iSecondPosition][jSecondPosition], gameMatrix[iPosition - 1][jPosition]) ||
                                Objects.equals(gameMatrix[iSecondPosition][jSecondPosition], gameMatrix[iPosition + 1][jPosition]) ||
                                Objects.equals(gameMatrix[iSecondPosition][jSecondPosition], gameMatrix[iPosition][jPosition + 1]) ||
                                Objects.equals(gameMatrix[iSecondPosition][jSecondPosition], gameMatrix[iPosition][jPosition - 1]) ||
                                Objects.equals(gameMatrix[iPosition][jPosition], gameMatrix[iSecondPosition][jSecondPosition]);
                        if (check) {
                            gameMatrix[iSecondPosition][jSecondPosition] = " ";
                        }
                    } while (check);

                    charArray = view.toCharArray();
                    charArray[0] = (char) (charArray[0] + 1);
                    view = new String(charArray);
                    gameMatrix[iPosition][jPosition] = view;
                    if (Objects.equals(gameMatrix[iPosition][jPosition], "z")) {
                        isGameRunning = false;
                    }
                }


                if (Objects.equals(move, "exit")) {
                    isGameRunning = false;
                } else {
                    matrixOut(gameMatrix);
                }
            } while (isGameRunning);
            System.out.println();
            System.out.println("Game Over! \n If you want to play again press ANY KEY, if you want to exit press ' exit '");
            decision = in.nextLine();
            switch (decision) {
                case "exit" : playAgain = false;
                    break;
                default: playAgain = true;
            }

        }while (playAgain);
    }

    public static int randomIPositionNumber(String[][] matrix) {
        int n;
        n = (int) (((Math.random() * (matrix.length - 3)) + 2));
        return n;
    }

    public static int randomJPositionNumber(String[][] matrix) {
        int n;
        n = (int) ((Math.random() * (matrix[matrix.length - 4].length - 4)) + 3);
        return n;
    }

    public static String[][] createMatrix(int a, int b) {
        String[][] matrix = new String[a][b];
        for (int i = 0; i < matrix.length; ++i) {
            for (int j = 0; j < matrix[i].length; ++j) {
                if (i == 0 && j < matrix[i].length) {
                    matrix[i][j] = "#";
                } else if (j == 0 && i < matrix.length) {
                    matrix[i][j] = "#";
                } else if (i == matrix.length - 1 && j < matrix[i].length) {
                    matrix[i][j] = "#";
                } else if (i < matrix.length && j == matrix[i].length - 1) {
                    matrix[i][j] = "#";
                } else
                    matrix[i][j] = " ";
            }
        }
        return matrix;
    }

    public static void matrixOut(String[][] argumentMatrix) {
        for (int i = 0; i < argumentMatrix.length; ++i) {
            for (int j = 0; j < argumentMatrix[i].length; ++j) {
                System.out.print(argumentMatrix[i][j]);
            }
            System.out.println();
        }
    }

    public static String[][] moveChar(String[][] matrix, String move, int iPosition, int jPosition, String view) {

        switch (move) {
            case "w":
                if (iPosition - 1 != 0) {
                    matrix[iPosition][jPosition] = " ";
                    matrix[iPosition - 1][jPosition] = view;
                }

                break;
            case "s":
                if (iPosition + 1 != matrix.length - 1) {
                    matrix[iPosition][jPosition] = " ";
                    matrix[iPosition + 1][jPosition] = view;
                }
                break;
            case "a":
                if (jPosition - 1 != 0) {
                    matrix[iPosition][jPosition] = " ";
                    matrix[iPosition][jPosition - 1] = view;
                }
                break;
            case "d":
                if (jPosition + 1 != matrix[matrix.length - 1].length - 1) {
                    matrix[iPosition][jPosition] = " ";
                    matrix[iPosition][jPosition + 1] = view;
                }
                break;
        }
        return matrix;
    }


    public static void clearScreen() {
        for(int i = 0; i < 26; ++i) {
            System.out.println();
        }
    }

}

