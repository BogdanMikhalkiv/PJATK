public class SkrzynkaException extends Exception {

    SkrzynkaException(String s){
        System.out.println(s);
    }
}
