public class Ciastko  {
    Dzem taste;
    double weight;

    public Ciastko(Dzem taste, double weight){
        this.taste = taste;
        this.weight = weight;
        this.show();
    }

    public void show(){
        System.out.println("Taste is " + taste + ", Weight is " + weight);
    }
}
