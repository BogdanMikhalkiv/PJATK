public class PPJ16 {
    public static void main(String args[]) {
        int a = 1;
        float b = 1f;
        char c = 'a';
        byte e = 12;

        MethodCarrier object = new MethodCarrier();
        object.setValue(a);
        object.setValue(b);
        object.setValue(c);
        object.setValue(e);

        Liczba number = new Liczba();
        number.przypiszWartosc(15);
        number.wyswietlWartosc();
        object.setValue(number);
        number.wyswietlWartosc();

        Osoba osoba = new Osoba("Yaroslaw" , "Chuiev" , 15);
        osoba.out();


    }



}





