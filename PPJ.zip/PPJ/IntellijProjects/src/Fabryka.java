public class Fabryka {
    double waga;

    Fabryka() {
        this.waga = 0;
    }


    public Sloik[] pryjmij(Owoc owoc) {
        Sloik[] sloik = new Sloik[10];
            waga = waga + owoc.waga;
            if(waga > 10000.0){
                Dzem dzem = new Dzem("slodki", 10.0);
                for(int i = 0; i <=10; ++i) {
                    sloik[i] = new Sloik(dzem);
                }
                return sloik;
            }else
                return null;
    }
}
