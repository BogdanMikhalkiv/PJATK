package PPJ20;

public class Samochod extends Pojazd {
    int vin;
    int iloscDrzwi;

    public Samochod (int vin, int iloscDrzwi , String marka) {
        super(marka);
        this.iloscDrzwi = iloscDrzwi;
        this.vin = vin;
    }

   public String wyswietli () {
        return  "vin - " + vin + " " + "ilosc drzwi - " + iloscDrzwi + super.wyswietli();
    }
}
