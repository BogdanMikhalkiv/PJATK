package PPJ20;

public class Spawacz {
}
