package PPJ20;

public class Punkt3D extends Punkt2D {
    int z;
    public Punkt3D (int x , int y , int z) {
        super(x,y);
        this.z = z;
    }

    public void odleglosc ( Punkt3D punkt3D) {
        double g = Math.pow((x - punkt3D.x),2) +  Math.pow((y - punkt3D.y),2) +  Math.pow((z - punkt3D.z),2);
        System.out.println(Math.sqrt(g));
    }
}
