package PPJ20;

public class Osoba {
    private String imie;
    private int rokurodzenia;

    public Osoba (String imie , int rokurodzenia) {
        this.imie = imie;
        this.rokurodzenia = rokurodzenia;
    }
}
