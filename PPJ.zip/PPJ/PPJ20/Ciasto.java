package PPJ20;

public class Ciasto {
    String nazwa;
    double masa;
    int kodProduktu;

    public Ciasto (String nazwa, double masa, int kodProduktu) {
        this.masa = masa;
        this.kodProduktu = kodProduktu;
        this.nazwa = nazwa;
    }

    public String toString () {
        String informacja = "Nazwa " + nazwa + " " + "Masa" + masa + " " + "kod prod - " + kodProduktu;
        return informacja;
    }
}
