package PPJ20;

public class Punkt2D {
    int x,y;
    public Punkt2D (int x , int y) {
        this.x = x;
        this.y = y;
    }
    public void odleglosc ( Punkt2D punkt2D) {
        double g = Math.pow((x - punkt2D.x),2) +  Math.pow((y - punkt2D.y),2) ;
        System.out.println(Math.sqrt(g));
    }
}
