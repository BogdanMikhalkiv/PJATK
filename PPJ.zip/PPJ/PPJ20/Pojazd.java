package PPJ20;

public class Pojazd   {
  private String marka;
    public Pojazd (String marka) {
        this.marka = marka;
    }

    public String wyswietli () {
        return " marka" + marka;
    }

}
