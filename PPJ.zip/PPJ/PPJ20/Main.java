package PPJ20;

public class Main {
    public static void main(String[] args) {
        Ciasto ciasto = new Ciasto("Ciasto", 20,8);
        System.out.println( ciasto);

        Samochod samochod = new Samochod(10,100,"ad");
        System.out.println(samochod);

        Punkt3D p3 = new Punkt3D(1,2,3);
        Punkt3D p4 = new Punkt3D(5,6,7);
        Punkt2D punkt2D = new Punkt2D(1,2);

    }
}
