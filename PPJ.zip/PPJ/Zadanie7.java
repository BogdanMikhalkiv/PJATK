public class Zadanie7 {
	public static void main(String[] args) {
	int x = 2 *(((5 + 3) * 4) - 8);
	System.out.println(x);
	
	}
}