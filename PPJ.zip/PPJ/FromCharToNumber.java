public class FromCharToNumber {
	public static void main(String[] args) {
	java.util.Scanner in = new java.util.Scanner(System.in);
	System.out.println("Enter your letter code");
	int litera = in.nextInt();
	System.out.println("your letter is" + (char) litera + " code is " + litera);
	char chr = (char)litera;
	System.out.println("Byte cod is : ");
	System.out.print( (chr & (1 << 8)) >> 8);
	System.out.print( (chr & (1 << 7)) >> 7);
	System.out.print( (chr & (1 << 6)) >> 6);
	System.out.print( (chr & (1 << 5)) >> 5);
	System.out.print(' ');
	System.out.print( (chr & (1 << 4)) >> 4);
	System.out.print( (chr & (1 << 3)) >> 3);
	System.out.print( (chr & (1 << 2)) >> 2);
	System.out.print( (chr & (1 << 1)) >> 1);
	System.out.print( (chr & (1 << 0)) >> 0);
	System.out.println();
	}
}