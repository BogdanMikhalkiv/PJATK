package PPJ22;

public class DebetCard  {

    public void metod (double d, Account account) throws NoutEnoughFunds {
        if (d > account.dailyDebet) {
            throw  new NoutEnoughFunds("price > od limitu");
        }
        if (d > account.balance) {
            throw new NoutEnoughFunds("niedostno srodkow ");
        } else {
            account.balance -= d;
            System.out.println(account.balance);
        }
    }
}
