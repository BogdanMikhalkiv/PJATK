package PPJ22;

import javax.imageio.IIOException;
import java.io.*;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;

public class Main2 {
    public static void main(String[] args) throws IOException {
//        FileReader fileReader = new FileReader("serverLog.txt");
//        StringBuilder stringBuilder = new StringBuilder();
//        int tmp = fileReader.read();
//        while (tmp != -1) {
//            stringBuilder.append((char) tmp);
//            tmp = fileReader.read();
//        }
//        fileReader.close();
//        System.out.println(stringBuilder);
        File input = new File("serverLog.txt");
        File output = new File("2.txt");

        try {
            Files.copy(input.toPath(), output.toPath());
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}
