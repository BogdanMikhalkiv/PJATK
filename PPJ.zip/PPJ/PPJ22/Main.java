package PPJ22;

public class Main {
    public static void main(String[] args) {
        Account account = new Account();
        try {
            account.mymethod(3000);
        } catch (NoutEnoughFunds noutEnoughFunds) {
            noutEnoughFunds.printStackTrace();
        }
        try {
            account.mymetod2(20000);
        } catch (NoutEnoughFunds noutEnoughFunds) {
            noutEnoughFunds.printStackTrace();
        }
    }
}
