package PPJ22;

public class NoutEnoughFunds extends Exception {
    public NoutEnoughFunds (String msg) {
        super(msg);
    }
}
