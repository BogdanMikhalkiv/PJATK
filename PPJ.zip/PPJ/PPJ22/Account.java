package PPJ22;

public class Account {
    double balance = 2000;
    double dailyDebet = 3000;
    double credit = 140;
    DebetCard debetCard = new DebetCard();
    CreditCard creditCard = new CreditCard();


    public void mymethod ( double d) throws NoutEnoughFunds {
        debetCard.metod(d, this);
    }
    public void mymetod2 ( double d) throws  NoutEnoughFunds {
        creditCard.methoda(d,this);
    }
}
