package PPJ22;

public class CreditCard  {
    public void methoda (double d, Account account) throws NoutEnoughFunds {
        if (d > account.balance ) {
            throw  new NoutEnoughFunds("niedostatno");
        } else {
            account.balance -= d;
            System.out.println(account.balance);
        }
    }
}
