public class PPJ1 {
	public static void main (String [] args) {
		System.out.println("Hello World!");
		int i = 0b0010;
		int j = 0b0101;
		System.out.println(i);
				System.out.println(j);
	}
}