package PPJ21;

import java.util.Random;

public class Main {
    public static void main(String[] args) {
//        DetektorDymu detektorDymu = new DetektorDymu();
//        boolean b = false;
//        while (!b) {
//            try {
//                detektorDymu.sprawdz();
//            } catch (Alarm alarm) {
//                alarm.printStackTrace();
//                b = true;
//            }
//        }

        int tab[][] = new int[3][3];
        Random random = new Random();
        for (int i = 0; i < tab.length; i++) {
            for (int j = 0; j < tab[i].length; j++) {
                tab[i][j] = random.nextInt(5);
            }
        }
        for (int i = 0; i < tab.length; i++) {
            for (int j = 0; j < tab[i].length; j++) {
                System.out.print(tab[i][j]);
            }
            System.out.println();
        }
        System.out.println();
        Main.fill(tab);
    }
    public static void fill (int[][] tab) {
        for (int i = 0 , x = 0; i < tab.length; i++) {
            for (int j = 0; j < tab[i].length; j++) {

                if ( i != j && tab[i][j] > 0) {
                    x++;

                    if (x == 1) {
                        System.out.println("tablica nie - ");
                    }
                    System.out.println( "[ " + i + ", " + j + " ]");

                }

            }
        }
    }
}
