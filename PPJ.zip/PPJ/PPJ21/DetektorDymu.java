package PPJ21;

public class DetektorDymu {



    public void sprawdz() throws Alarm {
      if (Math.random() < 0.2) {
          throw  new Alarm("dym");
      }
        System.out.println("ok");
    }

}
