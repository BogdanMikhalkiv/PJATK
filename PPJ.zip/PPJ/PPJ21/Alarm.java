package PPJ21;

public class Alarm extends Exception {
   public Alarm(String msg) {
       super(msg);
   }
}
