public class PPJ6 {
	public static void main ( String [] args ) {
		//==========1==========
		byte k = (byte)170;
		if(k % 2== 0 ) {
			System.out.println("parzysta");
		} else {
			System.out.println("nieparzysta");
		}
		System.out.println(k % 2 == 0 && k == 1);
		
		//===========2=========
		double a = Math.random() * 1;
		double b = Math.random() * 1;
		double c = Math.random() * 1;
		double d = Math.random() * 1;
		double e = Math.random() * 1;
		
		if (c > 0.2 && d > 0.2 && e > 0.2 ) {
			System.out.println("tak, jest wieksza");
		} else {
				System.out.println("nie");
		}
		
		//==========5============
		byte x = -20;
		short y = -11;
		int z = -21;
		int wrt = -1;
		
		if ( wrt >= x && wrt <= -10 || wrt >= -5 && wrt <=0 || wrt >= 5 && wrt <=10) {
			System.out.println("Zawiera");
		} else {
			System.out.println("nie zawiera");
		}
		
		
	}
	
}