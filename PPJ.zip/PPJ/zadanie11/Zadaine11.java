public class Zadaine11 {
	public static void main(String args[]) {
		char[] tab = {'a','b','c','e','f'};
		for(int i = 0; i < tab.length; ++i) {
			if(i == tab.length - 1) {
				System.out.println(tab[i-1] + " " + tab[i] + " " + tab[0]);
			} else if (i == 0) {
				System.out.println(tab[i + tab.length-1] + " " + tab [i] + " " + tab[i +1]);
			}else
				System.out.println(tab[i - 1] + " " + tab[i] + " " + tab[i+1]);
		}
	
		int tab1 [] = new int [20];
		for(int i = 0; i < tab1.length; ++i) {
			tab1[i] = (int) (Math.random()*100);
			if (i == 0) {
				if (tab1[i + tab1.length-1] > tab1[i] && tab1[i] < tab1[i + 1]) {
					System.out.println("index " + i);
				}
			}else if (i == tab1.length-1) {
					if(tab1[0] > tab1[tab1.length-1] && tab1[tab1.length-1] < tab1[tab1.length-2]) {
						System.out.println("index " + i);
					}
				} else {
					if(tab1[i] < tab1[i + 1] && tab1[1] < tab1[i-1]) {
						System.out.println("index " + i);
					}
				}
		}
	
		char tblicaChar [] = new char[25];
		for(int i = 0; i < tblicaChar.length; ++i) {
			tblicaChar[i] = (char) ((((int)Math.random()) + 'A') * 'Z'); 
		}
		char tblicaChar2 [] = new char[tblicaChar.length];
		for(int i = 0; i < tblicaChar2.length; ++i) {
			tblicaChar2[i] = tblicaChar[tblicaChar.length - 1 - i];
		}
		
		
		
		
		
		
		double tablicaDouble [] = new double [10];
		for (int i = 0; i < tablicaDouble.length; ++i) {
			tablicaDouble[i] = ((Math.random() * 10) - 10);
		
		}
		for(int i = 0; i < tablicaDouble.length; ++i) {
			if (i == 0) {
				System.out.println("Pierwszy element.");
				for (int j = 0; j < (tablicaDouble.length - 1 - i); ++j) {
						if (j > i && tablicaDouble[j] > tablicaDouble[i]) {
							System.out.println("Wartosc " + tablicaDouble[j] + "index : " + j);
						
					}
			}else if (i == tablicaDouble.length-1) {
				System.out.println("Ostatni element.");
			} else {
					for (int j = 0; j < (tablicaDouble.length - 1 - i); ++j) {
						if (j > i && tablicaDouble[j] > tablicaDouble[i])
							System.out.println("Wartosc " + tablicaDouble[j] + "index : " + j);
						
					}
					for (int g = 0; g < (tablicaDouble.length ) - (tablicaDouble.length - i); ++g) {
						if (tablicaDouble[g] < tablicaDouble[i] && g < i)
							System.out.println("Wartosc " + tablicaDouble[g] + "index : " + g);
					
					}
				}
			
			}
		}
		
		
		
		
		int [][] tab5 = {
			{1,0,0,0,0},
			{0,1,0,0},
			{0,0,1}
		};
		
		int [] tab11 = new int[tab5.length];
		for (int i = 0; i < tab5.length; ++i) {
			for(int j = 0; j < tab5[i].length; ++j)
				tab11 [i * tab5.length-1 - j];
		}
		for(int i = 0; i < tab11.length; ++ i)
			System.out.println(tab11[i]);
		
		
		
		
		
	}








}