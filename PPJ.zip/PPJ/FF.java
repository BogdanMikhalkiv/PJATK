public class FF {
public static void main(Stirng[] args){
	float flt = 1234,234f;
	float flt1 = flt + db1 ;
	long lng = 123451461451345L;
	int number - 12;
	int number1 = number + letter;
	char letter = 'f';
	char letter1 = letter + number;
	byte bt = 134;
	byte b1 = b1 + number;
	double dbl = 123,123;
	
	System.out.prntln(letter1);
	System.out.prntln(number1);
	System.out.prntln(flt);
	System.out.prntln(b1);
	}
}