package PPJ19;

public class Computer  extends Calculator{
    public Computer (String s) {
        super(s);
    }

    public  String calculate (double x , double y) {

        return super.calculate(x,y) + " " + x * y + " " + x / y + "";

    }

}
