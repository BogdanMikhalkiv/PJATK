package PPJ19;

public class CalculatingMachin {
    private String s ;

    public CalculatingMachin (String s) {
        this.s = s;
    }

    public String calculate (double x, double y) {
        return x + y + "" + " ";
    }

    public static  void printRes (CalculatingMachin[] a , double x, double y){
        for (int i = 0; i < a.length; i++) {
            System.out.println( a[i] +  a[i].calculate(x, y));
        }
    }

    public String toString () {
        return s + ":";
    }

}
