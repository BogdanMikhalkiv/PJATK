package PPJ19;

public class Main {
    public static void main(String[] args) {
//        CalculatingMachin[] arr = {
//                new Computer("Gray"),
//                new CalculatingMachin("Abacus"),
//                new Calculator("HP")
//        };
//        CalculatingMachin.printRes(arr,21,7);

        Person p = new Person("Bogdan", 2001);
        System.out.println(p);
        Student.printStudentsInfo();
        Student s = new Student("Pit", 2000);
        Student s1 = new Student(p);
        System.out.println(s);
    }
}
