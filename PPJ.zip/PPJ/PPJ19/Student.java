package PPJ19;

public class Student  extends Person{
   static int counter = 0;
 static   Student [] students = new Student[100];
   double avg;

   public  Student ( String name , int age) {
       super(name, age);
       avg = 0;
       if (counter < students.length){
           students[counter] = new Student(super(name,age));
           counter++;
       }
   }
 public Student (Person p ) {
       super(p);
 }

   public static void printStudentsInfo() {
       for (int i = 0; i <students.length ; i++) {
           if (counter == 0) {
               System.out.println("There are no students");
           } else {
               System.out.println("There is" + counter + "student: " + students[i]);
           }
       }
   }

    public String toString () {
        return super.toString() + " " + "avg: " +  avg + "";
    }
}
