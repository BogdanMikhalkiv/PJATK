package PPJ19;

import java.time.Year;

public class Person {
    private String name;
    int age;
    public Person (String name, int age) {
        this.name = name;
        this.age = age;
    }
    public Person (Person p) {
        this.name = p.name;
        this.age = p.age;
    }


    public String toString () {
        return "name: " + name + ", " + "age: " + (2019 - age);
    }
}
