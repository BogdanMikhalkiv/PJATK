package PPJ19;

public class Calculator extends  CalculatingMachin {
    public Calculator (String s) {
        super(s);
    }

    public String calculate (double x , double y) {
        return super.calculate(x, y) + (x - y + "");
    }

}



