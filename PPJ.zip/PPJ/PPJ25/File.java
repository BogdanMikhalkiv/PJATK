import java.io.FileReader;
import java.io.FileWriter;
import java.util.Scanner;

public class File {
    public static void main(String[] args) throws Exception {
        FileReader fr = new FileReader("serverLog.txt");

        String str = "";//первый вариант----------------------------------------------------------
        Scanner scan = new Scanner(fr);
        String reverse = "";
        while (scan.hasNextLine()){
            str += scan.nextLine() + "\n";
        }
        reverse = new StringBuffer(str).reverse().toString();

        int tmp = fr.read();//второй вариант----------------------------------------------------------
        StringBuilder st = new StringBuilder();
        while (tmp != -1){
            st.append((char) tmp);
            tmp = fr.read();
        }
        fr.close();
        //---------------------------------------------------------------------------------------------
        FileWriter fileReader = new FileWriter("1.txt");
        fileReader.write(st.reverse() + "");
        fileReader.write(reverse);
        fileReader.close();

    }
}
