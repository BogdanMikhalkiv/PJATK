package PPJ25;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RegParen {
    public static void main(String[] args) {
        String str = "Lisboa (Lisbon , Portugal), " +
                "Warszawa (Warsaw, Poland), and "
                + "Roma (Rome,Italy)";
        String pat = "[A-Z][a-z]+ *,*[A-Z][a-z]+";
        Matcher m = Pattern.compile(pat).matcher(str);
        while (m.find()) {
            String[] tab = m.group().split(",");
//            System.out.print(m.group());
//            m.find();
            for (int i = 0; i < tab.length(); i++) {
                System.out.print(tab[i] + " ");
            }
        }
    }
}
