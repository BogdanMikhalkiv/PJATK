package PPJ27;

public class Main {
    public static void main(String[] args) {
//        SingLList singLList = new SingLList();
//        singLList.addFront(1);
//        singLList.addFront(2);
//        singLList.addFront(3);
//        singLList.addBack(5);
//        singLList.showList();
        int[] arr = {1,2,3,4,5,6,7};
        SingLList list = SingLList.arrayToList(arr);
        list.showList();
    }
}
