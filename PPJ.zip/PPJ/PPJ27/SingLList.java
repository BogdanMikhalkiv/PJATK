package PPJ27;

public class SingLList {
        Node head;

    private static class Node {
         int a;
         Node next;
         public Node (int a) {
             this.a = a;
         }
     }
    public boolean empty() {
        return head == null;
    }
    public void addFront(int d) {
        Node nowy = new Node(d);
        nowy.next = head;
        head = nowy;
    }
    public void addBack(int d) {
        Node back = new Node(d);
        Node tmp = head;
        while (tmp != null) {
            if (tmp.next == null) {
                tmp.next = back;
                break;
            } else {
                tmp = tmp.next;
            }
        }

    }
    public static SingLList arrayToList(int[] arr) {
        SingLList singLList = new SingLList();
        for (int i = arr.length-1; i >=0; i--) {
            singLList.addFront(arr[i]);
        }
        return singLList;
    }
    public void removeOdd() {

    }
    public boolean contains(int d) {
return  false;
    }
    public void showList() {
        Node tmp = head;
        while (tmp != null) {
            System.out.println(tmp.a);
            tmp = tmp.next;
        }
    }
    public void clear(){

    }
}
