public class Z9 {
public static void main(String args[]) {
	char znak = 'A';
	System.out.println((char)(znak + 65) + " " +(char)(znak + 97));
	}
}

	
	
	
	
