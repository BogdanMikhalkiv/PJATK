public
	class Zadanie10 {
	
		public static void main(String args[]) {
			//zadanie 1-4
			int tablica[] = new int[10];
			int zera = 0;
			int jedynki = 0;
			
			for(int i = 0; i < 10; ++i) {
				tablica[i] = (int) (Math.random() * 2);
				System.out.print(tablica[i] + " ");
				if (tablica[i] == 0) {
					++zera;
				} else 
					++jedynki;
			}
			
			System.out.println("Jedynek : " + jedynki + " " + "Zera : " + zera);
			System.out.println(" ");
			
			int tablicaLength[] = new int[(int)(Math.random() * 10)];
			System.out.println("Table length is : " + tablicaLength.length);
			//zadanie 5
			int pomocnaZmienna = 0;
			int sumTablicy = 0;
			double tablicaDouble[] = new double[10];
			for(int i = 0; i < 10; ++i) {
				tablicaDouble[i] = (Math.random() * 10);
				sumTablicy += tablicaDouble[i];
				if( ((int) tablicaDouble[i]) % 2 != 0 )
					System.out.println("Nie parzysty element : " + " " + (int) tablicaDouble[i]);
			}
			for (int j = 0; j < 10; ++j){
				if ( j % 2 == 0)
					System.out.println("Indeks elementa " + (j) + " " + "Element na tym indeksie : " + tablicaDouble[j]);
			}
			System.out.println("Suma tablicy : " + sumTablicy);
			
			int tablicaKwadratyczna[] = {1, 0, 0, 0, 2, 0, 0, 0, 3};
			for (int i = 0; i < 3; i++) {
				for(int j = 0; j < 3; ++j) {
				System.out.print(tablicaKwadratyczna[i*3 + j]); 
				}
				System.out.println();
			}
			for (int i = 0; i < tablicaKwadratyczna.length; ++i) {
				if (tablicaKwadratyczna[i] > tablicaKwadratyczna[0])
					pomocnaZmienna = tablicaKwadratyczna[0]
			}
		}
	}