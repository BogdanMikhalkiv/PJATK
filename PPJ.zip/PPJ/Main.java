public class FirstProgram{
	
	public static void main(String[] args) {
	system.out.prntln("Hello java");
	}
}