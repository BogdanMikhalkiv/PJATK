package PPJ26;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Main {
    public static void main(String[] args) {
        String s = "TGAGFDFDTGA";
        String t = "ACCTAGGACCCCCC";
//        Matcher matcher1 = Pattern.compile("[^AGCT]").matcher(s);
//        Matcher matcher2 = Pattern.compile("[^AGCT]").matcher(t);
//        if (matcher1.find()) {
//            System.out.println("nie znalazla dna");
//        } else {
//            System.out.println("tak znalazla");
//        }
//        if (matcher2.find()) {
//            System.out.println("nie znalazla dna");
//        } else {
//            System.out.println("tak znalazla");
//        }
        String s1 = "+49(30)7654321";
        String s2 = "+49(.)123456789";
        String s3 = "+48(.)221234567";
        String s4 = "+48(.)123456789";
        String s5 = "1 234-567";
        String s6 = "1234-567";
        String s7 = "123 456 789";
        String s8 = "123-456-789";
        String s9 = "221_234_567";


        Matcher matcher1 = Pattern.compile("(\\+?[0-9]{0,2}(\\(.+\\)))*\\d{1}.*\\d{2}.*\\d.*\\d{2}.*\\d{1,3}").matcher(s1);
        Matcher matcher2 = Pattern.compile("(\\+{0,1}[0-9]{0,2}(\\(.+\\)))*\\d{1}.*\\d{2}.*\\d.*\\d{2}.*\\d{1,3}").matcher(s2);
        Matcher matcher3 = Pattern.compile("(\\+{0,1}[0-9]{0,2}(\\(.+\\)))*\\d{1}.*\\d{2}.*\\d.*\\d{2}.*\\d{1,3}").matcher(s3);
        Matcher matcher4 = Pattern.compile("(\\+{0,1}[0-9]{0,2}(\\(.+\\)))*\\d{1}.*\\d{2}.*\\d.*\\d{2}.*\\d{1,3}").matcher(s4);
        Matcher matcher5 = Pattern.compile("(\\+{0,1}[0-9]{0,2}(\\(.+\\)))*\\d{1}.*\\d{2}.*\\d.*\\d{2}.*\\d{1,3}").matcher(s5);
        Matcher matcher6 = Pattern.compile("(\\+{0,1}[0-9]{0,2}(\\(.+\\)))*\\d{1}.*\\d{2}.*\\d.*\\d{2}.*\\d{1,3}").matcher(s6);
        Matcher matcher7 = Pattern.compile("(\\+{0,1}[0-9]{0,2}(\\(.+\\)))*\\d{1}.*\\d{2}.*\\d.*\\d{2}.*\\d{1,3}").matcher(s7);
        Matcher matcher8 = Pattern.compile("(\\+{0,1}[0-9]{0,2}(\\(.+\\)))*\\d{1}.*\\d{2}.*\\d.*\\d{2}.*\\d{1,3}").matcher(s8);
        Matcher matcher9 = Pattern.compile("(\\+{0,1}[0-9]{0,2}(\\(.+\\)))*\\d{1}.*\\d{2}.*\\d.*\\d{2}.*\\d{1,3}").matcher(s9);

        while(matcher1.find()) {
            System.out.println(matcher1.group());
        }

        while(matcher2.find()) {
            System.out.println(matcher2.group());
        }
        while(matcher3.find()) {
            System.out.println(matcher3.group());
        }
        while(matcher4.find()) {
            System.out.println(matcher4.group());
        }
        while(matcher5.find()) {
            System.out.println(matcher5.group());
        }

        while(matcher6.find()) {
            System.out.println(matcher6.group());
        }

        while(matcher7.find()) {
            System.out.println(matcher7.group());
        }

        while(matcher8.find()) {
            System.out.println(matcher8.group());

        }
        while(matcher9.find()) {
            System.out.println(matcher9.group());
        }
    }
}
