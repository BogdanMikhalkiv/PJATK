public
	class Lekcja8 {
		public static void main(String[] args) {
		
			int wrt = 15;
		
			for(int i = 1; i <=10; ++i)
			System.out.println(i * 15);
		
			//================================================================================
		
			int g = 10;
		
			while (g > 10)
			System.out.println(g);
		
			do {
			System.out.println(g);
		
			}while(g > 10);
		
			//=================================================================================
			
			double sum = 0.0;
			
			for(int i = 0; i <= 10; ++i) {
				sum += 1 / Math.pow(2,i);
				System.out.println();	
			}
			//=================================================================================
		
			char gwiazdka = '*';
		
			for(int i = 0; i < 5; ++i) {
				for(int j = 0; j <= i; ++j) {
				System.out.print(gwiazdka);
				}
				System.out.println(" ");
			}
		
			//=================================================================================
		
		
			boolean wykonuj = true;
			int res = 15 , i = 10;
			do {
				i--;
				if (i == 6)
				wykonuj = false;
				res -= 2;
			}while (wykonuj);
			System.out.println (res); 
		
		
			//=================================================================================
			
			int y = 3;
			
			do {
				System.out.println(++y + " ");
			}while( y <= 10);
			
			
			
			
			
			int x = 0 ;
			while ( x++ < 10 ) {}
			String msg = (x > 10) ? "wieksze niz" : "false" ;
			System . out . println ( msg + "," + x ) ;
	
	}
	
}
	