public
	class Zadanie12 {
		public static void main(String args[]) {
			String[] slova = {
				"Ala" , "kota", "ma", "ma", "a", "kot", "Ale"
			};
			String zmienna;
			zmienna = slova[1];
			slova [1] = slova [2];
			slova[2] = zmienna;
			zmienna = slova[slova.length - 2];
			slova[slova.length - 2] = slova[3];
			slova[3] = zmienna;
			zmienna = slova[3];
			slova[3] = slova[5];
			slova[5] = zmienna;
			for(int i = 0; i < slova.length;++i) {
				System.out.println(slova[i]);
			}
		
		
		
		
		
		}
	}