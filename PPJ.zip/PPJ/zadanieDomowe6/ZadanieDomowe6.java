public 
	class ZadanieDomowe6 {
	public static void main(String args[]) {
		byte a = 40 , b = 50;
		int suma = (byte) a + b ; //We can convert only from byte to int, unable to convert from byte to byte
		System.out.println ( suma ) ;
		
		boolean czyPada = true;
		if (czyPada){
			System.out.println("czyPada = true");
		}else {
			System.out.println("czyPada = false");
		}
		System.out.println("Enter x");
		java.util.Scanner in = new java.util.Scanner(System.in);
		int x = in.nextInt();
		if(x <= -15 || (x > -8 && x < -5)) {
			System.out.println(x + " --> B");
		} else if ( (x >= 0 && x <= 5) || x >= 10) {
			System.out.println(x + " --> C");
		} else if (x >= -13 && x <= -10) {
			System.out.println(x + " --> A");
		} else if ((x < -15 && x > -13) || (x >= -5 && x < -4)) {
			System.out.println(x + " --> AB");
		} else if (x >= -4 && x <= -3) {
			System.out.println(x + " --> ABC");
		} else if ((x > -3 && x < 0) || x > 5 && x < 10) {
			System.out.println(x + " --> AC");
		}else {
			System.out.println(x + " Nie nalezy do zbiurow");
		}
		
		System.out.println("Enter number for task 4");
		int y = in.nextInt();
		if (y > -13 && y < -10) {
			System.out.println(y + " --> A");
		} else if (y < 15) {
			System.out.println(y + " -->B");
		} else {
			System.out.println("Liczba nie nalezy do zbioru A labo do zbioru B");
		}
		
		double sqTwo = Math.sqrt(2);
		double sqTwo1 = Math.pow(sqTwo, 2); //ezeli zmienna bedzie  int to wynnik ostatniej operacji bedzie 0.
		double sqTwo2 = sqTwo1 - 2;
		
		System.out.println(sqTwo + " - wynnik z Math.sqrt(2)");
		System.out.println(sqTwo1 + " - wynnik z operacji Math.sqrt(2) ^ 2" );
		System.out.println(sqTwo2 + " - wynnik z operacji (Math.sqrt(2) ^ 2) - 2 ");
		
		int z = 4;
		long p = z * 4 - z++;
		if ( p < 12) System.out.println ( "za mało" );
		else System.out.println ( "w sam raz dla tego ze 'p' zawsze 12" );
		
		
		boolean w = true , l = true;
		int o = 20;
		w = ( o != 10 ) ^ ( l = false ); // true ^(XOR) false = true.
		System.out.println ( w+", "+o+", "+l );
		
	}

}