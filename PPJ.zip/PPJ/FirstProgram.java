public class FirstProgram {
	
	public static void main(String[] args) {
	System.out.println("Hello java");
	}
	boolean yesNo = true;
	int a = 2147483647 ;
	float b = 1234567F;
	char letters = 'a';
}