public class FirstProgram1 {
public static void main(String[] args){
	float flt = 1.234f;

	long lng = 123451461451345L;
	int number = 12;
	
	char letter = 'f';

	byte bt = 122;
	
	double dbl = 1.123;
	
	char mm =(char) (letter + number);
	int sdf = (number + letter);
	float dfs =(float) (flt + dbl);
	byte gfg =(byte) (bt + number);
	byte x = 5;
	byte y = 10;
	
	float z2 = x + y;
	double z3 = x + y;
	int z4 = x + y;
	long z5 = x + y;
	
	java.util.Scanner in = new java.util.Scanner(System.in);
	byte wrt = in.nextByte();

	System.out.print( (wrt & (1 << 7)) + " ");
	System.out.print( (wrt & (1 << 6)) + " ");
	System.out.print( (wrt & (1 << 5)) + " ");
	System.out.print( (wrt & (1 << 4)) + " ");
	System.out.print(" ");
	System.out.print( (wrt & (1 << 3)) + " ");
	System.out.print( (wrt & (1 << 2)) + " ");
	System.out.print( (wrt & (1 << 1)) + " ");
	System.out.print( (wrt & (1 << 0)) + " ");
	System.out.println();
	
	int ARGB = 370208;


int a = (int)(( ARGB & (1<<15))>>15)*128;
int b =  (int)(( ARGB & (1<<14))>>14)*64;
int c =  (int)((ARGB & (1<<13))>>13)*32;
int d = (int)((ARGB & (1<<12))>>12 )*16;
int e = (int)((ARGB & (1<<11))>>11)*8;
int f = (int)((ARGB & (1<<10))>>10 )*4;
int g = (int)((ARGB & (1<<9))>>9)*2;
int h = (int)((ARGB & (1<<8))>>8 );
int green =a+b+c+d+e+f+g+h;
System.out.println(green);

	}
	
	
}