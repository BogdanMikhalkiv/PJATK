package PPJ24;

import java.io.FileReader;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Main {
    public static void main(String[] args) throws Exception {
        FileReader fileReader = new FileReader("1.txt");
        StringBuilder stringBuilder = new StringBuilder();
        int tmp = fileReader.read();
        while (tmp != -1) {
            stringBuilder.append((char) tmp);
            tmp = fileReader.read();
        }
        fileReader.close();
//        System.out.println(stringBuilder);
//
        String s = "Ярих лох Ярих";
        Pattern pattern = Pattern.compile("Одессос");
        Matcher matcher = pattern.matcher(stringBuilder);
        while (matcher.find()){
            System.out.println(matcher.group());
            matcher.find();
        }


    }
}
