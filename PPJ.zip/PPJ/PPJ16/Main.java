package PPJ16;

public class Main {
    public static void main(String[] args) {
        System.out.println(A.counter);
      A a = new A();
      int counter = 0;

        System.out.println(a.x);
        System.out.println(a.y);
        a.show();
        System.out.println(A.counter);

        A a1 = new A(4.5f, "NAPIS");
        a1.show();
        System.out.println(A.counter);

        System.out.println();
        int [] arr = {1,2,3};
        B b = new B(arr);
        b.show();
        System.out.println();
        b.add(4);
        b.show();
        System.out.println();
        b.replaceOdd(10);
        b.show();
    }
}
