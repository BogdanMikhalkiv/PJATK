package PPJ16;

import java.util.Scanner;

public class Prostokat {
    private int a, b, pole;
    private double przekatna;

    public Prostokat () {
        a = 0;
        b = 0;
        pole = 0;
        przekatna = 0;
    }

     public void czytajDane () {
        Scanner scanner = new Scanner(System.in);
         System.out.println("a - ");
        a = scanner.nextInt();
         System.out.println(a);
         System.out.println("b - ");
        b = scanner.nextInt();
         System.out.println(b);
    }
    public  int obliczPole() {
        pole = 3;
        return pole;
    }
    public double obliczPrzekatna() {
        przekatna = 6;
        return przekatna;
    }

    public String toString() {
        return "a - " + a + "\t" + "b - " + b + "\t" + "pole - " + pole + "\t" + "przekatna - " + przekatna;
    }
}
