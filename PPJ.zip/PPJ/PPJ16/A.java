package PPJ16;

public class A {
    float x ;
    String y;
    static int counter = 0;
    public A () {

        x = 1.5f;
        y = "NOPE";
        counter++;
    }
    public A(float x, String y) {
        this.x = x;
        this.y = y;
        counter++;
    }

    public void show() {
        System.out.println(x + " " + y);
    }

}
