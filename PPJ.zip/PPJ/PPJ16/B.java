package PPJ16;

public class B {
    int [] arr ;

    public B(int[] arr) {
        this.arr = arr;
    }

    public void show() {
        for (int i = 0; i < arr.length; i++) {
            System.out.print(arr[i] + " ");
        }
    }

    public int[] add(int d) {
        for (int i = 0; i < arr.length; i++) {
            arr[i] = d + arr[i];
        }
        return arr;
    }

    public int[] replaceOdd(int h) {
        for (int i = 0; i < arr.length; i++) {
            if (arr[i] % 2 != 0) {
                arr[i] = h;
            }
        }
        return arr;
    }
}
