public class PPJ7 {
public static void main(String args[]) {
		java.util.Scanner in = new java.util.Scanner(System.in);
		int x = in.nextInt();
		System.out.println((x > 1) ? "A" : (x < 0) ? "B" : "ABC"); 
		
		boolean czyPada = true; 
		boolean czySwieciSlonce;
	
		int wrt = (czyPada == true ?  5 : 8);
		
		System.out.println("Enter char");
		char znak = in.next().charAt(0);
		int p = 0;
		if(znak >= 48 && znak <= 57) {
			p = znak - 48;
		} else if(znak >= 65 && znak <= 76) {
			p = znak - 55;
		} else
			System.out.println(" Nie jest liczba w 16 systemie");
		
		System.out.println(p);
		
		int dzien = in.nextInt();
		int miesac = in.nextInt();
		int ilosc = 0;
		
		switch(miesac) {
			case 1: ilosc += dzien;
				break;
				
			case 2: ilosc = dzien + 31;
				break;
				
			case 3: ilosc = dzien + 31 + 29;
				break;
			
			case 4: ilosc = dzien + 31 + 29 + 31;
				break;
				
			case 5: ilosc = dzien + 31 + 29 + 31 + 30;
				break;
				
			case 6: ilosc = dzien + 31 + 29 + 31 + 30 + 31;
				break;
				
			case 7: ilosc = dzien + 31 + 29 + 31 + 30 + 31 + 30;
				break;
				
			case 8: ilosc = dzien + 31 + 29 + 31 + 30 + 31 + 30 + 31;
				break;
				
			case 9: ilosc = dzien + 31 + 29 + 31 + 30 + 31 + 30 + 31 + 30;
				break;
				
			case 10: ilosc = dzien + 31 + 29 + 31 + 30 + 31 + 30 + 31 + 30 + 31;
				break;
				
			case 11: ilosc = dzien + 31 + 29 + 31 + 30 + 31 + 30 + 31 + 30 + 31 + 30;
				break;
				
			case 12: ilosc = dzien + 31 + 29 + 31 + 30 + 31 + 30 + 31 + 30 + 31 + 30 + 31;
				break;
				
			default : System.out.println("Nie ma takiego miesaca");
		}
		
		int x1 = ( int ) ( Math.random () * 10);
		int y1 = ( int ) ( Math.random () * 10);
		int z1 = ( int ) ( Math.random () * 10);
		int max1 = 0;
		
		if (x1 > y1) {
			max1 = x1;
		}else max1 = y1;
		
		
		if (z1 > max1) {
			System.out.println(z1);

		}
	 
		
	

	}
}