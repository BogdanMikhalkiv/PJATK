package com.example.diplom;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.input.MouseEvent;

public class ProfileInfoController {

    @FXML
    private Button saveButton;

    @FXML
    void saveBtn(MouseEvent event) {

    }

}
