/**
 *
 *  @author Mykhalkiv Bohdan S19362
 *
 */

package zad1;


import javax.swing.*;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class CustomersPurchaseSortFind {
    List<Purchase> list = new ArrayList<>();
    public void readFile(String fname)  {
        try(BufferedReader br = new BufferedReader(new FileReader(fname)))  {
            String tmp;
            while((tmp = br.readLine())!=null) {

               list.add(new Purchase(
                       tmp.split(";")[0],
                       tmp.split(";")[1].split( " ")[0],
                       tmp.split(";")[1].split(" ")[1],
                       tmp.split(";")[2],
                       Double.parseDouble(tmp.split(";")[3]),
                       Double.parseDouble(tmp.split(";")[4])
                       )
               );
            }
        }
        catch(IOException ex){
            System.out.println(ex.getMessage());
        }

    }

    public int sortN (String string) {
        boolean b = false;
        String s = "";
        int a = 0;
            for (int i = 1; i < string.length(); i++) {
                if (b == false) {
                    if (string.charAt(i) != '0') {
                        for (int j = i; j < string.length(); j++) {
                            if (string.charAt(j) >= 48 && string.charAt(j) <= 57) {
                                s += string.charAt(j);
                            }
                        }
                        b = true;

                    }
                }

        }
         a = Integer.parseInt(s);
        return a;
    }

    public void showSortedBy(String stringArg) {
        List<Purchase> listB = new ArrayList<>(list);
        if (stringArg.equals("Nazwiska")) {
            System.out.println("Nazwiska");
        for (int i = 0; i < listB.size(); i++) {
            for (int j = i + 1; j < listB.size(); j++) {
                if (i <= listB.size() - 2) {
                    if (listB.get(i).nazwisko.equals(listB.get(j).nazwisko)) {
                        if (sortN(listB.get(i).id_klienta) > sortN(listB.get(j).id_klienta)) {
                            Collections.swap(listB, i, j);
                        }
                    }
                    if (listB.get(i).nazwisko.charAt(0) > listB.get(j).nazwisko.charAt(0)) {
                        Collections.swap(listB, i, j);
                    }
                }
            }
        }
        for (int i = 0; i < listB.size(); i++) {
            System.out.println(listB.get(i));
        }
            System.out.println();
    }

        if (stringArg.equals("Koszty")) {
            System.out.println("Koszty");
            for (int i = 0; i < listB.size(); i++) {
                for (int j = i + 1; j < listB.size(); j++) {
                    if (i <= listB.size() - 2) {
                        if (listB.get(i).koszty == listB.get(j).koszty) {
                            if (sortN(listB.get(i).id_klienta) > sortN(listB.get(j).id_klienta)) {
                                Collections.swap(listB, i, j);
                            }
                        }
                        if (listB.get(i).koszty < listB.get(j).koszty) {
                            Collections.swap(listB, i, j);
                        }
                    }
                }
            }
            for (int i = 0; i < listB.size(); i++) {
                System.out.println(listB.get(i) + "(koszt: " + listB.get(i).koszty + ")");
            }
            System.out.println();
    }
}

    public void showPurchaseFor(String id) {
        System.out.println("Klient " + id);
        List<Purchase> listA = new ArrayList(list);
        for (int i = 0; i < listA.size(); i++) {
            if (listA.get(i).id_klienta.equals(id)) {
                System.out.println(listA.get(i));
            }
        }
        System.out.println();
    }
}
