/**
 *
 *  @author Mykhalkiv Bohdan S19362
 *
 */

package zad1;


public class Purchase {
    String id_klienta;
    String nazwisko;
    String imię;
    String nazwa_towaru;
    double cena;
    double zakupiona_ilość;
    double koszty;

    public Purchase(String id_klienta, String nazwisko, String imię, String nazwa_towaru, double cena, double zakupiona_ilość) {
        this.id_klienta = id_klienta;
        this.nazwisko = nazwisko;
        this.imię = imię;
        this.nazwa_towaru = nazwa_towaru;
        this.cena = cena;
        this.zakupiona_ilość = zakupiona_ilość;
        koszty = cena * zakupiona_ilość;
    }


    @Override
    public String toString() {
        return id_klienta + ";" + nazwisko + " " + imię + ";" + nazwa_towaru + ";" + cena + ";" + zakupiona_ilość;
    }
}

