/**
 *
 *  @author Mykhalkiv Bohdan S19362
 *
 */

package zad2;


import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;

public class Anagrams {
    List<String> list = new ArrayList<>();

    public Anagrams (String fname) {
        String tmpArf = "";
        int counter = 0;
        try(BufferedReader br = new BufferedReader(new FileReader(fname)))  {
            String tmp;
            int i = 0;
            while((tmp = br.readLine())!=null) {
                if (counter == 0) {
                    tmpArf += tmp;
                    counter++;
                } else  {
                    tmpArf += " " + tmp;
                }
            }
        }
        catch(IOException ex){
            System.out.println(ex.getMessage());
        }
        for (int i = 0; i < tmpArf.split(" ").length; i++) {
            list.add(tmpArf.split(" ")[i]);
        }




    }

    public String MySort(String a) {
        String abcd = a;
        char[]chars = abcd.toCharArray();
        Arrays.sort(chars);
        String sorted = new String(chars);
        return sorted;
    }
    public List<List<String>> getSortedByAnQty() {
        List<List<String>> listArrayList = new ArrayList<>();
        for (int i = 0; i < list.size(); i++) {
            List<String> arr = new ArrayList<>();
            arr.add(list.get(i));
            for (int j = i+1; j < list.size(); j++) {
                    if (MySort(list.get(i)).equals(MySort(list.get(j)))) {
                            arr.add(list.get(j));
                   }
            }
            boolean b = false;
            for (int g = 0; g < listArrayList.size(); g++) {
                for (int j = 0; j < listArrayList.get(g).size(); j++) {
                    for (int k = 0; k < arr.size(); k++) {
                        if (arr.get(k).equals(listArrayList.get(g).get(j))) {
                        b = true;
                        }
                    }
                }
            }
            if (b == false && !arr.isEmpty()) {
                Collections.sort(arr);

                listArrayList.add(arr);
            }
        }
        for (int i = 0; i < listArrayList.size(); i++) {
            for (int j = 0; j < listArrayList.get(i).size(); j++) {
                for (int k = j+1; k < listArrayList.get(i).size(); k++) {
                    if (listArrayList.get(j).size() < listArrayList.get(k).size()) {
                        Collections.swap(listArrayList, j, k);
                    } else if (listArrayList.get(j).size() == listArrayList.get(k).size() && listArrayList.get(i).get(j).charAt(0) > listArrayList.get(i).get(k).charAt(0)) {
                            Collections.swap(listArrayList, j, k);
                    }
                }
            }
        }
        return listArrayList;

    }

    public String getAnagramsFor(String next) {
        List<List<String>> listArrayList = new ArrayList<>();
        String nextb = new String(next);
        List<String> tab = new ArrayList<>();
        boolean check = false;
        int counter = 0;
        for (int i = 0; i < list.size(); i++) {
            if (!next.equals(list.get(i))) {
                counter++;
            }
        }
        if (counter == list.size()) {
            check = true;
        }
        for (int i = 0; i < list.size(); i++) {
            List<String> arr = new ArrayList<>();
            for (int j = i+1; j < list.size(); j++) {
                if (MySort(next).equals(MySort(list.get(j)))) {
                    arr.add(list.get(j));
                }
            }
            boolean b = false;
            for (int g = 0; g < listArrayList.size(); g++) {
                for (int j = 0; j < listArrayList.get(g).size(); j++) {
                    for (int k = 0; k < arr.size(); k++) {
                        if (arr.get(k).equals(listArrayList.get(g).get(j))) {
                            b = true;
                        }
                    }
                }
            }
            if (b == false && !arr.isEmpty()) {
                arr.remove(nextb);
                Collections.sort(arr);
                listArrayList.add(arr);
            }
        }
        for (int i = 0; i < listArrayList.size(); i++) {
            for (int j = 0; j < listArrayList.get(i).size(); j++) {
                if (MySort(next).equals(MySort(listArrayList.get(i).get(j))) && !next.equals(MySort(listArrayList.get(i).get(j)))) {
                    tab.add(listArrayList.get(i).get(j));
                }
            }
        }
        if (check!=true) {
            return next + ": " + tab;
        } else {
            return next + ": " + null;
        }
    }
}

