import java.util.Arrays;

public class п {
    public static void main(String[] args) {
        String abcd = "bdca";
        char[]chars = abcd.toCharArray();

        Arrays.sort(chars);
        String sorted = new String(chars);
        System.out.println(sorted);
    }
}
