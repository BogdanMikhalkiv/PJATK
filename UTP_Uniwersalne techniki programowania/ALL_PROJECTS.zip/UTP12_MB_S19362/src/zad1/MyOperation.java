package zad1;

import java.math.BigDecimal;

public class MyOperation {

    public BigDecimal Add (BigDecimal i, BigDecimal j ) {
        return i.add(j);
    }

    public BigDecimal Minus (BigDecimal i, BigDecimal j) {
        return i.subtract(j);
    }

    public BigDecimal Multiply (BigDecimal i, BigDecimal j) {
        return i.multiply(j);
    }

    public BigDecimal Divide (BigDecimal i, BigDecimal j) {
        return i.divide(j, 7, BigDecimal.ROUND_HALF_UP);
    }
}
