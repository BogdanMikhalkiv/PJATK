/**
 *
 *  @author Mykhalkiv Bohdan S19362
 *
 */

package zad1;


import java.lang.reflect.Method;
import java.math.BigDecimal;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class Calc {
    Map<String, Method> map = new HashMap<>();


    public String doCalc(String arg) {
        BigDecimal a = new BigDecimal(arg.split("[\\s]+")[0]);
        BigDecimal b = new BigDecimal(arg.split("[\\s]+")[2]);

        String wynik ="";

        try {
            MyOperation myOperation = new MyOperation();

            Method add = myOperation.getClass().getDeclaredMethod("Add", BigDecimal.class,BigDecimal.class);
            Method divide = myOperation.getClass().getDeclaredMethod("Divide", BigDecimal.class,BigDecimal.class);
            Method multiply = myOperation.getClass().getDeclaredMethod("Multiply", BigDecimal.class,BigDecimal.class);
            Method minus = myOperation.getClass().getDeclaredMethod("Minus", BigDecimal.class, BigDecimal.class);

            map.put("+", add);
            map.put("-", minus);
            map.put("*", multiply);
            map.put("/", divide);


           wynik = String.valueOf(map.get(arg.split("[\\s]+")[1]).invoke(myOperation, a, b));


        } catch (Exception e) {
            e.printStackTrace();
        }


        return wynik;
    }
}
