//package zad2;
//
//
//import java.lang.reflect.Field;
//import java.lang.reflect.Method;
//import java.util.Map;
//
//public class main {
//    public static void main(String[] args) {
//        Class<MyClass> bClass = MyClass.class;
//        System.out.println(bClass);
//
//
//
//        Class<MyClass> carClass2 = MyClass.class;
//        Field[] declaredFields = carClass2.getDeclaredFields();
//        for (Field field :declaredFields) {
//            System.out.println(field);
//        }
//
//
//        Class<MyClass> carClass = MyClass.class;
//        Method[] declaredMethods = carClass.getDeclaredMethods();
//        for (Method method : declaredMethods) {
//            System.out.println(method);
//        }
//    }
//}
