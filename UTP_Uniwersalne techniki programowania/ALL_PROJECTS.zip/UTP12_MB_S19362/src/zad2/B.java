//package zad2;
//
//public class B  extends MyClass {
//    int h;
//    public B(boolean b, int h) {
//        super(b);
//        this.h = h;
//    }
//}
