//package zad2;
//
//public class MyClass {
//   public int g;
//    final boolean b;
//
//    public MyClass(boolean b) {
//        this.b = b;
//    }
//
//    public void setG(int g) {
//        this.g = g;
//    }
//
//}
