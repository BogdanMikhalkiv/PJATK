package zad3;

import java.beans.*;

public class Account {
   static int idAccountCounter;
   int idAccount;
   double balance;
   private PropertyChangeSupport propertyChange = new PropertyChangeSupport(this);
   private VetoableChangeSupport vetos = new VetoableChangeSupport(this);



    public Account (double num) throws PropertyVetoException {
        balance = num;
        idAccountCounter++;
        idAccount = idAccountCounter;
    }

    public Account ( ) throws PropertyVetoException {
        balance = 0;
        idAccountCounter++;
        idAccount = idAccountCounter;
    }



    public synchronized void addVetoableChangeListener(VetoableChangeListener l) {
        vetos.addVetoableChangeListener(l);
    }
    public synchronized void removeVetoableChangeListener(VetoableChangeListener l) {
        vetos.removeVetoableChangeListener(l);
    }
    public synchronized void addPropertyChangeListener(PropertyChangeListener l) {
        propertyChange.addPropertyChangeListener(l);
    }
    public synchronized void removePropertyChangeListener(PropertyChangeListener l) {
        propertyChange.removePropertyChangeListener(l);
    }




    @Override
    public String toString() {
        return "Acc " + idAccount + ": " + balance;
    }

    public synchronized void deposit(double newValue) throws PropertyVetoException {
        Double oldValue = null;
        oldValue = balance;
        vetos.fireVetoableChange("" + idAccount, oldValue, newValue + oldValue);
        balance = balance + newValue;
        propertyChange.firePropertyChange("" + idAccount, oldValue, newValue + oldValue);
    }

    public synchronized void withdraw(double newValue) throws PropertyVetoException {
        Double oldValue = null;
        oldValue = balance;
        vetos.fireVetoableChange(" " + idAccount, oldValue, oldValue - newValue);
        balance = balance - newValue;
        propertyChange.firePropertyChange(" " + idAccount, oldValue, oldValue - newValue);
    }

    public void transfer(Account acc1, double i)throws  PropertyVetoException   {
            withdraw(i);
            acc1.deposit(i);
    }
}
