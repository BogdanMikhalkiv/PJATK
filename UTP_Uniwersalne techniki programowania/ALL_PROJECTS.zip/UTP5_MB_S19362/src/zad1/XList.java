package zad1;

import java.util.*;
import java.util.function.BiConsumer;
import java.util.function.Function;

public class XList<T> extends ArrayList {
    
    public XList( T ... t) {
        if (t.length == 1) {
            for (int i = 0; i < t.length; i++) {
                if (t[i] instanceof Collection) {
                    ((Collection) t[i]).forEach(o -> this.add(o));
                }
            }
        } else {

            for (int i = 0; i < t.length; i++) {
                this.add(t[i]);
            }
        }
    }
    public XList () {}
    
    public static <T>XList of(T ... t ) {
        XList <T> arr = new XList<>();
        if (t.length > 1) {
            for (int i = 0; i < t.length; i++) {
                arr.add(t[i]);
            }
        } else {
            for (int i = 0; i < t.length; i++) {
                if (t[i] instanceof Collection) {
                    ((Collection) t[i]).forEach(o -> arr.add(o));
                }
            }
            return new XList<>(t);
        }
        return arr;
    }

    public static <T>XList<T> charsOf(String s) {
        XList <T> arr = new XList<>();
        for (int i = 0; i < s.length(); i++) {
                arr.add(s.charAt(i));
        }
        return arr;
    }

    public static <T>XList<T> tokensOf(String... s) {
        XList <T> arr = new XList<>();
        if (s.length == 2) {
            String[] d = s[0].split(s[1]);
            for (int i = 0; i < d.length; i++) {
                arr.add(d[i]);
            }
        } else {
            String[] d = s[0].split(" ");
            for (int i = 0; i < d.length; i++) {
                arr.add(d[i]);
            }
        }
        return arr;
    }

    public <R>XList<T> union(R ... t) {
        XList<T> arr2 = new XList(t);
        XList<T> arr = new XList<>();
        for (int i = 0; i < this.size(); i++) {
            arr.add(this.get(i));
        }
        for (int i = 0; i < arr2.size(); i++) {
            arr.add(arr2.get(i));
        }
        return arr;
    }

    public <R>XList<T> diff(R ... t) {
        XList<T> arr2 = new XList(t);
        XList<T> arr = new XList(this);
        int k = 0;
        for (int i = 0; i < arr2.size(); i++) {
            for (int j = 0; j < arr.size(); j++) {
                arr.remove(arr2.get(i));
            }
        }
        return arr;
    }

    public XList<T> unique() {
        XList<T> arr = new XList(this);
        for (int i = 0; i < arr.size()-1; i++) {
            for (int j = i+1; j < arr.size(); j++) {
                if (arr.get(i) == arr.get(j)) {
                        arr.remove(j);
                        j--;
                }
            }
        }
        return arr;
    }
    public void forEachWithIndex(BiConsumer<T, Integer> biCon){
        for (int i = 0; i < this.size(); i++) {
            biCon.accept((T)this.get(i), i);
        }
    }
}
