/**
 *
 *  @author Mykhalkiv Bohdan S19362
 *
 */

package zad1;


import java.util.ArrayList;
import java.util.List;
import java.util.function.Function;
import java.util.function.Predicate;


public class ListCreator<T,R> { // Uwaga: klasa musi być sparametrtyzowana
        List<T> list;
        List<T> listWhen = new ArrayList<T>();
        List<T> listMap = new ArrayList<T>();

    public ListCreator(List list) {
        this.list = list;
    }


    public static <T> ListCreator collectFrom(List<T> list) {
            return new ListCreator(list);
    }

    public ListCreator<T,R> when (Predicate<T> predicate) {
        for (int i = 0; i < list.size(); i++) {
            if (predicate.test(list.get(i))) {
                listWhen.add(list.get(i));
            }
        }
        return this;
        }

       public List<T> mapEvery (Function<T,R> function) {
           for (int i = 0; i < listWhen.size(); i++) {
               listMap.add((T) function.apply(listWhen.get(i)));
           }
           return listMap;
       }




}
