package zad1;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;

public class ProgLang <T> {
    Map<String, List<String>> list = new LinkedHashMap<>();
    Map<String, List<String>> listB = new LinkedHashMap<>();


    public ProgLang (String fname) {

        FileReader fr;
        try {
            fr = new FileReader(fname);
            BufferedReader br = new BufferedReader(fr);

            String lang;
            String tmp = br.readLine();
            while (tmp != null) {
                List<String> valT = new ArrayList(Arrays.asList(tmp.split("\t")));
                for (int i = 0; i < valT.size()-1; i++) {
                    for (int j = i+1; j <valT.size(); j++) {
                         if (valT.get(i).equals(valT.get(j))) {
                             valT.remove(j);
                             j--;
                        }
                    }
                }
                lang = valT.get(0);
                valT.remove(0);
                for (int i = 0; i < valT.size(); i++) {
                    if(listB.containsKey(valT.get(i)) == false){
                        listB.put(valT.get(i),new ArrayList<>(Arrays.asList(lang)));
                    }else{
                        listB.get(valT.get(i)).add(lang);
                    }
                }
                list.put(lang,valT);
                tmp = br.readLine();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    public Map<String, List<String>> getLangsMap() {
        return list;
    }

    public Map<String, List<String>> getProgsMap() {
        return listB;
    }

    public Map<String, List<String>> getLangsMapSortedByNumOfProgs() {
       return sorted(list);
    }

    public Map<String, List<String>> getProgsMapSortedByNumOfLangs() {
        return sorted(listB);
    }

    public Map<String, List<String>> getProgsMapForNumOfLangsGreaterThan(int num) {
      return filtered(listB, num);
    }

    public Map<String, List<String>> sorted (Map<String, List<String>> listF) {
        List<Map.Entry<String, List<String>>> valT = new ArrayList(listF.entrySet());
        Map<String, List<String>> newMap = new LinkedHashMap<>();
        for (int i = 0; i <valT.size()-1 ; i++) {
            for (int j = i+1; j <valT.size() ; j++) {
                if (valT.get(i).getValue().size() == valT.get(j).getValue().size()) {
                    if (valT.get(i).getKey().charAt(0) > valT.get(j).getKey().charAt(0)) {
                        Collections.swap(valT, i, j);
                    }
                }
                if (valT.get(i).getValue().size() < valT.get(j).getValue().size()) {
                    Collections.swap(valT, i, j);
                }
            }
        }
        for (int i = 0; i < valT.size(); i++) {
            newMap.put(valT.get(i).getKey(), valT.get(i).getValue());
        }
        return newMap;

    }

    public Map<String, List<String>> filtered (Map<String, List<String>> listF, int num) {
        List<Map.Entry<String, List<String>>> valT = new ArrayList(listF.entrySet());
        List<Map.Entry<String, List<String>>> valT2 = new ArrayList();

        Map<String, List<String>> newMap = new LinkedHashMap<>();
        for (int i = 0; i < valT.size(); i++) {
            if (valT.get(i).getValue().size() > num) {
                valT2.add(valT.get(i));
            }
        }
        for (int i = 0; i < valT2.size(); i++) {
            newMap.put(valT2.get(i).getKey(), valT2.get(i).getValue());
        }
        return newMap;
    }
}
