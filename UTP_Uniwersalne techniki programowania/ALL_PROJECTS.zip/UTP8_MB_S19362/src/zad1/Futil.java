package zad1;

import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.*;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.ArrayList;
import java.util.List;

public class Futil  extends SimpleFileVisitor <Path> {

   static List<String> arrayListlist = new ArrayList<>();

    public static void processDir(String dirName, String resultFileName)  {
        try {
        Files.walkFileTree(Path.of(dirName), new SimpleFileVisitor<Path>() {
            public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) throws IOException {
                if (attrs.isRegularFile()) {
                     List<String> list = Files.readAllLines(file, Charset.forName("Cp1250"));
                    for (int i = 0; i < list.size(); i++) {
                        arrayListlist.add(list.get(i));
                    }
                }
                return FileVisitResult.CONTINUE;
            }
        });
        Files.write(Path.of(resultFileName), arrayListlist,Charset.forName("UTF-8"));
        } catch (IOException e) {
            e.getStackTrace();
        }



    }

}
