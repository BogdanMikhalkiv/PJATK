package zad2;

import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.SimpleFileVisitor;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class Futil extends SimpleFileVisitor<Path> {
    static List<String> arrayListlist = new ArrayList<>();

    public static void processDir(String dirName, String resultFileName) {
        try {

        Files.walk(Path.of(dirName)).filter(Files::isRegularFile).forEach(l -> {
            List<String> list = new ArrayList<>();
            try {
             list=   Files.lines(Path.of(String.valueOf(l)), Charset.forName("Cp1250")).collect(Collectors.toList());
            } catch (IOException e) {
                e.printStackTrace();
            }
            System.out.println(l);
            for (int i = 0; i < list.size(); i++) {
                arrayListlist.add(list.get(i));
            }

        });
            Files.write(Path.of(resultFileName), arrayListlist,Charset.forName("UTF-8"));

        } catch (IOException e) {
            e.getStackTrace();
        }
    }
}
