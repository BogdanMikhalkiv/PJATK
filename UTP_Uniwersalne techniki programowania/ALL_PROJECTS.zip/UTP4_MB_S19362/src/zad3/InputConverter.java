package zad3;

import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Function;

public class InputConverter<T> {
        T text;
        String tmp;

    public InputConverter (T fname) {
        String text = "";
        if (fname.getClass() == String.class) {
            try (BufferedReader bufferedReader = new BufferedReader(new FileReader((String) fname))) {
                while ((tmp = bufferedReader.readLine()) != null) {
                    text += (tmp + "\n");
                }
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
            this.text = (T) text;
        } else {
            this.text = fname;
        }
    }


    public  <R> R convertBy (Function ... functionsTab) {
        Object res = this.text;
        for (int i = 0; i < functionsTab.length; i++) {
            res = functionsTab[i].apply(res);
        }
        return (R) res;
    }
}
