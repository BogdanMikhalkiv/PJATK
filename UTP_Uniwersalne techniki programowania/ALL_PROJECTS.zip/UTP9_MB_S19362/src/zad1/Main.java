/**
 *
 *  @author Mykhalkiv Bohdan S19362
 *
 */

package zad1;
import java.io.*;
import java.net.MalformedURLException;
import java.util.*;
import java.util.stream.Collectors;
public class Main {
   static int maximumLen = 0;
  public static int maxLen(List<String> list) {
    if(maximumLen < list.size()){
      maximumLen = list.size();
    }
    return maximumLen;
  }
  public static String MySort(String a) {
    String abcd = a;
    char[]chars = abcd.toCharArray();
    Arrays.sort(chars);
    String sorted = new String(chars);
    return sorted;
  }
  public static void main(String[] args) throws IOException {
    BufferedReader br = new BufferedReader(new FileReader("unixdict.txt"));
    Map<String, List<String>> anagram = br.lines().sorted().collect(Collectors.groupingBy(e -> MySort(e)));
    anagram.forEach((b1, b2) -> b2.remove(b1));
    anagram.forEach((b1, b2) -> maxLen(b2));
    Map<String, List<String>> listMap = anagram.entrySet().stream().filter(f -> maximumLen == f.getValue().size()).collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue));
    Map<String, List<String>> res =  listMap.entrySet().stream().sorted(Map.Entry.comparingByKey()).collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue, (oldValue, newValue) -> oldValue, LinkedHashMap::new));
    res.forEach((b1, b2) -> System.out.println(b1 + " " + b2));
  }
}
