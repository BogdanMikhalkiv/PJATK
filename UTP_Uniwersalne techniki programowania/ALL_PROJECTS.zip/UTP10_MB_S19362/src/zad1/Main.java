package zad1;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Main {
  static   JPanel panel = new JPanel();
    static   JPanel panel2 = new JPanel();
  static   JFrame frame = new JFrame("Thread pool");


    public static void main(String[] args) {


        JButton jStop = new JButton("Stop");
        JButton jCreate = new JButton("Create new");
        JTextArea jTextArea = new JTextArea(23,25);
        jTextArea.setEditable(false);
        JScrollPane jScrollPane = new JScrollPane(jTextArea);
        Watek.jTextArea = jTextArea;




        jCreate.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {

                JButton jButton = new JButton("T " + Watek.counter);
                Watek a = new Watek(jButton);
                jStop.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent actionEvent) {
                        a.stop();
                        if (!jButton.getText().startsWith("T")) {
                            jButton.setText("T" + a.index + " done");
                        }
                        jButton.setEnabled(false);
                        jCreate.setEnabled(false);
                        jStop.setEnabled(false);
                    }
                });
                jButton.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent actionEvent) {
                        if (jButton.getText().startsWith("T")) {
                            jButton.setText("Suspend T" + a.index);
                            a.start();
                        } else if (jButton.getText().startsWith("S")) {
                            jButton.setText("Continue T" + a.index);
                            a.setStatus(false);

                        } else if (jButton.getText().startsWith("C")) {
                            jButton.setText("Suspend T" + a.index);
                            a.setStatus(true);
                        }
                    }
                });
                SwingUtilities.updateComponentTreeUI(frame);
                panel.add(jButton);

            }
        });
        

        panel.add(jStop);
        panel.add(jCreate);
        SwingUtilities.updateComponentTreeUI(frame);


        panel.add(jScrollPane, BorderLayout.CENTER);
        frame.getContentPane().add(panel);




        frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        frame.setVisible(true);
        frame.setSize(320, 500);
    }


}
