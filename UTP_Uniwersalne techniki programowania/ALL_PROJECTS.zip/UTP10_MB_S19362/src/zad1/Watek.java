package zad1;

import javax.swing.*;
import java.util.Random;

public class Watek extends Thread {
    static int counter = 1;
    boolean status = true;
    Object synchr = new Object();
    Random random = new Random();
    int sum = 0;
    int r;
    int index;
    JButton jButton;
    static public JTextArea jTextArea = new JTextArea();
    public Watek(JButton jButton)  {
        index = counter;
        counter++;
        this.jButton = jButton;

    }
    public void setStatus(boolean b) {
        this.status = b;
        synchronized (synchr){
            synchr.notify();
        }
    }
    public void run() {
        while (!isInterrupted() && sum <= (index * 1000)) {
            synchronized (synchr) {
                if (status == false) {
                    try {
                        jTextArea.append("Thread" + index + " Stoped!" + "\n");
                        synchr.wait();
                    } catch (InterruptedException e) {
                    }
                }
            }
            r = random.nextInt(100);
            sum += r;
            try {
                jTextArea.append("Thread " + index + "(limit = " + (index*1000) + "): "  +  r  + " sum = "+ sum + "\n");
                //System.out.println("Thread " + index +  " " +  r  + " "+ sum);
                sleep(500);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        jTextArea.append("Thread " + index  + " end" + "\n");
        jButton.setText("T " + index  + " done!");
        jButton.setEnabled(false);
        try {
            sleep(2000);
            Main.panel.remove(jButton);
            SwingUtilities.updateComponentTreeUI(Main.frame);
        } catch (InterruptedException e) {
        }

        System.out.println("thread " + index  + " end") ;
    }

}
