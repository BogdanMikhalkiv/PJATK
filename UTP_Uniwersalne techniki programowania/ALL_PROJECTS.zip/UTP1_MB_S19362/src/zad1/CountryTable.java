package zad1;

import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;
import java.awt.*;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class CountryTable extends JTable {
    String countriesFileName;
    JTable table = null;
    String[] regexArr;
    Object [][] data = new Object[252][4];
    Object [] nazwyKolumn = new Object[4];
    public CountryTable(String countriesFileName) {
        this.countriesFileName = countriesFileName;
    }


    public JTable create() {
        int counter = 1;
        try(BufferedReader br = new BufferedReader(new FileReader("data/countries.txt")))  {
            String tmp;
            String[] tmpStrArr;
            int i = 0;
            double d = 0;
            while((tmp = br.readLine())!=null) {
                if(counter == 1) {
                    tmpStrArr = tmp.split("\\t");
                    nazwyKolumn = tmpStrArr;
                    counter++;
                } else {
                    tmpStrArr = tmp.split("\\t");
                    data[i][0] =  new ImageIcon(new ImageIcon("data/" + tmpStrArr[0] + ".gif").getImage().getScaledInstance(60,40,2));
                    data[i][1] = tmpStrArr[1];
                    data[i][2] = tmpStrArr[2];
                    regexArr = tmpStrArr[3].split("\\s");
                    data[i][data[i].length-1] = Integer.parseInt(regexArr[0]);

                    i++;
                }
            }
        }
        catch(IOException ex){
            System.out.println(ex.getMessage());
        }

        DefaultTableModel model = new DefaultTableModel(data, nazwyKolumn) {
            public Class getColumnClass(int column) {
                return getValueAt(0, column).getClass();
            }

            @Override
            public boolean isCellEditable(int row, int column) {
                switch (column) {
                    case 3:
                        return true;
                    default:
                        return false;
                }
            }
        };

       table  = new JTable(model);
        return table;
    }
}
