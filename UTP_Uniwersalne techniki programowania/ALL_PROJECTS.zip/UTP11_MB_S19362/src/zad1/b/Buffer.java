package zad1.b;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class Buffer {
    int pojemnosc;
    int counterl = 0;
    ArrayBlockingQueue<Integer> list ;
    Lock lock;
    Condition condition;
    Condition condition2;
    int count = 0;


    public Buffer (int pojemnosc) {
        this.pojemnosc = pojemnosc;
        list = new ArrayBlockingQueue<>(pojemnosc);
        this.lock = new ReentrantLock();
        condition = lock.newCondition();
        condition2 = lock.newCondition();
    }



    public void put (int buffer) throws InterruptedException {
        if (counterl < pojemnosc) {
            list.put(buffer);
        }
        counterl++;
    }
}
