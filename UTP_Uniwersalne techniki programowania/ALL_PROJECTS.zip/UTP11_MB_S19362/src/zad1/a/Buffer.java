package zad1.a;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class Buffer {
    int pojemnosc;
    int counterl = 0;
    List<Integer> list = new ArrayList<>();
    Lock lock;
    Condition condition;
    Condition condition2;


    public Buffer (int pojemnosc) {
        this.pojemnosc = pojemnosc;
        this.lock = new ReentrantLock();
        condition = lock.newCondition();
        condition2 = lock.newCondition();

    }

    public int get (int i) {
        int res = list.get(i);
        list.remove(i);
        counterl--;
       return res;
    }

    public void put (int buffer) {
        if (counterl < pojemnosc) {
            list.add(buffer);
        }
        counterl++;
    }
}
