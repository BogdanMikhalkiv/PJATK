package zad1.a;

import java.util.Random;

public class Consumer implements Runnable {
    Random random = new Random();
    Buffer buffer;

    int i = 0;
    int val;
    public Consumer (Buffer b) {
        this.buffer = b;

    }
    @Override
    public void run() {
        for (; ;) {
            buffer.lock.lock();
            try {
                while (buffer.list.isEmpty()) {
                    System.out.println("consumer waitg-------");
                    buffer.condition.await();
                }
                val = buffer.get(0);
                i++;
                System.out.println("consumer " + val);
                buffer.condition2.signal();
            } catch (InterruptedException e) {
                e.getStackTrace();
            } finally {
                buffer.lock.unlock();
            }
            int j = random.nextInt(2);

            try {
                Thread.sleep(j*1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }


        }
    }
}
