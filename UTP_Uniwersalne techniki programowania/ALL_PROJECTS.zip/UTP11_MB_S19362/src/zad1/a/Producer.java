package zad1.a;

import java.util.Random;

public class Producer implements Runnable {
    Random random = new Random();
    Buffer buffer;

    public Producer (Buffer b) {
        this.buffer = b;

    }
    @Override
    public void run() {
        for (; ;) {
            buffer.lock.lock();
            try {


                while (buffer.counterl == buffer.pojemnosc) {
                    System.out.println("producent wait--------");
                    buffer.condition2.await();

                }
                int i = random.nextInt(100);
                buffer.put(i);
                System.out.println("producent " + i);

                buffer.condition.signal();

            } catch (InterruptedException e) {
                e.printStackTrace();
            } finally {
                buffer.lock.unlock();
            }
            int j = random.nextInt(2);
            try {
                Thread.sleep(j * 1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

}
