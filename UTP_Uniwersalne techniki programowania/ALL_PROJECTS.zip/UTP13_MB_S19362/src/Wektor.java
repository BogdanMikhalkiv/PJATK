import java.util.ArrayList;
import java.util.List;

public class Wektor {
    List<Double> tab = new ArrayList();


    public Wektor (List<Double> tab) {
        this.tab = tab;
    }

    void dlugoscWektora() {
        int suma = 0;
        for (int i = 0; i < tab.size(); i++) {
            tab.set(i, Math.pow(tab.get(i), 2));
            suma += tab.get(i);
        }

        System.out.println(Math.sqrt(suma));
    }
}
