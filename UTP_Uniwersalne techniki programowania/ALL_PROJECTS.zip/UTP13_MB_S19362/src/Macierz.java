public class Macierz {
    int s,f;

    int[][] a;

    public Macierz (int s , int f) {
        this.s = s;
        this.f = f;
        a = new int[s][f];
    }

    void addMat(int [][] mat) {
        a = mat;
    }


    void plius (Macierz d) {
        if (a.length == d.a.length) {
            for (int i = 0; i < a.length; i++) {
                for (int j = 0; j < a[i].length; j++) {
                    a[i][j] += d.a[i][j];
                }
            }
            show();
        } else {
            System.out.println("размеры не совпадают");
        }
    }

    void myMetod (int k) {
        for (int i = 0; i < a.length; i++) {
            for (int j = 0; j < a[i].length; j++) {
                a[i][j] *= k;
            }
        }
        show();
    }


    void show () {
        for (int i = 0; i < a.length; i++) {
            for (int j = 0; j < a[i].length; j++) {
                System.out.print(a[i][j] + " ");
            }
            System.out.println();
        }
    }
//    void Mult (Macierz A) {
//        if (f == A.s) {
//            int [][] b = new int [s][A.f];
//            for (int i = 0; i < a.length; i++) {
//                int z = 0;
//                for (int j = 0; j < a[i].length; j++) {
//                    z += (a[i][j] * A.a[j][i]);
//                }
//                for (int j = 0; j < b.length; j++) {
//                    for (int k = 0; k < ; k++) {
//
//                    }
//                }
//            }
//        }
//    }
}
