import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        int [][] mas1 = {
                {1,2},
                {3,4}
        };

        int [][] mas2 = {
                {3,8},
                {6,5}
        };
        Macierz macierz = new Macierz(2, 2);
        Macierz macierz2 = new Macierz(2, 2);

        macierz.addMat(mas1);
        macierz2.addMat(mas2);

        System.out.println();
        macierz.plius(macierz2);
    }
}
