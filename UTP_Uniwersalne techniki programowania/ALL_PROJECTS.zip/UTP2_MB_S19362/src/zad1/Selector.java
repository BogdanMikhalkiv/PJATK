/**
 *
 *  @author Mykhalkiv Bohdan S19362
 *
 */

package zad1;


public interface Selector<A> { // Uwaga: interfejs musi być sparametrtyzowany
        public boolean select(A a);
}
