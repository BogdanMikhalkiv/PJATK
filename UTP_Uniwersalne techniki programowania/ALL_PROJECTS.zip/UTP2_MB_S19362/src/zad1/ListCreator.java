/**
 *
 *  @author Mykhalkiv Bohdan S19362
 *
 */

package zad1;


import java.util.ArrayList;
import java.util.List;


public class ListCreator { // Uwaga: klasa musi być sparametrtyzowana
        List list;
        List listWhen = new ArrayList();
        List listMap = new ArrayList();

    public ListCreator(List list) {
        this.list = list;
    }


    public static ListCreator collectFrom (List list1) {
            return new ListCreator(list1);
    }

      public ListCreator when (Selector selector) {
            for (int i = 0; i < list.size(); i++) {
                if (selector.select(list.get(i))) {
                    listWhen.add(list.get(i));
                }
            }
            return this;
        }

       public List mapEvery (Mapper mapper) {
           for (int i = 0; i < listWhen.size(); i++) {
               listMap.add(mapper.map(listWhen.get(i)));
           }
           return listMap;
       }




}
