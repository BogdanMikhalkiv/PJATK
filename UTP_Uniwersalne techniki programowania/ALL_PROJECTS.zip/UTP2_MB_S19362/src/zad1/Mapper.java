/**
 *
 *  @author Mykhalkiv Bohdan S19362
 *
 */

package zad1;


public interface Mapper<T, C> { // Uwaga: interfejs musi być sparametrtyzowany
        public C map (T t);
}
