/**
 *
 *  @author Mykhalkiv Bohdan S19362
 *
 */

package zad1;



import org.json.JSONArray;
import org.json.JSONObject;

import java.io.*;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Service {
    String country;
    String city;
    String code;
    String code2;
    List<Kraj> listCountry = new ArrayList<>();
    public Service(String country) {
        this.country = country;
        String line;
        String [] arr;
        try (Scanner scanner = new Scanner(new File("Data/dane.txt"))){
            while (scanner.hasNextLine()) {
                    line = scanner.nextLine();
                    arr = line.split("\\t");
                    listCountry.add(new Kraj(arr[0],arr[2]));
                }
        } catch (IOException e) {
            e.getStackTrace();
        }
        for (int i = 0; i < listCountry.size(); i++) {
            if (listCountry.get(i).kraj.toLowerCase().contains(country.toLowerCase())){
                code2 = listCountry.get(i).code;
            }
        }
    }

    public String getWeather(String city) {
        this.city = city;

        StringBuffer content = new StringBuffer();

        try {
            URL url = new URL("http://api.openweathermap.org/data/2.5/weather?q=" + city + "&appid=b6367bd40dfb51859897db09261f4e1c&units=metric");
            URLConnection urlConn = url.openConnection();

            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(urlConn.getInputStream()));
            String line;

            while((line = bufferedReader.readLine()) != null) {
                content.append(line);
            }
            bufferedReader.close();
        } catch(Exception e) {
            System.out.println("nie ma takiego miasta");
        }
        return content.toString();
    }

    public Double getRateFor(String rate) {
        StringBuffer content = new StringBuffer();
        code = rate;
        try {
            URL url = new URL("https://api.exchangerate.host/latest?base="+ rate + "&symbols=" + code2);
            URLConnection urlConn = url.openConnection();

            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(urlConn.getInputStream()));
            String line;

            while((line = bufferedReader.readLine()) != null) {
               // System.out.println(line);
                content.append(line + "\n");
            }
            bufferedReader.close();
        } catch(Exception e) {
            System.out.println("nie ma takiej waluty");
        }
        String result = content.toString();
        JSONObject object = new JSONObject(result);



        return object.getJSONObject("rates").getDouble(code2);
    }

    public Double getNBPRate() {

        StringBuffer content = new StringBuffer();
        String result = "";
        String result2 = "";
        //tablica A
        try {
            URL url = new URL("http://api.nbp.pl/api/exchangerates/tables/"+"a"+"/");
            URLConnection urlConn = url.openConnection();

            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(urlConn.getInputStream()));
            String line;

            while((line = bufferedReader.readLine()) != null) {
                result += line ;
            }
            bufferedReader.close();
        } catch(Exception e) {
            System.out.println("nie ma takiej waluty");
        }
        //tablica B
        try {
            URL url = new URL("http://api.nbp.pl/api/exchangerates/tables/"+"b"+"/");
            URLConnection urlConn = url.openConnection();

            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(urlConn.getInputStream()));
            String line;

            while((line = bufferedReader.readLine()) != null) {
                result2 += line ;
            }
            bufferedReader.close();
        } catch(Exception e) {
            System.out.println("nie ma takiej waluty");
        }

        JSONArray jsonArray =  new JSONArray(result);
        JSONObject object = jsonArray.getJSONObject(0);
        double rates = 0;


        for (int j = 0; j < object.getJSONArray("rates").length(); j++) {
            JSONObject object1 = (JSONObject) object.getJSONArray("rates").get(j);
            if (object1.get("code").equals(code2)) {
                rates = object1.getDouble("mid");
                break;
            }
        }
        if (rates == 0) {
            JSONArray jsonArray2 =  new JSONArray(result2);
            JSONObject object2 = jsonArray2.getJSONObject(0);

            for (int j = 0; j < object2.getJSONArray("rates").length(); j++) {
                JSONObject object1 = (JSONObject) object2.getJSONArray("rates").get(j);
                if (object1.get("code").equals(code2)) {
                    rates = object1.getDouble("mid");
                    break;
                }
            }
            if (rates == 0) {
                System.out.println("nie ma takiej waluty albo dany kraj jest Polska");
            }
        }


        return rates;
    }
}  
