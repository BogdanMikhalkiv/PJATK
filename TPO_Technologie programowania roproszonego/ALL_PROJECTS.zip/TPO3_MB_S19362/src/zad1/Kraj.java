package zad1;

public class Kraj {
    String kraj;
    String code;

    public Kraj(String kraj, String code)  {
        this.code = code;
        this.kraj = kraj;
    }
}
