package zad1;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class MainServlet  extends HttpServlet {

      String url = "jdbc:mysql://localhost:3306/my_playground";
       String user = "root";
       String password = "73torrent1";

    // JDBC variables for opening and managing connection
   Connection con;
     Statement stmt;
     ResultSet rs;

    @Override
    public void init() throws ServletException {
//        try {
//            con = DriverManager.getConnection(url, user, password);
//        } catch (Exception exc) {
//            throw new ServletException("Connection failed...", exc);
//        }
        super.init();

        log("init");
    }

    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
//        resp.setContentType("text/html; charset=windows-1250");
//        PrintWriter out = resp.getWriter();
//        out.println("<h2>Books in store</h2>");
//        String sel = "select * from books";
//        out.println("<ol>");
//
//        //String query = "select * from books";
//
//        List <Book> myBooks = new ArrayList<Book>();
//
//        try  {
//            Statement stmt = con.createStatement();
//            ResultSet rs = stmt.executeQuery(sel);
//            while (rs.next()) {
//                myBooks.add(new Book(rs.getInt(1),rs.getString(2), rs.getString(3)));
//            }
//            for (int i = 0; i < myBooks.size(); i++) {
//                out.println("<li>" + myBooks.get(i).id + " - name: " + myBooks.get(i).name +  " -  author" + myBooks.get(i).author +"</li>");
//            }
//            rs.close();
//            stmt.close();
//        } catch (SQLException exc)  {
//            out.println(exc.getMessage());
//        }
//        out.close();

        super.service(req,resp);
        resp.getWriter().write("service");

    }

    @Override
    public void destroy() {
//        try {
//            con.close();
//        } catch (Exception exc) {}

        log("destroy");
    }

    public void doGet(HttpServletRequest request,
                      HttpServletResponse response)
            throws ServletException, IOException
    {
//        service(request, response);

        log("get");
    }

//    public void doPost(HttpServletRequest request,
//                       HttpServletResponse response)
//            throws ServletException, IOException
//    {
//        service(request, response);
//    }
}
