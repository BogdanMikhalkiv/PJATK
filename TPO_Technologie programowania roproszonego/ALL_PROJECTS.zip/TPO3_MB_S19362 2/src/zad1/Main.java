/**
 *
 *  @author Mykhalkiv Bohdan S19362
 *
 */

package zad1;


import javafx.application.Platform;
import javafx.embed.swing.JFXPanel;
import javafx.event.EventHandler;
import javafx.geometry.Side;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.web.WebEngine;
import javafx.scene.web.WebView;
import org.json.JSONObject;
import org.w3c.dom.Document;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Main {
  public static void main(String[] args) {
    Service s = new Service("Madagascar");
    String weatherJson = s.getWeather("Warsaw");
    Double rate1 = s.getRateFor("USD");
    Double rate2 = s.getNBPRate();
    System.out.println(rate2);


    // ...
    // część uruchamiająca GUI
    JSONObject object = new JSONObject(weatherJson);
    JFrame frame = new JFrame("TPO");

    frame.setLayout(new GridLayout());

    JLabel locationTemp = new JLabel(  "Pogoda: " +s.city + " temperatura aktualna - "+ object.getJSONObject("main").getDouble("temp") + " °С, " +
             "humidity - " + object.getJSONObject("main").getDouble("humidity") + "%, " +
            "pressure - " + object.getJSONObject("main").getDouble("pressure"));
    JLabel rateFor = new JLabel( "rate1: 1 " + s.code + " = "+ rate1 + " " + s.code2);
    JLabel rateForNBP = new JLabel( "rate2 :1 " + s.code2 + " = "+ rate2 + " PLN" );

    JTextArea jTextArea = new JTextArea(23,25);
    JPanel jPanel = new JPanel();
    jPanel.setLayout(new GridLayout(3,1,1,1));
    JButton web = new JButton("Go");




    //frame.add(location, BorderLayout.NORTH);

    jPanel.add(locationTemp);
    jPanel.add(rateFor);
    jPanel.add(rateForNBP);

      jPanel.setSize(new Dimension(300, 300));
      jPanel.setLocation(new Point(0, 27));

    frame.getContentPane().add(jPanel);

    frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
    frame.setVisible(true);
    frame.setSize(700, 200);


  }


}
