package zad1;

import javafx.scene.web.WebEngine;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.nio.channels.FileChannel;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.EnumSet;

public class Futil extends SimpleFileVisitor<Path> {

   static FileChannel fileChannel ;
   static FileChannel writeFile;
   static ByteBuffer byteBuffer;


    public static void processDir(String dirName, String resultFileName) {
        WebEngine webEngine = new WebEngine();
        try {
                File file = new File(resultFileName);
                if (file.exists()) {
                    file.delete();
                    file.createNewFile();
                }

                writeFile = FileChannel.open(Paths.get(String.valueOf(file)), EnumSet.of(StandardOpenOption.CREATE,  StandardOpenOption.WRITE));

                 Files.walkFileTree(Path.of(dirName), new SimpleFileVisitor<Path>() {
                    public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) throws IOException {
                        if (attrs.isRegularFile()) {
                            try {
                                fileChannel = FileChannel.open(file);
                                byteBuffer = ByteBuffer.allocate((int) (new File(file.toString()).length()));
                                byteBuffer.clear();
                                fileChannel.read(byteBuffer);
                            } catch (IOException e) {
                                e.printStackTrace();
                            }
                            byteBuffer.flip();
                            CharBuffer buffer = Charset.forName("Cp1250").decode(byteBuffer);
                            ByteBuffer byteB = StandardCharsets.UTF_8.encode(buffer);

                            byteB.clear();

                            while (byteB.hasRemaining()) {
                                try {

                                    writeFile.write(byteB);
                                } catch (IOException e) {
                                    e.printStackTrace();
                                }

                            }


                        }
                        return FileVisitResult.CONTINUE;
                    }
                });
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}





