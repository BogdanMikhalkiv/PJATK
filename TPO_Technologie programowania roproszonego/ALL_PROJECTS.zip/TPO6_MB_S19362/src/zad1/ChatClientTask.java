/**
 *
 *  @author Mykhalkiv Bohdan S19362
 *
 */

package zad1;


import java.util.List;
import java.util.concurrent.*;


public class ChatClientTask extends FutureTask<ChatClient> {



    public static ChatClientTask create(ChatClient chatClient, List<String> messages, int waitT) {

        return new ChatClientTask(() -> {

            chatClient.login();

            if (waitT != 0) {
                Thread.sleep(waitT);
            }
            for (int i = 0; i < messages.size(); i++) {
                chatClient.send(messages.get(i));
                if (waitT!=0){
                    Thread.sleep(waitT);
                }
            }
            chatClient.logout();
            if (waitT != 0) {
                Thread.sleep(waitT);
            }
            return chatClient;
        });
    }



    public ChatClient getClient() {
        try {
            return this.get();
        } catch (InterruptedException | ExecutionException e) {
            e.printStackTrace();
        }
        return null;
    }

    public ChatClientTask(Callable<ChatClient> callable) {
        super(callable);
    }
}

