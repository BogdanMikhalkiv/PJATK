/**
 *
 *  @author Mykhalkiv Bohdan S19362
 *
 */

package zad1;


import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.SocketAddress;
import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.nio.channels.SocketChannel;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;

public class ChatClient {


    String id;
    String host;
    int port;

    static Charset charset = StandardCharsets.UTF_8;

     SocketChannel connectSocket;

    String clientLog = "";



    public ChatClient(String host, int port, String id) {
        clientLog += "=== " + id + " chat view\n";

        this.id = id;
        this.host = host;
        this.port = port;

        try {
            connectSocket = SocketChannel.open();
            connectSocket.configureBlocking(false);
            SocketAddress socketAddr = new InetSocketAddress(host, port);
            connectSocket.connect(socketAddr);

            while (!connectSocket.finishConnect()) {
            }

        } catch (IOException ioe) {
            ioe.printStackTrace();
        }

    }


    public void login() {
        send("auth login " + id);
    }

    public void logout() {
        send("auth logout " + id);
        clientLog += id +" logged out\n";
    }


    public void send(String req) {
        ByteBuffer sendBuffer = ByteBuffer.allocateDirect(req.getBytes().length);
        ByteBuffer readBuffer = ByteBuffer.allocateDirect(1024);
        try {
            sendBuffer.put(charset.encode(req));
            sendBuffer.flip();
            connectSocket.write(sendBuffer);
            connectSocket.read(readBuffer);
            readBuffer.flip();
            CharBuffer charBuffer = charset.decode(readBuffer);
            clientLog += charBuffer.toString();
        } catch (IOException  e) {
            e.printStackTrace();
        }
    }

    public String getChatView() {
        return clientLog;
    }


}