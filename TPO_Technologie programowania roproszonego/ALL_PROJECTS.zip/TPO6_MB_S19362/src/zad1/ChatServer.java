/**
 *
 *  @author Mykhalkiv Bohdan S19362
 *
 */

package zad1;


import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.UnknownHostException;
import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.time.LocalTime;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import static java.nio.channels.SelectionKey.OP_WRITE;

public class ChatServer implements Runnable {

     String host;
     int port;
     boolean IsRunning;

     ServerSocketChannel serverSocketChannel;

    Thread serverThread = new Thread(this);
     SelectionKey selectionKey;

    String serverLog = "";
    Selector selector;
    static Charset charset = StandardCharsets.UTF_8;

     Map<SocketChannel, String> clientInfo;

    public ChatServer(String host, int port) {
        this.host = host;
        this.port = port;
        clientInfo = new HashMap<>();
    }

    public String getTrueTime(LocalTime localTime) {
        String s1 = String.valueOf(LocalTime.now());
        String result = s1.substring(0,12);
        return result + " ";
    }

    public int getSwitch(String[] str) {
        if (str[0].equals("auth")) {
            return 1;
        } else {
            return 2;
        }
    }


    public void sendLog(SocketChannel client, String message) throws IOException {
        ByteBuffer byteBuffer = ByteBuffer.allocateDirect(message.getBytes().length);
        byteBuffer.put(charset.encode(message));
        byteBuffer.flip();
        client.write(byteBuffer);
    }

    public void startServer() {
        IsRunning = true;
        serverThread.start();
    }

    public void stopServer() {
        IsRunning = false;
        System.out.println("Server stopped");

    }

    public String getServerLog() {
        return serverLog;
    }

    @Override
    public void run() {
        try {

            serverSocketChannel = ServerSocketChannel.open();
            serverSocketChannel.configureBlocking(false);
            InetSocketAddress inetSocketAddress = new InetSocketAddress(host,port);
            serverSocketChannel.socket().bind(inetSocketAddress);
            System.out.println("Server started\n");


            selector = Selector.open();
            serverSocketChannel.register(selector, SelectionKey.OP_ACCEPT);

        } catch (IOException ioe) {
            ioe.printStackTrace();
            System.exit(1);
        }

        try {
            while (IsRunning == true) {
                selector.select();
                Set<SelectionKey> keys = selector.selectedKeys();
                Iterator<SelectionKey> iterator = keys.iterator();
                while (iterator.hasNext()) {
                    selectionKey = iterator.next();
                    iterator.remove();
                    if (selectionKey.isAcceptable()) {
                        SocketChannel socketChannel = serverSocketChannel.accept();
                        socketChannel.configureBlocking(false);
                        socketChannel.register(selector, SelectionKey.OP_READ | OP_WRITE);
                    }
                    if (selectionKey.isReadable()) {
                        SocketChannel socketChannel = (SocketChannel) selectionKey.channel();
                        ByteBuffer inBuffer = ByteBuffer.allocateDirect(1024);
                        String req;
                        inBuffer.clear();
                        int readByte = socketChannel.read(inBuffer);
                        if (readByte == 0) {
                            Thread.sleep(200);
                        } else if (readByte == -1) {
                            serverSocketChannel.close();
                        } else {
                            String idClient = "";

                            String Log;
                            String clientLog = "";

                            if (clientInfo.containsKey(socketChannel)) {

                                idClient = clientInfo.get(socketChannel);
                            }

                            inBuffer.flip();
                            CharBuffer buffer = charset.decode(inBuffer);
                            req = buffer.toString();

                            String[] content = req.split(" ");

                            switch (getSwitch(content)){
                                case 1 :
                                    if (content[1].equals("login")) {
                                        idClient = content[2].trim();
                                        clientInfo.put(socketChannel, idClient);
                                        clientLog = idClient + " logged in\n";
                                        Log = getTrueTime(LocalTime.now())  + clientLog;
                                        serverLog += Log;
                                    } else {
                                        clientLog = idClient + " logged out\n";
                                        Log = getTrueTime(LocalTime.now())  + clientLog;
                                        serverLog+=Log;
                                        clientInfo.remove(socketChannel);

                                    }
                                    break;
                                case 2 :
                                    clientLog = idClient + ": " + req + "\n";
                                    Log = getTrueTime(LocalTime.now()) + clientLog;
                                    this.serverLog+=Log;
                                    break;
                            }

                            for (SocketChannel client : clientInfo.keySet()) {
                                sendLog(client, clientLog);
                            }
                        }
                    }
                }
            }
        } catch (UnknownHostException exc) {
            System.err.println("Unknown host " + host);
        } catch (Exception exc) {
            exc.printStackTrace();
        }
    }
}
