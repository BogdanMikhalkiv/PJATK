/**
 *
 *  @author Mykhalkiv Bohdan S19362
 *
 */

package zad1;



import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.SimpleDateFormat;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;

public class Time {
    public static String passed(String from, String to) {
        DateTimeFormatter isoLocalDate = DateTimeFormatter.ISO_LOCAL_DATE;
        try {
            if (from.length()< 11) {
                SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-mm-dd");

                String [] dniTygodnia = {"poniedziałek", "wtorek", "środa", "czwartek", "piątek", "sobota", "niedziela"};
                String [] months = {"stycznia", "lutego", "marca", "kwietnia", "maja", "czerwca", "lipca", "sierpnia", "września" , "października", "listopada", "grudnia"};

                String [] tab1 = from.split("-");
                String [] tab2 = to.split("-");

                LocalDate date1 = LocalDate.parse(from, isoLocalDate);
                LocalDate date2 = LocalDate.parse(to, isoLocalDate);
                Period period = Period.between(date1,date2);
                long periodDays = ChronoUnit.DAYS.between(date1, date2);
                double periodWeeks = (double) ChronoUnit.DAYS.between(date1, date2)/7;
                BigDecimal bd = new BigDecimal(Double.toString(periodWeeks));
                bd = bd.setScale(2, RoundingMode.HALF_UP);
                double periodWeeks2 = bd.doubleValue();

                String s = tab1[2];
                String s3 = tab2[2];
                String s2 = "";

                if (Double.valueOf(s) <= 9) {
                    s2 = String.valueOf(s.charAt(1));
                    tab1[2] = s2;
                }
                if (Double.valueOf(s3) <= 9) {
                    s2 = String.valueOf(s3.charAt(1));
                    tab2[2] = s2;
                }


                int dayOfWeek = date1.getDayOfWeek().getValue();
                int dayOfWeek2 = date2.getDayOfWeek().getValue();

                int monthsNumber = date1.getMonth().getValue();
                int monthsNumber2 = date2.getMonth().getValue();

                String line = "";

                if (periodDays != 0) {

                    line = "Od " + tab1[2] + " " + months[monthsNumber-1] + " " + tab1[0] + " ("+ dniTygodnia[dayOfWeek-1] + ") " + "do " + tab2[2] + " "+  months[monthsNumber2-1] + " " + tab2[0] + " (" + dniTygodnia[dayOfWeek2-1] + ")\n"
                            + "- mija: " + periodDays + " " + trueDay(periodDays) + ", tygodni " + periodWeeks2 + "\n"
                            + "- kalendarzowo: ";
                    if (period.getYears() > 0) {
                        line += period.getYears() + " " +  trueYear(period.getYears()) + ", ";
                    }
                    if (period.getMonths() > 0) {
                        line += period.getMonths() + " " + trueMonth(period.getMonths()) + ", ";
                    }
                    if (period.getDays() >  0) {
                        line +=  period.getDays() + " " + trueDay(period.getDays()) + ", ";
                    }
                    // + period.getYears() + trueYear(period.getYears()) +  ", " + period.getMonths() + " " + trueMonth(period.getMonths()) + ", " + period.getDays() + " dni" + "\n";
                } else {
                    line = "Od " + tab1[2] + " " + months[monthsNumber - 1] + " " + tab1[0] + " (" + dniTygodnia[dayOfWeek - 1] + ") " + "do " + tab2[2] + " " + months[monthsNumber2 - 1] + " " + tab2[0] + " (" + dniTygodnia[dayOfWeek2 - 1] + ")\n"
                            + "- mija: " + periodDays + " " + trueDay(periodDays) + ", tygodni " + periodWeeks2 + "\n";
                }
                return line;
            }
            if (from.length() > 10) {
                ZonedDateTime zonedDateTime = LocalDateTime.parse(from,DateTimeFormatter.ISO_DATE_TIME).atZone(ZoneId.systemDefault());
                ZonedDateTime zonedDateTime2 = LocalDateTime.parse(to,DateTimeFormatter.ISO_DATE_TIME).atZone(ZoneId.systemDefault());
                SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-mm-dd");

                String [] dniTygodnia = {"poniedziałek", "wtorek", "środa", "czwartek", "piątek", "sobota", "niedziela"};
                String [] months = {"stycznia", "lutego", "marca", "kwietnia", "maja", "czerwca", "lipca", "sierpnia", "września" , "października", "listopada", "grudnia"};

                String [] tab = from.split("T");
                String[] tab1 = tab[0].split("-");
                String [] tab5 = to.split("T");
                String[] tab2 = tab5[0].split("-");


//            LocalDate date1 = LocalDate.parse(from, zonedDateTime);
//            LocalDate date2 = LocalDate.parse(to, zonedDateTime2);
                Period period = Period.between(zonedDateTime.toLocalDate(),zonedDateTime2.toLocalDate());
                long periodDays = ChronoUnit.DAYS.between(zonedDateTime, zonedDateTime2);
                double periodWeeks = (double) ChronoUnit.DAYS.between(zonedDateTime, zonedDateTime2)/7;
                long peroidHour = ChronoUnit.HOURS.between(zonedDateTime, zonedDateTime2);
                long periodMinut =  ChronoUnit.MINUTES.between(zonedDateTime,zonedDateTime2);
                BigDecimal bd = new BigDecimal(Double.toString(periodWeeks));
                bd = bd.setScale(2, RoundingMode.HALF_UP);
                double periodWeeks2 = bd.doubleValue();

                String s = tab1[2];
                String s3 = tab2[2];
                String s2 = "";

//                if (Double.valueOf(s) <= 9) {
//                    s2 = String.valueOf(s.charAt(1));
//                    tab1[2] = s2;
//                }
//                if (Double.valueOf(s3) <= 9) {
//                    s2 = String.valueOf(s3.charAt(1));
//                    tab2[2] = s2;
//                }


                int dayOfWeek = zonedDateTime.getDayOfWeek().getValue();
                int dayOfWeek2 = zonedDateTime2.getDayOfWeek().getValue();

                int monthsNumber = zonedDateTime.getMonth().getValue();
                int monthsNumber2 = zonedDateTime2.getMonth().getValue();

                String line = "";

                if (periodDays != 0) {

                    line = "Od " + tab1[2] + " " + months[monthsNumber-1] + " " + tab1[0] + " ("+ dniTygodnia[dayOfWeek-1] + ") godz. "  + tab[1]  + " do " + tab2[2] + " "+  months[monthsNumber2-1] + " " + tab2[0] + " (" + dniTygodnia[dayOfWeek2-1] + ") godz. " + tab5[1] +  "\n"
                            + "- mija: " + periodDays + " " + trueDay(periodDays) + ", tygodni " + periodWeeks2 + "\n"
                            + "- godzin: " + peroidHour + ", minut: " + periodMinut + "\n"
                            + "- kalendarzowo: ";
                    if (period.getYears() > 0) {
                        line += period.getYears() + " " +  trueYear(period.getYears()) + ", ";
                    }
                    if (period.getMonths() > 0) {
                        line += period.getMonths() + " " + trueMonth(period.getMonths()) + ", ";
                    }
                    if (period.getDays() >  0) {
                        line +=  period.getDays() + " " + trueDay(period.getDays()) + ", ";
                    }
                    // + period.getYears() + trueYear(period.getYears()) +  ", " + period.getMonths() + " " + trueMonth(period.getMonths()) + ", " + period.getDays() + " dni" + "\n";
                } else {
                    line = "Od " + tab1[2] + " " + months[monthsNumber - 1] + " " + tab1[0] + " (" + dniTygodnia[dayOfWeek - 1] + ") " + "do "  + " " + months[monthsNumber2 - 1] + " " + tab2[0] + " (" + dniTygodnia[dayOfWeek2 - 1] + ")\n"
                            + "- mija: " + periodDays + " " + trueDay(periodDays) + ", tygodni " + periodWeeks2 + "\n"
                            + "- godzin: " + peroidHour + ", minut: " + periodMinut + "\n";

                }

                return  line;
            }
        } catch (Exception e) {
            return "***" + e.fillInStackTrace();
        }

        return "fgf";
    }

    static String trueMonth (double month) {
        String line = "";
        if (month == 1) {
            line = "miesiąc";
        }
        if (month > 1 && month <= 4) {
            line = "miesiące";
        }
        if (month >= 5) {
            line = "miesięcy";
        }
        return line;
    }

    static  String trueDay (double day) {
        String line = "";
        if (day == 1) {
            line = "dzień";
        } else {
            line = "dni";
        }
        return line;
    }

    static String trueYear (double year) {
        String line = "";

        if (year == 1) {
            line = "rok";
        }
        if (year > 1 && year <= 4) {
            line = "lata";
        }
        if (year >= 5) {
            line = "lat";
        }
        return line;
    }
}
