/**
 *
 *  @author Mykhalkiv Bohdan S19362
 *
 */

package zad1;


import java.util.List;
import java.util.concurrent.ExecutionException;

public class ClientTask implements Runnable {
     Client c;
     List<String> requestList;

    boolean isReady = true;
    String clog = "";

    boolean showSendRes;

    public ClientTask(Client c, List<String> reqList, boolean showSendRes) {
        this.requestList = reqList;
        this.c = c;
        this.showSendRes = showSendRes;
    }

    public String get() throws InterruptedException, ExecutionException {

        while(isReady) {
            Thread.sleep(200);
        }


        return clog;
    }

    @Override
    public void run() {
        c.connect();
        c.send("login " + c.id);

        String result = "";

        for (int i = 0; i < requestList.size(); i++) {
            result = c.send(requestList.get(i));
            if (showSendRes) {
                System.out.println(result);
            }
        }

        clog = c.send("bye and log transfer");
        isReady = false;


    }

    public static ClientTask create(Client c, List<String> reqList, boolean showSendRes) {
        ClientTask myClient = new ClientTask(c, reqList, showSendRes);
        return myClient;
    }

}
