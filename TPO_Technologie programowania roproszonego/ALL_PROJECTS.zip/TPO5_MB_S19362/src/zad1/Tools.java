/**
 *
 *  @author Mykhalkiv Bohdan S19362
 *
 */

package zad1;


import org.yaml.snakeyaml.Yaml;

import java.io.*;
import java.lang.reflect.Constructor;
import java.util.*;

public class Tools {
    public static Options createOptionsFromYaml(String fileName) throws Exception {
        Options options = null;
        InputStream inputStream = new FileInputStream(new File(fileName));
        Yaml yaml = new Yaml();

        Map<String, Object> data = yaml.load(inputStream);
        Map<String, List<String>> clientsMap = new LinkedHashMap<>();

        clientsMap = (Map<String, List<String>>) data.get("clientsMap");

        String host = String.valueOf(data.get("host"));
        int port = Integer.parseInt(String.valueOf(data.get("port")));
        boolean concurMode = Boolean.parseBoolean(String.valueOf(data.get("concurMode")));
        boolean showSendRes = Boolean.parseBoolean(String.valueOf(data.get("showSendRes")));

        options = new Options(host,port,  concurMode, showSendRes , clientsMap);


        return options;
    }
}
