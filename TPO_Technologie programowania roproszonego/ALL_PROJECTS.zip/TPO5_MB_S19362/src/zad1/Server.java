/**
 *
 *  @author Mykhalkiv Bohdan S19362
 *
 */

package zad1;


import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.SocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.time.LocalTime;
import java.time.ZoneId;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;


public class Server implements Runnable
{
    String host;
    int port;

    Thread myServer = new Thread(this);

    SelectionKey selectionKey;

    ServerSocketChannel serverSocketChannel;

    boolean serverRunning;
    Selector selector;

    ZoneId zoneId = ZoneId.of("Europe/Warsaw");

    String resultServerLog = "";

    LocalTime timeNow = LocalTime.now(zoneId);
    String requestClient;
    HashMap<SocketChannel, String> names = new HashMap<>();


    Map<SocketChannel, String> myMap = new HashMap<>();



    public Server(String host, int port) {
        this.port = port;
        this.host = host;
    }



    @Override
    public void run() {
        try {

            serverSocketChannel = ServerSocketChannel.open();
            serverSocketChannel.configureBlocking(false);
            SocketAddress socketAddr = new InetSocketAddress(port);
            serverSocketChannel.socket().bind(socketAddr);
            selector = Selector.open();
            selectionKey = serverSocketChannel.register(selector, SelectionKey.OP_ACCEPT);

        } catch(IOException e) {
            e.printStackTrace();
        }


        while(serverRunning == true) {
            try {
                selector.selectNow();

                Set<SelectionKey> keys = selector.selectedKeys();
                Iterator<SelectionKey> iterator = keys.iterator();

                while(iterator.hasNext()) {
                    SelectionKey key = iterator.next();
                    iterator.remove();
                    if(key.isAcceptable()) {
                        SocketChannel socketClient = serverSocketChannel.accept();
                        socketClient.configureBlocking(false);
                        socketClient.register(selector, SelectionKey.OP_READ);
                        continue;
                    }
                    if(key.isReadable()) {

                        SocketChannel channel = (SocketChannel)key.channel();

                        Time time = new Time();
                        ByteBuffer bbuf = ByteBuffer.allocate(1024);

                        if(!channel.isOpen()) {
                            return;
                        }

                        int readBytes = 0;

                        try {
                            readBytes =  channel.read(bbuf);
                        }
                        catch(IOException e) {
                            e.printStackTrace();
                        }
                        requestClient = new String(bbuf.array(), 0 , readBytes);



                        switch (getSwitch(requestClient)) {
                            case 1 :
                                String elements[] = requestClient.split(" ");
                                names.put(channel, elements[1]);

                                resultServerLog += names.get(channel) + " logged in at " + this.timeNow + "\n";

                                myMap.put(channel,  "=== " + names.get(channel) + " log start === " + "\nlogged in");
                                try {
                                    channel.write(ByteBuffer.wrap("logged in ".getBytes()));
                                } catch(IOException e) {
                                    e.printStackTrace();
                                }
                                break;
                            case 2 :
                                try {
                                    channel.write(ByteBuffer.wrap("logged out".getBytes()));
                                    myMap.put(channel, myMap.get(channel) + "\nlogged out ");
                                }
                                catch(IOException e) {
                                    e.printStackTrace();
                                }
                                break;
                            case 3 :
                                resultServerLog += names.get(channel) + " logged out at " + this.timeNow + "\n";

                                myMap.put(channel, myMap.get(channel) + "\nlogged out\n=== " +  names.get(channel) + " log end ===\n");

                                try {
                                    channel.write(ByteBuffer.wrap(myMap.get(channel).getBytes()));
                                    channel.close();
                                    channel.socket().close();
                                } catch(IOException e) {
                                    e.printStackTrace();
                                }
                                break;
                            case 4 :
                                resultServerLog += names.get(channel) + " request at " + this.timeNow + ": " + (char) 34 + requestClient + (char) 34 + "\n";

                                String data;
                                if(!requestClient.contains("T")) {
                                    data = new String(requestClient.getBytes(), 0, 21);
                                } else {
                                    data = new String(requestClient.getBytes(), 0, 33);
                                }
                                String elements2[] = data.split(" ");

                                try {
                                    String dataOdDataDo = time.passed(elements2[0], elements2[1]);
                                    channel.write(ByteBuffer.wrap(dataOdDataDo.getBytes()));
                                    myMap.put(channel, myMap.get(channel) + "\nRequest: " + requestClient + " \nResult: \n" + dataOdDataDo);
                                } catch(IOException e) {
                                    e.printStackTrace();
                                }
                        }
                        continue;
                    }

                }
            }
            catch(IOException e) {
                e.printStackTrace();
                continue;
            }
        }
    }

    public int getSwitch (String str) {
        if (str.contains("login")) {
            return 1;
        } else if (str.equals("bye")){
            return 2;
        } else if (str.contains("bye and log transfer")) {
            return 3;
        } else {
            return 4;
        }
    }


    public void startServer() {
        serverRunning = true;
        myServer.start();
    }

    public String getServerLog() {
        return resultServerLog;
    }

    public void stopServer() {
        serverRunning = false;
    }
}
