/**
 *
 *  @author Mykhalkiv Bohdan S19362
 *
 */

package zad1;


import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.InetSocketAddress;
import java.net.SocketAddress;
import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.nio.channels.SocketChannel;
import java.nio.charset.Charset;

public class Client {
    SocketChannel socketChannel;
    String host;
    int port;
    String id;

     Charset charset = Charset.forName("ISO-8859-2");

    ByteBuffer byteBuffer = ByteBuffer.allocate(1024);


    public Client(String host, int port, String id) {
        this.host = host;
        this.port = port;
        this.id = id;
    }

    public void connect() {
        try {
            socketChannel = SocketChannel.open();
            socketChannel.configureBlocking(false);
            SocketAddress socketAddr = new InetSocketAddress(host, port);
            socketChannel.connect(socketAddr);

            while(!socketChannel.finishConnect()) { }
        }
        catch(IOException e) {
            e.printStackTrace();
        }
    }

    public String send(String req) {
        CharBuffer charBuffer = CharBuffer.wrap(req);
        ByteBuffer byteBuffer = charset.encode(charBuffer);

        try {
            byteBuffer.clear();
            byteBuffer.put(req.getBytes());
            byteBuffer.flip();

            socketChannel.write(byteBuffer);



            while(true) {

                this.byteBuffer.clear();


                int rBytes = socketChannel.read(this.byteBuffer);


                if(rBytes == 0) {
                    continue;
                }

                if(rBytes == -1) {
                    break;
                } else {
                    this.byteBuffer.flip();
                    String resp = new String(this.byteBuffer.array(), 0, rBytes);
                    return resp;
                }

            }
        }
        catch(IOException e) {
            e.printStackTrace();
        }
        return " ";
    }
}