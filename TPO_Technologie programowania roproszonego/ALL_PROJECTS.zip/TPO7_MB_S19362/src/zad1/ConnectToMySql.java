package zad1;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class ConnectToMySql {
    private static final String url = "jdbc:mysql://localhost:3306/DBdyploma";
    private static final String user = "root";
    private static final String password = "73torrent1";

    private static Connection con;
    private static Statement stmt;
    private static ResultSet rs;

    public static void main(String args[]) {
        String query = "select * from pracownik";
            try {
                Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection(url, user, password);

            stmt = con.createStatement();

            rs = stmt.executeQuery(query);

            List <Book> myBooks = new ArrayList<>();


            while (rs.next()) {
                System.out.println(rs.getString("imie"));
            }


        } catch (SQLException sqlEx) {
            sqlEx.printStackTrace();
        } catch (ClassNotFoundException e) {
                throw new RuntimeException(e);
            } finally {
            try { con.close(); } catch(SQLException se) { }
            try { stmt.close(); } catch(SQLException se) { }
            try { rs.close(); } catch(SQLException se) {  }
        }
    }

}






