package com.example.myapplication

import android.app.AlertDialog
import android.graphics.Bitmap
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.annotation.RequiresApi
import androidx.core.graphics.drawable.toBitmap
import androidx.core.os.HandlerCompat
import androidx.fragment.app.FragmentActivity
import androidx.recyclerview.widget.RecyclerView
import com.example.myapplication.data.DataSource
import com.example.myapplication.databinding.ListItemBinding
import java.io.ByteArrayOutputStream

class  ProductViewHolder(val binding: ListItemBinding, val productAdapter: ProductAdapter) : RecyclerView.ViewHolder(binding.root) {
    @RequiresApi(Build.VERSION_CODES.O)
    fun bind(product: Product) {
        binding.titleText.text = product.name
        binding.adress.text = product.adress
        binding.Photo.setImageBitmap(product.resId)


        binding.cardview.setOnLongClickListener{
            val alertDialogBuilder = AlertDialog.Builder(it.context)
            alertDialogBuilder.setMessage("Do you want to finish this event ?")

            alertDialogBuilder.setPositiveButton("Yes")  { dialog, which ->
                DataSource.tasks.remove(product)
                        productAdapter.replace(DataSource.tasks)


            }
            alertDialogBuilder.setNegativeButton("cancel") { dialog, which ->

            }

            alertDialogBuilder.show()

            true
        }
    }
}
class ProductAdapter(val activity: FragmentActivity?) : RecyclerView.Adapter<ProductViewHolder>() {
    private var data = mutableListOf<Product>()
    private val handler : Handler = HandlerCompat.createAsync(Looper.getMainLooper())
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ProductViewHolder {
        val binding = ListItemBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )


        return ProductViewHolder(binding,this )
    }



    @RequiresApi(Build.VERSION_CODES.O)
    override fun onBindViewHolder(holder: ProductViewHolder, position: Int) {
        holder.bind(data[position])
        holder.binding.cardview.setOnClickListener{
            val bn = Bundle()
            bn.putString("name", holder.binding.titleText.text.toString())
            bn.putString("adress", holder.binding.adress.text.toString())
            bn.putByteArray("image",fromBitmap(holder.binding.Photo.drawable.toBitmap()) )


            bn.putInt("id", position)




            activity?.supportFragmentManager?.beginTransaction()?.apply {
                val edit = EditFragment("edit")
                edit.arguments = bn
                replace(R.id.container, edit,edit::class.java.name)
                addToBackStack(EditFragment::class.java.name)
            }?.commit()
        }
    }

    fun fromBitmap(bitmap: Bitmap): ByteArray {
        val outputStream = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.PNG, 100,outputStream)
        return outputStream.toByteArray()
    }

    override fun getItemCount(): Int = data.size

    @RequiresApi(Build.VERSION_CODES.O)
    fun replace(newData: List<Product>) {
        data.clear()
        data.addAll(newData)
        handler.post {

            notifyDataSetChanged()
        }
    }

}