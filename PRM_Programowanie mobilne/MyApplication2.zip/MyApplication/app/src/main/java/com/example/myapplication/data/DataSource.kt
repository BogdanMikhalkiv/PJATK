package com.example.myapplication.data

import com.example.myapplication.Product

object DataSource {
    var count = 0
    var tasks = mutableListOf<Product>()
  //  @RequiresApi(Build.VERSION_CODES.O)
//    var tasks = mutableListOf<Product>(
//        Product(
//            "сделать английскийfghfhghfgh",
//            "Warsaw,Poland, Koszykowa 6",
//            R.drawable.pizza
//        ),
//        Product(
//                "сделать алгебру",
//            "Warsaw,Poland, Koszykowa 190",
//            R.drawable.rosol
//        )
//
//
//    )







}