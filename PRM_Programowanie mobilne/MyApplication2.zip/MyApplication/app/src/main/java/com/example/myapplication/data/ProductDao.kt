package com.example.myapplication.data

import android.graphics.Bitmap
import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update

@Dao
interface ProductDao {
    @Query("select * from product;")
    fun getall(): List<ProductEntity>

    @Insert
    fun addProduct(newProduct: ProductEntity)

    @Query("update product set name = :newName, adress = :newAdress, image = :newImage where id = :id1")
    fun updateProduct(id1: Long, newName: String, newAdress: String , newImage: Bitmap )


    @Query("delete from product where id = :id1")
    fun deleteProduct(id1: Long)
}