package com.example.myapplication

import android.graphics.Bitmap
import android.media.Image
import android.view.View
import android.widget.ImageView
import androidx.annotation.DrawableRes
import java.time.LocalDate
import java.time.Period

data class Product(
    var name: String,
    var adress: String,

    var resId: Bitmap
)
