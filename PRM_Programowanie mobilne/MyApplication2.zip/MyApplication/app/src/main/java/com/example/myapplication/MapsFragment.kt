package com.example.myapplication

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Color
import androidx.fragment.app.Fragment

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import com.example.myapplication.databinding.FragmentEditBinding
import com.example.myapplication.databinding.FragmentMapsBinding

import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.CircleOptions
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions
import com.google.android.material.snackbar.Snackbar

const val RANGE = 10.0
const val RANGE2 = 100.0
private const val STROKE_WIDTH = 10f

class MapsFragment(var fragment: EditFragment) : Fragment() {
    private lateinit var binding: FragmentMapsBinding

    private lateinit var map: GoogleMap
    private val callback = OnMapReadyCallback { googleMap ->
        map = googleMap
        turnOnLocation()
        googleMap.setOnMapClickListener (::onMapClick)

    }



    private lateinit var permissionLauncher: ActivityResultLauncher<Array<String>>

    @SuppressLint("MissingPermission")
    private val onPermisonResult = { results: Map<String, Boolean> ->
        if(ContextCompat.checkSelfPermission(requireContext(),
                Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED){
            map.isMyLocationEnabled = true
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        permissionLauncher = registerForActivityResult(
            ActivityResultContracts.RequestMultiplePermissions(),
            onPermisonResult
        )
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return FragmentMapsBinding.inflate(inflater, container, false).also {
            binding = it
        }.root
    }



    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val mapFragment = childFragmentManager.findFragmentById(R.id.map) as SupportMapFragment?
        mapFragment?.getMapAsync(callback)

        binding.myLocBtn.setOnClickListener {
            fragment.boolean = true
            fragment.lat = map.myLocation.latitude
            fragment.lng = map.myLocation.longitude
            activity?.supportFragmentManager?.beginTransaction()?.apply {
                replace(R.id.container, fragment,fragment::class.java.name)
            }?.commit()
        }
    }

    private fun turnOnLocation() {
        if(ContextCompat.checkSelfPermission(requireContext(),
                Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED){
            map.isMyLocationEnabled = true
        } else{
            permissionLauncher.launch(arrayOf(
                Manifest.permission.ACCESS_FINE_LOCATION,
                Manifest.permission.ACCESS_COARSE_LOCATION))
        }
    }

     private fun onMapClick(latLng: LatLng) {
         drawCircle(latLng)
         askForSave(latLng)

     }

    private fun askForSave(latLng: LatLng) {
        Snackbar.make(
            requireView(),
            "Save location?",
            Snackbar.LENGTH_INDEFINITE
        ).setAction("save") {
            fragment.boolean = true
            fragment.lat = latLng.latitude
            fragment.lng = latLng.longitude
            activity?.supportFragmentManager?.beginTransaction()?.apply {
                replace(R.id.container, fragment,fragment::class.java.name)
            }?.commit()
        }.show()
    }



    private fun drawCircle(latLng: LatLng) {
        var circle = CircleOptions()
            .strokeColor(Color.RED)
            .radius(RANGE)
            .center(latLng)
            .strokeWidth(STROKE_WIDTH)
        map.apply {
            clear()
            addCircle(circle)

        }
    }
}