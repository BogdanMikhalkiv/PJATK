package com.example.myapplication

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.location.Address
import android.location.Geocoder
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.annotation.RequiresApi
import androidx.core.graphics.drawable.toBitmap
import androidx.core.view.drawToBitmap
import androidx.fragment.app.Fragment
import com.example.myapplication.data.DataSource
import com.example.myapplication.data.ProductDatabase
import com.example.myapplication.data.ProductEntity
import com.example.myapplication.databinding.FragmentEditBinding
import java.util.*
import kotlin.concurrent.thread


private const val REQUEST_CODE = 42
class EditFragment(var type: String) : Fragment() {


   private lateinit var binding: FragmentEditBinding

   var boolean : Boolean = false

    var lat : Double = 0.0
    var lng : Double = 0.0


    fun setAdress(lat: Double, lng: Double) {
       val geocoder: Geocoder
       val addresses: List<Address>
       geocoder = Geocoder(requireContext(), Locale.getDefault())

       addresses = geocoder.getFromLocation(
           lat,
           lng,
           1
       )
        val street: String = addresses[0].getAddressLine(0)


       binding.ProductAdress.setText(street )

   }

    @SuppressLint("UseRequireInsteadOfGet")
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        return FragmentEditBinding.inflate(inflater, container, false).also {
            binding = it

        }.root

    }


    override fun onStart() {
        super.onStart()
        if (boolean == true) {
            setAdress(lat, lng)
        }
    }



    @RequiresApi(Build.VERSION_CODES.O)
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val dane = arguments
        val bn = Bundle()

        var count = 0L
        var idSql = 0L

        if (type == "edit"){
            thread {
                var list = ProductDatabase.open(requireContext()).products.getall()
                list.forEach{
                    if (dane?.getInt("id")?.toLong() == count) {
                        idSql = it.id
                    }
                    count++
                }
            }


            binding.ProductName.setText(dane?.getString("name").toString())

            binding.ProductAdress.setText(dane?.getString("adress").toString())

            binding.imageView.setImageBitmap(toBitmap(dane!!.getByteArray("image")!!))

            binding.deleteBtn.visibility = View.VISIBLE

            binding.deleteBtn.setOnClickListener {
                thread {
                    ProductDatabase.open(requireContext()).products.deleteProduct(idSql)
                    (activity as? Navigable)?.navigate(Navigable.Destination.list)
                }
            }



        }

        binding.photoBtn.setOnClickListener{

            val takePictureIntent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)

            startActivityForResult(takePictureIntent, REQUEST_CODE)

        }

        binding.mapBtn.setOnClickListener{
            activity?.supportFragmentManager?.beginTransaction()?.apply {
                val mapsFragment = MapsFragment(this@EditFragment)
                mapsFragment.arguments = bn
                replace(R.id.container, mapsFragment,mapsFragment::class.java.name)
                addToBackStack(MapsFragment::class.java.name)
            }?.commit()
        }




        binding.buttonSave.setOnClickListener {

                if (
                    binding.ProductName.text.toString().isEmpty() ||
                    binding.ProductAdress.text.toString().isEmpty() ||
                    binding.imageView.drawable == null
                ) {
                    if (binding.ProductName.text.toString().isEmpty()) {
                        binding.ProductNameLabel.setTextColor(Color.RED)
                    } else {
                        binding.ProductNameLabel.setTextColor(Color.BLACK)
                    }

                    if (binding.ProductAdress.text.toString().isEmpty()) {
                        binding.adress.setTextColor(Color.RED)
                    } else {
                        binding.adress.setTextColor(Color.BLACK)
                    }

                    if (binding.imageView.drawable == null) {
                        binding.photoLabel.setTextColor(Color.RED)
                    } else {
                        binding.photoLabel.setTextColor(Color.BLACK)
                    }


            } else {
                    if (type == "add") {

                        val newProduct = ProductEntity(
                            name = binding.ProductName.text.toString(),
                            adress = binding.ProductAdress.text.toString(),
                            image = binding.imageView.drawable.toBitmap()
                        )

                        thread {
                            ProductDatabase.open(requireContext()).products.addProduct(newProduct)
                            (activity as? Navigable)?.navigate(Navigable.Destination.list)
                        }

                    } else if (type == "edit") {

                        val currentProduct = ProductEntity(
                            id = idSql,
                            name = binding.ProductName.text.toString(),
                            adress = binding.ProductAdress.text.toString(),
                            image = binding.imageView.drawable.toBitmap()
                        )

                        thread {
                            ProductDatabase.open(requireContext()).products.updateProduct(
                                currentProduct.id,
                                currentProduct.name,
                                currentProduct.adress,
                                currentProduct.image
                            )
                            (activity as? Navigable)?.navigate(Navigable.Destination.list)
                        }

                    }
            }
        }
    }

    fun toBitmap(byteArray: ByteArray) : Bitmap {
        return BitmapFactory.decodeByteArray(byteArray, 0, byteArray.size)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {

        if (requestCode == REQUEST_CODE && resultCode == Activity.RESULT_OK) {
            val takenImage = data?.extras?.get("data") as Bitmap
            binding.imageView.setImageBitmap(takenImage)
        } else {
            super.onActivityResult(requestCode, resultCode, data)
        }
    }




}