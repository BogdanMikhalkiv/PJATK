package com.example.myapplication

import android.app.AlertDialog
import android.os.Build
import android.os.Bundle
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.annotation.RequiresApi
import androidx.fragment.app.FragmentActivity
import androidx.recyclerview.widget.RecyclerView
import com.example.myapplication.databinding.ListItemBinding
import java.time.LocalDate

class  TaskViewHolder(val binding: ListItemBinding, val taskAdapter: TaskAdapter) : RecyclerView.ViewHolder(binding.root) {
    @RequiresApi(Build.VERSION_CODES.O)
    fun bind(task: Task) {
        binding.titleText.text = task.name
        binding.priority.text = task.priority
        binding.deadline.text = task.deadline.toString()
        binding.percent.text = task.progresPercent.toString()
        binding.time.text = task.timeToDo.toString()

        binding.cardview.setOnLongClickListener{
            val alertDialogBuilder = AlertDialog.Builder(it.context)
            alertDialogBuilder.setMessage("Do you want to finish this event ?")

            alertDialogBuilder.setPositiveButton("Yes")  { dialog, which ->
                DataSource.tasks.remove(task)
                        taskAdapter.replace(DataSource.tasks)


            }
            alertDialogBuilder.setNegativeButton("cancel") { dialog, which ->

            }

            alertDialogBuilder.show()

            true
        }
    }
}
class TaskAdapter(val activity: FragmentActivity?) : RecyclerView.Adapter<TaskViewHolder>() {
    private var data = mutableListOf<Task>()
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TaskViewHolder {
        val binding = ListItemBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )


        return TaskViewHolder(binding,this )
    }



    @RequiresApi(Build.VERSION_CODES.O)
    override fun onBindViewHolder(holder: TaskViewHolder, position: Int) {
        holder.bind(data[position])
        holder.binding.cardview.setOnClickListener{
            val bn = Bundle()
            bn.putString("percent", holder.binding.percent.text.toString())
            bn.putString("name", holder.binding.titleText.text.toString())
            bn.putString("priority", holder.binding.priority.text.toString())
            bn.putString("deadline", holder.binding.deadline.text.toString())
            bn.putString("time", holder.binding.time.text.toString())
            bn.putInt("id", position)




            activity?.supportFragmentManager?.beginTransaction()?.apply {
                replace(R.id.container, DataFragment(bn),DataFragment(bn)::class.java.name)
                addToBackStack(DataFragment::class.java.name)
            }?.commit()
        }
    }

    override fun getItemCount(): Int = data.size

    @RequiresApi(Build.VERSION_CODES.O)
    fun replace(newData: List<Task>) {
        data.clear()
        data.addAll(newData)
        DataSource.tasks = DataSource.tasks.filter {
            it.deadline >= LocalDate.now()
        } as MutableList<Task>

        DataSource.tasks.sortWith(compareBy{it.deadline})

        notifyDataSetChanged()
    }

}