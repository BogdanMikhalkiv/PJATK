package com.example.myapplication

import android.os.Build
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.annotation.RequiresApi
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.myapplication.databinding.FragmentEditBinding
import java.time.LocalDate
import java.time.Period


class EditFragment(var type: String) : Fragment() {


   private lateinit var binding: FragmentEditBinding
   private lateinit var adapter: TaskPriorityAdapter




    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        return FragmentEditBinding.inflate(inflater, container, false).also {
            binding = it
        }.root
    }

    @RequiresApi(Build.VERSION_CODES.O)
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        adapter = TaskPriorityAdapter()
        val dane = arguments
        if (type == "edit"){

            binding.taskProgress.setText(dane?.getString("percent").toString())
            binding.taskName.setText(dane?.getString("name").toString())

            binding.taskDeadline.setText(dane?.getString("deadline").toString())



        }


            binding.taskPriority.apply {
                adapter = this@EditFragment.adapter
                layoutManager = LinearLayoutManager(context, LinearLayoutManager.HORIZONTAL, false)
            }
            binding.buttonSave.setOnClickListener {
                if (type == "add") {

                    val newTask = Task(
                        binding.taskName.text.toString(),
                        adapter.selectedPriority,
                        LocalDate.parse(binding.taskDeadline.text.toString()),
                        binding.taskProgress.text.toString().toInt(),
                        Period.between(
                            LocalDate.now(), LocalDate.parse(binding.taskDeadline.text.toString())
                        ).days
                    )

                    DataSource.tasks.add(newTask)
                } else if (type == "edit") {
//                    DataSource.tasks.removeAt(dane!!.getInt("id"))
//
//                    val newTask = Task(
//                        binding.taskName.text.toString(),
//                        adapter.selectedPriority,
//                        LocalDate.parse(binding.taskDeadline.text.toString()),
//                        binding.taskProgress.text.toString().toInt(),
//                        Period.between(
//                            LocalDate.now(), LocalDate.parse(binding.taskDeadline.text.toString())
//                        ).days
//                    )
//                    DataSource.tasks.add(newTask)

                    val task =  DataSource.tasks.get(dane!!.getInt("id"))
                    DataSource.tasks.get(dane!!.getInt("id")).deadline = LocalDate.parse(binding.taskDeadline.text.toString())
                    DataSource.tasks.get(dane!!.getInt("id")).name = binding.taskName.text.toString()
                    DataSource.tasks.get(dane!!.getInt("id")).priority = adapter.selectedPriority
                    DataSource.tasks.get(dane!!.getInt("id")).progresPercent = binding.taskProgress.text.toString().toInt()
                }

                (activity as? Navigable)?.navigate(Navigable.Destination.list)
            }

    }




}