package com.example.myapplication

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.myapplication.databinding.ListItemBinding
import com.example.myapplication.databinding.TaskPriorityBinding

class  TaskPriorityViewHolder(val binding: TaskPriorityBinding)
    : RecyclerView.ViewHolder(binding.root) {


    fun bind(id: String, isSelected: Boolean) {
        binding.priority.text = id
        binding.selectedFrame.visibility = if (isSelected) View.VISIBLE else View.INVISIBLE

    }
}
class TaskPriorityAdapter : RecyclerView.Adapter<TaskPriorityViewHolder>() {
    private val listPriority = listOf<String>("!","!!","!!!")
    private  var selectedPosition: Int = 0
    var selectedPriority: String = listPriority[0]
    get() = listPriority[selectedPosition]
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TaskPriorityViewHolder {
        val binding = TaskPriorityBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return TaskPriorityViewHolder(binding).also {vh ->
            binding.root.setOnClickListener {
                notifyItemChanged(selectedPosition)
                selectedPosition= vh.layoutPosition
                notifyItemChanged(selectedPosition)
            }
        }
    }

    override fun onBindViewHolder(holder: TaskPriorityViewHolder, position: Int) {
        holder.bind(listPriority[position], position == selectedPosition)
    }

    override fun getItemCount(): Int = listPriority.size



}