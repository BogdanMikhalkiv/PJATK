package com.example.myapplication

import android.icu.text.DateFormat
import android.os.Build
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.annotation.RequiresApi
import androidx.core.view.get
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.myapplication.databinding.FragmentListBinding
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.temporal.TemporalAdjusters.next
import java.util.*
import java.time.DayOfWeek.SUNDAY


class ListFragment : Fragment() {



    private lateinit var binding: FragmentListBinding
    private lateinit var adapter: TaskAdapter
    private  var count = 0
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        return FragmentListBinding.inflate(inflater, container, false).also {
            binding = it
        }.root
    }


    @RequiresApi(Build.VERSION_CODES.O)
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {

        super.onViewCreated(view, savedInstanceState)
        adapter = TaskAdapter(activity).apply {
            replace(DataSource.tasks)
        }
        binding.list.let {
            it.adapter = adapter
            it.layoutManager = LinearLayoutManager(requireContext())
        }
        binding.btnAdd.setOnClickListener{
            (activity as? Navigable)?.navigate(Navigable.Destination.Add)
        }

        for (i in DataSource.tasks) {
            if (i.deadline <= LocalDate.now().with((SUNDAY)) ) {
                count++
            }
        }


        binding.toDo.text = count.toString()
        count =0



    }


}