package com.example.myapplication

import java.time.LocalDate
import java.time.Period

data class Task(
    var name: String,
    var priority: String,
    var deadline: LocalDate,
    var progresPercent: Int,
    val timeToDo: Int
)
