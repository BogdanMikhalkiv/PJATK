package com.example.myapplication

import android.os.Build
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.annotation.RequiresApi
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.myapplication.databinding.FragmentDataBinding
import java.time.LocalDate
import java.time.Period

class DataFragment(var bundle: Bundle) : Fragment() {

    private lateinit var binding: FragmentDataBinding


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        return FragmentDataBinding.inflate(inflater, container, false).also {
            binding = it
        }.root
    }

    @RequiresApi(Build.VERSION_CODES.O)
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.taskName.text = bundle.getString("name").toString()
        binding.taskPriority.text = bundle.getString("priority").toString()
        binding.taskDeadline.text = bundle.getString("deadline").toString()
        binding.taskTime.text = bundle.getString("time").toString()
        binding.taskProgress.setText(bundle.getString("percent").toString())



        binding.buttonSave.setOnClickListener{
            val id = bundle.getInt("id")


            DataSource.tasks.get(id).progresPercent = binding.taskProgress.text.toString().toInt()
            (activity as? Navigable)?.navigate(Navigable.Destination.list)
        }

        binding.buttonEdit.setOnClickListener{
            activity?.supportFragmentManager?.beginTransaction()?.apply {
                val edit = EditFragment("edit")
                edit.arguments = bundle
                replace(R.id.container, edit,edit::class.java.name)
                addToBackStack(EditFragment::class.java.name)
            }?.commit()
        }






    }
}