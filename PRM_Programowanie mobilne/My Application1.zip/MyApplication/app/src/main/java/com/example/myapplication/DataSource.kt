package com.example.myapplication

import android.os.Build
import androidx.annotation.RequiresApi
import java.time.Duration
import java.time.LocalDate
import java.time.Period
import java.time.temporal.ChronoUnit

object DataSource {
    var count = 0
    @RequiresApi(Build.VERSION_CODES.O)
    var tasks = mutableListOf<Task>(
        Task(
            "сделать английский",
            "!",
            LocalDate.of(2022,5,10),
            10,
            Period.between(LocalDate.now(), LocalDate.of(2022,5,10)).days,

        ),
        Task(
                "сделать алгебру",
                "!!",
                LocalDate.of(2022,5,9),
                0,
                Period.between(LocalDate.now(), LocalDate.of(2022,5,9)).days,
        )


    )







}