package com.example.myapplication

interface Navigable {
    enum class Destination{
        list, Add, Data
    }
    fun navigate(to: Destination)
    //fun navigate(to: DataFragment)
}